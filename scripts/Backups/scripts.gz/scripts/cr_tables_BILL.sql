set echo on
set timing on
set time on
conn billteste/billteste
spool cr_tables_billteste.log

Prompt Criando tabela:MOVI_BILL_OFICIAL20061101
create table billteste.MOVI_BILL_OFICIAL20061101 nologging as
select * from billprod.MOVI_BILL_OFICIAL20061101@orabill
;

Prompt Criando tabela:TMP_CARACTERISTICAS
create table billteste.TMP_CARACTERISTICAS nologging as
select * from billprod.TMP_CARACTERISTICAS@orabill
;

Prompt Criando tabela:TMP_CARAC_ESPECIFICAS
create table billteste.TMP_CARAC_ESPECIFICAS nologging as
select * from billprod.TMP_CARAC_ESPECIFICAS@orabill
;

Prompt Criando tabela:TMP_CONTRATO_CONTAS
create table billteste.TMP_CONTRATO_CONTAS nologging as
select * from billprod.TMP_CONTRATO_CONTAS@orabill
;

Prompt Criando tabela:TMP_LANCAMENTOS
create table billteste.TMP_LANCAMENTOS nologging as
select * from billprod.TMP_LANCAMENTOS@orabill
;

Prompt Criando tabela:TMP_PLANO_PACOTES
create table billteste.TMP_PLANO_PACOTES nologging as
select * from billprod.TMP_PLANO_PACOTES@orabill
;

Prompt Criando tabela:TMP_PRATELEIRAS
create table billteste.TMP_PRATELEIRAS nologging as
select * from billprod.TMP_PRATELEIRAS@orabill
;

Prompt Criando tabela:TMP_PRODUTOS
create table billteste.TMP_PRODUTOS nologging as
select * from billprod.TMP_PRODUTOS@orabill
;

Prompt Criando tabela:TMP_TRR_INSTANCIAS
create table billteste.TMP_TRR_INSTANCIAS nologging as
select * from billprod.TMP_TRR_INSTANCIAS@orabill
;

Prompt Criando tabela:TMP_TRR_INSTANCIA_POPS
create table billteste.TMP_TRR_INSTANCIA_POPS nologging as
select * from billprod.TMP_TRR_INSTANCIA_POPS@orabill
;

Prompt Criando tabela:TRR_BILLING_COMPETENCIAS
create table billteste.TRR_BILLING_COMPETENCIAS nologging as
select * from billprod.TRR_BILLING_COMPETENCIAS@orabill
;

Prompt Criando tabela:TRR_CARACTERISTICAS
create table billteste.TRR_CARACTERISTICAS nologging as
select * from billprod.TRR_CARACTERISTICAS@orabill
;

Prompt Criando tabela:TRR_CLASSE_CACHES
create table billteste.TRR_CLASSE_CACHES nologging as
select * from billprod.TRR_CLASSE_CACHES@orabill
;

Prompt Criando tabela:TRR_CONTRATO_CONTAS
create table billteste.TRR_CONTRATO_CONTAS nologging as
select * from billprod.TRR_CONTRATO_CONTAS@orabill where cd_pop in ('BEM')
;

Prompt Criando tabela:TRR_CONTROLE_LANCAMENTOS
create table billteste.TRR_CONTROLE_LANCAMENTOS nologging as
select * from billprod.TRR_CONTROLE_LANCAMENTOS@orabill
;

Prompt Criando tabela:TRR_DICIONARIO_DADOS
create table billteste.TRR_DICIONARIO_DADOS nologging as
select * from billprod.TRR_DICIONARIO_DADOS@orabill
;

Prompt Criando tabela:TRR_ECD_INPUT_GBC
create table billteste.TRR_ECD_INPUT_GBC nologging as
select * from billprod.TRR_ECD_INPUT_GBC@orabill
;

Prompt Criando tabela:TRR_ESQUEMAS
create table billteste.TRR_ESQUEMAS nologging as
select * from billprod.TRR_ESQUEMAS@orabill
;

Prompt Criando tabela:TRR_ESTATISTICA_BILLINGS
create table billteste.TRR_ESTATISTICA_BILLINGS nologging as
select * from billprod.TRR_ESTATISTICA_BILLINGS@orabill
;

Prompt Criando tabela:TRR_EVENTOS
create table billteste.TRR_EVENTOS nologging as
select * from billprod.TRR_EVENTOS@orabill
;

Prompt Criando tabela:TRR_EVENTO_PRECEDENCIAS
create table billteste.TRR_EVENTO_PRECEDENCIAS nologging as
select * from billprod.TRR_EVENTO_PRECEDENCIAS@orabill
;

Prompt Criando tabela:TRR_GRUPOS
create table billteste.TRR_GRUPOS nologging as
select * from billprod.TRR_GRUPOS@orabill
;

Prompt Criando tabela:TRR_GRUPO_POPS
create table billteste.TRR_GRUPO_POPS nologging as
select * from billprod.TRR_GRUPO_POPS@orabill
;

Prompt Criando tabela:TRR_HISTORICO_CARACTERISTICAS
create table billteste.TRR_HISTORICO_CARACTERISTICAS nologging as
select * from billprod.TRR_HISTORICO_CARACTERISTICAS@orabill
;

Prompt Criando tabela:TRR_HISTORICO_PLANO_PACOTES
create table billteste.TRR_HISTORICO_PLANO_PACOTES nologging as
select * from billprod.TRR_HISTORICO_PLANO_PACOTES@orabill
;

Prompt Criando tabela:TRR_INPUT_GBC
create table billteste.TRR_INPUT_GBC nologging as
select * from billprod.TRR_INPUT_GBC@orabill
;

Prompt Criando tabela:TRR_INPUT_GBC_CORP
create table billteste.TRR_INPUT_GBC_CORP nologging as
select * from billprod.TRR_INPUT_GBC_CORP@orabill
;

Prompt Criando tabela:TRR_INSTANCIAS
create table billteste.TRR_INSTANCIAS nologging as
select * from billprod.TRR_INSTANCIAS@orabill
;

Prompt Criando tabela:TRR_INSTANCIA_POPS
create table billteste.TRR_INSTANCIA_POPS nologging as
select * from billprod.TRR_INSTANCIA_POPS@orabill
;

Prompt Criando tabela:TRR_INSTANCIA_PROCESSOS
create table billteste.TRR_INSTANCIA_PROCESSOS nologging as
select * from billprod.TRR_INSTANCIA_PROCESSOS@orabill
;

Prompt Criando tabela:TRR_LINGUAGENS
create table billteste.TRR_LINGUAGENS nologging as
select * from billprod.TRR_LINGUAGENS@orabill
;

Prompt Criando tabela:TRR_LINHA_TEMPOS
create table billteste.TRR_LINHA_TEMPOS nologging as
select * from billprod.RES_LINHA_TEMPOS@orabill
 where id_contrato_conta in (select id_contrato_conta from BILLPROD.trr_contrato_contas@orabill where cd_pop in ('BEM'));
;

Prompt Criando tabela:TRR_LOG_CARGA_SUAT
create table billteste.TRR_LOG_CARGA_SUAT nologging as
select * from billprod.TRR_LOG_CARGA_SUAT@orabill
;

Prompt Criando tabela:TRR_LOG_PROCESSOS
create table billteste.TRR_LOG_PROCESSOS nologging as
select * from billprod.TRR_LOG_PROCESSOS@orabill
;

Prompt Criando tabela:TRR_MDA_GRAVACOES
create table billteste.TRR_MDA_GRAVACOES nologging as
select * from billprod.TRR_MDA_GRAVACOES@orabill
;

Prompt Criando tabela:TRR_MODULOS
create table billteste.TRR_MODULOS nologging as
select * from billprod.TRR_MODULOS@orabill
;

Prompt Criando tabela:TRR_MODULO_ESQUEMAS
create table billteste.TRR_MODULO_ESQUEMAS nologging as
select * from billprod.TRR_MODULO_ESQUEMAS@orabill
;

Prompt Criando tabela:TRR_MODULO_EVENTOS
create table billteste.TRR_MODULO_EVENTOS nologging as
select * from billprod.TRR_MODULO_EVENTOS@orabill
;

Prompt Criando tabela:TRR_NEGOCIOS
create table billteste.TRR_NEGOCIOS nologging as
select * from billprod.TRR_NEGOCIOS@orabill
;

Prompt Criando tabela:TRR_NEGOCIO_PRATELEIRAS
create table billteste.TRR_NEGOCIO_PRATELEIRAS nologging as
select * from billprod.TRR_NEGOCIO_PRATELEIRAS@orabill
;

Prompt Criando tabela:TRR_OCORRENCIAS
create table billteste.TRR_OCORRENCIAS nologging as
select * from billprod.TRR_OCORRENCIAS@orabill
;

Prompt Criando tabela:TRR_PARAMETRO_COBRANCAS
create table billteste.TRR_PARAMETRO_COBRANCAS nologging as
select * from billprod.TRR_PARAMETRO_COBRANCAS@orabill
;

Prompt Criando tabela:TRR_PLANO_PACOTES
create table billteste.TRR_PLANO_PACOTES nologging as
select * from billprod.TRR_PLANO_PACOTES@orabill
;

Prompt Criando tabela:TRR_POPS
create table billteste.TRR_POPS nologging as
select * from billprod.TRR_POPS@orabill
;

Prompt Criando tabela:TRR_PRIORIDADES
create table billteste.TRR_PRIORIDADES nologging as
select * from billprod.TRR_PRIORIDADES@orabill
;

Prompt Criando tabela:TRR_PROCESSOS
create table billteste.TRR_PROCESSOS nologging as
select * from billprod.TRR_PROCESSOS@orabill
;

Prompt Criando tabela:TRR_PRODUTOS
create table billteste.TRR_PRODUTOS nologging as
select * from billprod.TRR_PRODUTOS@orabill
;

Prompt Criando tabela:TRR_RELATORIOS
create table billteste.TRR_RELATORIOS nologging as
select * from billprod.TRR_RELATORIOS@orabill
;

Prompt Criando tabela:TRR_RELATORIO_MANUTENCOES
create table billteste.TRR_RELATORIO_MANUTENCOES nologging as
select * from billprod.TRR_RELATORIO_MANUTENCOES@orabill
;

Prompt Criando tabela:TRR_TIPO_CONEXAO_PERMITIDAS
create table billteste.TRR_TIPO_CONEXAO_PERMITIDAS nologging as
select * from billprod.TRR_TIPO_CONEXAO_PERMITIDAS@orabill
;

Prompt Criando tabela:TRR_TMP_RELATORIOTFC_FEV
create table billteste.TRR_TMP_RELATORIOTFC_FEV nologging as
select * from billprod.TRR_TMP_RELATORIOTFC_FEV@orabill
;

Prompt Criando tabela:TRR_TMP_RELATORIOTFC_MAR
create table billteste.TRR_TMP_RELATORIOTFC_MAR nologging as
select * from billprod.TRR_TMP_RELATORIOTFC_MAR@orabill
;

Prompt Criando tabela:TRR_VALOR_PARAM_POPS
create table billteste.TRR_VALOR_PARAM_POPS nologging as
select * from billprod.TRR_VALOR_PARAM_POPS@orabill
;

Prompt Criando tabela:TRR_VALOR_PARAM_SISTEMAS
create table billteste.TRR_VALOR_PARAM_SISTEMAS nologging as
select * from billprod.TRR_VALOR_PARAM_SISTEMAS@orabill
;


Prompt Criando tabela:TRR_BILLINGS
create table billteste.TRR_BILLINGS nologging as
select * from billprod.TRR_BILLINGS@orabill WHERE 1<>1
;

Prompt Criando tabela:TRR_BILLING_TIPO_CONEXOES
create table billteste.TRR_BILLING_TIPO_CONEXOES nologging as
select * from billprod.TRR_BILLING_TIPO_CONEXOES@orabill WHERE 1<>1
;

Prompt Criando tabela:TRR_CARAC_ESPECIFICAS
create table billteste.TRR_CARAC_ESPECIFICAS nologging as
select * from billprod.TRR_CARAC_ESPECIFICAS@orabill WHERE 1<>1
;

Prompt Criando tabela:TRR_CREDITOS
create table billteste.TRR_CREDITOS nologging as
select * from billprod.TRR_CREDITOS@orabill WHERE 1<>1
;

Prompt Criando tabela:TRR_HISTORICO_CONTRATO_CONTAS
create table billteste.TRR_HISTORICO_CONTRATO_CONTAS nologging as
select * from billprod.TRR_HISTORICO_CONTRATO_CONTAS@orabill WHERE 1<>1
;

Prompt Criando tabela:TRR_INPUT_LANCAMENTOS
create table billteste.TRR_INPUT_LANCAMENTOS nologging as
select * from billprod.TRR_INPUT_LANCAMENTOS@orabill WHERE 1<>1
;

Prompt Criando tabela:TRR_OCORRENCIA_LOGS
create table billteste.TRR_OCORRENCIA_LOGS nologging as
select * from billprod.TRR_OCORRENCIA_LOGS@orabill WHERE 1<>1
;

Prompt Criando tabela:TRR_OUTPUT_BILHETE
create table billteste.TRR_OUTPUT_BILHETE nologging as
select * from billprod.TRR_OUTPUT_BILHETE@orabill WHERE 1<>1
;

Prompt Criando tabela:TRR_OUTPUT_BILHETE_HISTORICO
create table billteste.TRR_OUTPUT_BILHETE_HISTORICO nologging as
select * from billprod.TRR_OUTPUT_BILHETE_HISTORICO@orabill WHERE 1<>1
;

Prompt Criando tabela:TRR_OUTPUT_CARACTERISTICAS
create table billteste.TRR_OUTPUT_CARACTERISTICAS nologging as
select * from billprod.TRR_OUTPUT_CARACTERISTICAS@orabill WHERE 1<>1
;

Prompt Criando tabela:TRR_PRATELEIRAS
create table billteste.TRR_PRATELEIRAS nologging as
select * from billprod.TRR_PRATELEIRAS@orabill WHERE 1<>1
;

Prompt Criando tabela:TRR_VALOR_EXTRAS
create table billteste.TRR_VALOR_EXTRAS nologging as
select * from billprod.TRR_VALOR_EXTRAS@orabill WHERE 1<>1
;

Spool off;
exit;
