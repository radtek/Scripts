undefine tabe;
col ultima for a20
select owner,tablespace_name, num_rows, to_char(last_analyzed,'dd/mm/yyyy hh24:mi:ss') ultima, AVG_ROW_LEN tam_medio_linha, sample_size,BLOCKS,EMPTY_BLOCKS,CHAIN_CNT
 from all_tables
where table_name = upper('&tabe')
order by num_rows desc
/
