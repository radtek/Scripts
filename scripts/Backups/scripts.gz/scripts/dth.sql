alter session set nls_date_format = 'dd/mm/yyyy hh24:mi:ss';
