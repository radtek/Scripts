set pagesize 500
set lines 400
set trimspool on
col D_MAIL_IMAP_HABILITADO format a22
break on report
compute sum of num_users on report
spool dsv3141.txt


select brand, d_mail_imap_habilitado, imap, num_users, to_char((ratio_to_report(num_users) over ()) * 100,'FM990D00') as Percentual
  from (select mbrand.brand, nvl(usrm.d_mail_imap_habilitado,'Default') d_mail_imap_habilitado, obpv.valor imap, count(*) num_users
          from mail.trr_emp_atributos empa, mail.trr_usr_mails usrm, bd_central.trr_obpv_users obpv, mail.trr_mail_brands mbrand
         where usrm.usrm_id (+) = obpv.snh_id
	   	   and usrm.empa_id 	= empa.empa_id (+)
	       and usrm.mbrand_id 	= mbrand.mbrand_id (+)
	       and obpv.obpv_id 	= 48
	       and obpv.valor in 	('2_ALLOWED', '1_ONLY_WEB')
         group by mbrand.brand, nvl(usrm.d_mail_imap_habilitado,'Default'), obpv.valor
      )
/

spool off;
exit;


