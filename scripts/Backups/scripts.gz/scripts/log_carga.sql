col msg for a30 trunc;
col inicio for a20;
col fim for a20;
select * from (
select a.PROCESSO_CARGA, b.DT_STAT, to_char(DT_INI,'dd/mm/yyyy hh24:mi:ss') Inicio,
to_char(DT_fim,'dd/mm/yyyy hh24:mi:ss') fim,
msg, status
from stat.log_processo_cargas a, stat.log_cargas b
where a.PROCESSO_CARGA_ID = b.PROCESSO_CARGA_ID
order by b.CARGA_ID desc)
where rownum <=30
/
