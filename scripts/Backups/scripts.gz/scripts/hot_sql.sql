col sql_text for a80;
col Gets_p_exec for 999,999,999,999;

spool hot_sql.log
select * 
  from (select 	username,sql_text, executions, 
		buffer_gets, 
		buffer_gets/decode(executions,0,1,executions) Gets_p_exec,
		parse_calls,
		hash_value
         from v$sqlarea a , dba_users b
        where a.PARSING_USER_ID = b.user_id
        order by executions desc)
 where rownum <= &top_n
/


spool off;
