spool update_mail_smart.log
set timing on
set echo on
alter session set sort_area_size=30000000;



-- Script to insert new OBP variables.
--
declare
    --
    v_lines_to_commit       number := 1000;
    v_cont                  number := 0;
    v_exit                  varchar2(01) := null;
    --
    cursor assinantes_cur is
select /*+ use_hash (a b d obp3 obp4) */
  distinct(d.empa_id)
  from bd_central.trr_senhas a, mail.trr_usr_mails b, mail.trr_emp_atributos d,
       (select snh_id
          from bd_central.trr_obpv_users
         where obpv_id = 3
           and valor = 'T') obp3,
       (select snh_id
          from bd_central.trr_obpv_users
         where obpv_id = 4
           and valor = 'T') obp4
 where a.snh_id            = b.usrm_id
   and a.snh_id            = obp3.snh_id
   and a.snh_id            = obp4.snh_id
   and b.empa_id           = d.empa_id
   and d.d_mail_smart_habilitado is null;
--
begin
    --
    -- Esse loop foi incluido apenas para tratar os poss�veis ORA-1555 (SNAPSHOT TOO OLD).
    v_exit := 'N';
    loop
      exit when v_exit = 'S';
      begin
        --
        for C in assinantes_cur
        loop
		  --
			begin

				update mail.trr_emp_atributos a
				set a.d_mail_smart_habilitado = 'N' 
				where a.empa_id = C.empa_id;

			exception
				when others then
					raise;
			end;
			  --
			if (v_cont = v_lines_to_commit) then
				commit;
				v_cont := 0;
			else
				v_cont := v_cont + 1;
			end if;
        --
        end loop;
        --
        commit;
        v_exit := 'S';
      exception when others then
        if (sqlcode = -1555) then
           v_exit := 'N';
		   rollback;
        else
		   rollback;
           raise;
        end if;
      end;
    end loop;
    --
end;
--
/

exit;


