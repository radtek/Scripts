select sid, serial#, context ,
       round(sofar/totalwork*100,2) "% Complete", 
       to_char(sysdate,'hh24: mi:ss') "Time Now" 
from  v$session_longops 
where substr(opname,1,4) = 'RMAN'
  and sofar <> totalwork
/
