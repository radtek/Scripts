break on tablespace_name skip 1;
select a.tablespace_name,a.file_id,a.file_name,
       b.bytes,b.create_bytes,b.status,b.enabled
from dba_data_files a , v$datafile b
where a.file_id=b.file#
order by tablespace_name
/
