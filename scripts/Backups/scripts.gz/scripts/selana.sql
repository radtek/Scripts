undefine dono;
col ultima for a20
select table_name, num_rows, to_char(last_analyzed,'dd/mm/yyyy hh24:mi:ss') ultima, AVG_ROW_LEN tam_medio_linha, sample_size,BLOCKS,EMPTY_BLOCKS
 from all_tables
where owner = upper('&dono')
order by num_rows desc
/
