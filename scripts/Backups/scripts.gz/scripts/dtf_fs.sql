select a.tablespace_name||'('||b.status||')' tablespace_name, a.file_name, a.BYTES, a.AUTOEXTENSIBLE, a.MAXBYTES
from dba_data_files a, dba_tablespaces b
where a.file_name like '%&string%'
  and a.tablespace_name = b.tablespace_name
/
