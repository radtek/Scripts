select sid, serial#, username, machine, program, server from v$session
where paddr in (select addr from v$process where spid = &pid_so)
/
