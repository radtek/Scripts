set timing on
set echo on

alter session set sort_area_SIZE = 50000000;
alter session set db_file_multiblock_read_count = 128;


alter index DISCOV_PLANETA.IDX_VDISK_ULTACESSO 
rebuild online nologging
tablespace DISCOVIRTUAL_INDEX
storage (initial 40m next 5m);


alter index DISCOV_PLANETA.IDX_VDISK_ULTACESSO logging;

analyze DISCOV_PLANETA.IDX_VDISK_ULTACESSO compute statistics;

exit;


