spool cr_tables_dsv_suat.log
set echo on
set time on
set timing on

CONN dsv_suat/dsv_suat

Prompt ReCriando tabela:TRR_ACAOPROMOCAO_PROMOCAO
create table dsv_suat.TRR_ACAOPROMOCAO_PROMOCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_ACAOPROMOCAO_PROMOCAO@orahlg01
;

Prompt ReCriando tabela:TRR_ACAO_PROMOCAO
create table dsv_suat.TRR_ACAO_PROMOCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_ACAO_PROMOCAO@orahlg01
;

Prompt ReCriando tabela:TRR_AGENDA
create table dsv_suat.TRR_AGENDA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_AGENDA@orahlg01
;

Prompt ReCriando tabela:TRR_AGENDA_CANCEL
create table dsv_suat.TRR_AGENDA_CANCEL Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_AGENDA_CANCEL@orahlg01
;

Prompt ReCriando tabela:TRR_AGENDA_PROCESSO
create table dsv_suat.TRR_AGENDA_PROCESSO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_AGENDA_PROCESSO@orahlg01
;

Prompt ReCriando tabela:TRR_ALIAS
create table dsv_suat.TRR_ALIAS Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_ALIAS@orahlg01
;

Prompt ReCriando tabela:TRR_AREAINTERESSE_CONTA
create table dsv_suat.TRR_AREAINTERESSE_CONTA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_AREAINTERESSE_CONTA@orahlg01
;

Prompt ReCriando tabela:TRR_AREA_INTERESSE
create table dsv_suat.TRR_AREA_INTERESSE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_AREA_INTERESSE@orahlg01
;

Prompt ReCriando tabela:TRR_ASSINANTE
create table dsv_suat.TRR_ASSINANTE Tablespace SUAT_BIG_DATA nologging as
select * from dsv_suat.TRR_ASSINANTE@orahlg01
;

Prompt ReCriando tabela:TRR_ASSINANTE_RESPOSTA
create table dsv_suat.TRR_ASSINANTE_RESPOSTA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_ASSINANTE_RESPOSTA@orahlg01
;

Prompt ReCriando tabela:TRR_ATRIBUTO
create table dsv_suat.TRR_ATRIBUTO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_ATRIBUTO@orahlg01
;

Prompt ReCriando tabela:TRR_ATRIBUTO_ENTIDADECONJOPER
create table dsv_suat.TRR_ATRIBUTO_ENTIDADECONJOPER Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_ATRIBUTO_ENTIDADECONJOPER@orahlg01
;

Prompt ReCriando tabela:TRR_ATRIBUTO_GRUPO_NAMESPACE
create table dsv_suat.TRR_ATRIBUTO_GRUPO_NAMESPACE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_ATRIBUTO_GRUPO_NAMESPACE@orahlg01
;

Prompt ReCriando tabela:TRR_ATRIBUTO_LOG
create table dsv_suat.TRR_ATRIBUTO_LOG Tablespace SUAT_LOG_DATA nologging as
select * from dsv_suat.TRR_ATRIBUTO_LOG@orahlg01 where 1<>1
;

CREATE INDEX "DSV_SUAT"."ATLO_ATRI_FK_I" ON "DSV_SUAT"."TRR_ATRIBUTO_LOG" ("ID_ATRIBUTO")
  TABLESPACE "SUAT_LOG_INDX";

CREATE INDEX "DSV_SUAT"."ATLO_LOOP_FK_I" ON "DSV_SUAT"."TRR_ATRIBUTO_LOG"
("NR_LOG_OPERACAO", "ID_REGISTRO_OPERACAO", "ID_ENTIDADE", "DT_REGISTRO_OPERACAO")
  TABLESPACE "SUAT_LOG_INDX";

CREATE UNIQUE INDEX "DSV_SUAT"."ATLO_PK" ON "DSV_SUAT"."TRR_ATRIBUTO_LOG"
("NR_LOG_OPERACAO", "ID_REGISTRO_OPERACAO", "ID_ENTIDADE", "ID_ATRIBUTO", "DT_REGISTRO_OPERACAO")
  TABLESPACE "SUAT_LOG_INDX";

Prompt ReCriando tabela:TRR_AUMENTOPRECO_CLIENTE
create table dsv_suat.TRR_AUMENTOPRECO_CLIENTE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_AUMENTOPRECO_CLIENTE@orahlg01
;

Prompt ReCriando tabela:TRR_AUMENTOPRECO_LOG
create table dsv_suat.TRR_AUMENTOPRECO_LOG Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_AUMENTOPRECO_LOG@orahlg01
;

Prompt ReCriando tabela:TRR_AUMENTOPRECO_LOGVERIFICA
create table dsv_suat.TRR_AUMENTOPRECO_LOGVERIFICA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_AUMENTOPRECO_LOGVERIFICA@orahlg01
;

Prompt ReCriando tabela:TRR_AUMENTOPRECO_PACOTE
create table dsv_suat.TRR_AUMENTOPRECO_PACOTE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_AUMENTOPRECO_PACOTE@orahlg01
;

Prompt ReCriando tabela:TRR_AUMENTOPRECO_PLANO
create table dsv_suat.TRR_AUMENTOPRECO_PLANO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_AUMENTOPRECO_PLANO@orahlg01
;

Prompt ReCriando tabela:TRR_BRINDE
create table dsv_suat.TRR_BRINDE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_BRINDE@orahlg01
;

Prompt ReCriando tabela:TRR_CARACSERVICO_PACOTECOM
create table dsv_suat.TRR_CARACSERVICO_PACOTECOM Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CARACSERVICO_PACOTECOM@orahlg01
;

Prompt ReCriando tabela:TRR_CARACTERISTICA
create table dsv_suat.TRR_CARACTERISTICA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CARACTERISTICA@orahlg01
;

Prompt ReCriando tabela:TRR_CARACTERISTICA_ESPECIFICA
create table dsv_suat.TRR_CARACTERISTICA_ESPECIFICA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CARACTERISTICA_ESPECIFICA@orahlg01
;

Prompt ReCriando tabela:TRR_CARACTERISTICA_SERVICO
create table dsv_suat.TRR_CARACTERISTICA_SERVICO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CARACTERISTICA_SERVICO@orahlg01
;

Prompt ReCriando tabela:TRR_CARGA_COMPORTAMENTAL
create table dsv_suat.TRR_CARGA_COMPORTAMENTAL Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CARGA_COMPORTAMENTAL@orahlg01
;

Prompt ReCriando tabela:TRR_CCID_NAI
create table dsv_suat.TRR_CCID_NAI Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CCID_NAI@orahlg01
;

Prompt ReCriando tabela:TRR_CICLO
create table dsv_suat.TRR_CICLO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CICLO@orahlg01
;

Prompt ReCriando tabela:TRR_CICLOBILLING_VENCIMENTO
create table dsv_suat.TRR_CICLOBILLING_VENCIMENTO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CICLOBILLING_VENCIMENTO@orahlg01
;

Prompt ReCriando tabela:TRR_CICLOSERVICO_LINHANEGOCIO
create table dsv_suat.TRR_CICLOSERVICO_LINHANEGOCIO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CICLOSERVICO_LINHANEGOCIO@orahlg01
;

Prompt ReCriando tabela:TRR_CICLOSERVICO_REGISTRADO
create table dsv_suat.TRR_CICLOSERVICO_REGISTRADO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CICLOSERVICO_REGISTRADO@orahlg01
;

Prompt ReCriando tabela:TRR_CICLO_BILLING
create table dsv_suat.TRR_CICLO_BILLING Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CICLO_BILLING@orahlg01
;

Prompt ReCriando tabela:TRR_CIDADE
create table dsv_suat.TRR_CIDADE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CIDADE@orahlg01
;

Prompt ReCriando tabela:TRR_CIDADE_CLASSEPACOTE
create table dsv_suat.TRR_CIDADE_CLASSEPACOTE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CIDADE_CLASSEPACOTE@orahlg01
;

Prompt ReCriando tabela:TRR_CIDADE_CONVENIO
create table dsv_suat.TRR_CIDADE_CONVENIO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CIDADE_CONVENIO@orahlg01
;

Prompt ReCriando tabela:TRR_CIDADE_GRUPOCIDADE
create table dsv_suat.TRR_CIDADE_GRUPOCIDADE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CIDADE_GRUPOCIDADE@orahlg01
;

Prompt ReCriando tabela:TRR_CIDADE_MODCOBRANCA
create table dsv_suat.TRR_CIDADE_MODCOBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CIDADE_MODCOBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_CIDADE_PARAMSISTEMA
create table dsv_suat.TRR_CIDADE_PARAMSISTEMA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CIDADE_PARAMSISTEMA@orahlg01
;

Prompt ReCriando tabela:TRR_CIDADE_PROMOCAO
create table dsv_suat.TRR_CIDADE_PROMOCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CIDADE_PROMOCAO@orahlg01
;

Prompt ReCriando tabela:TRR_CIDADE_TELTERRA
create table dsv_suat.TRR_CIDADE_TELTERRA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CIDADE_TELTERRA@orahlg01
;

Prompt ReCriando tabela:TRR_CLASSEPACOTE_MODCOBRANCA
create table dsv_suat.TRR_CLASSEPACOTE_MODCOBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CLASSEPACOTE_MODCOBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_CLASSEPACOTE_PROMOCAO
create table dsv_suat.TRR_CLASSEPACOTE_PROMOCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CLASSEPACOTE_PROMOCAO@orahlg01
;

Prompt ReCriando tabela:TRR_CLASSE_PACOTE
create table dsv_suat.TRR_CLASSE_PACOTE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CLASSE_PACOTE@orahlg01
;

Prompt ReCriando tabela:TRR_CLASSE_SERVICO
create table dsv_suat.TRR_CLASSE_SERVICO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CLASSE_SERVICO@orahlg01
;

Prompt ReCriando tabela:TRR_COBRANCA_ADICIONAL
create table dsv_suat.TRR_COBRANCA_ADICIONAL Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_COBRANCA_ADICIONAL@orahlg01
;

Prompt ReCriando tabela:TRR_CONJ_OPERACAO
create table dsv_suat.TRR_CONJ_OPERACAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CONJ_OPERACAO@orahlg01
;

Prompt ReCriando tabela:TRR_CONTA
create table dsv_suat.TRR_CONTA Tablespace SUAT_TRR_CONTA_DATA nologging as
select * from dsv_suat.TRR_CONTA@orahlg01
;

Prompt ReCriando tabela:TRR_CONTATO_CONTRATOCOBRANCA
create table dsv_suat.TRR_CONTATO_CONTRATOCOBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CONTATO_CONTRATOCOBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_CONTATO_LINHANEGOCIO
create table dsv_suat.TRR_CONTATO_LINHANEGOCIO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CONTATO_LINHANEGOCIO@orahlg01
;

Prompt ReCriando tabela:TRR_CONTATO_LNEG_CONTRATOCOB
create table dsv_suat.TRR_CONTATO_LNEG_CONTRATOCOB Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CONTATO_LNEG_CONTRATOCOB@orahlg01
;

Prompt ReCriando tabela:TRR_CONTA_NEWSLETTER
create table dsv_suat.TRR_CONTA_NEWSLETTER Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CONTA_NEWSLETTER@orahlg01
;

Prompt ReCriando tabela:TRR_CONTA_RESPONSAVEL
create table dsv_suat.TRR_CONTA_RESPONSAVEL Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CONTA_RESPONSAVEL@orahlg01
;

Prompt ReCriando tabela:TRR_CONTRATOSERVICO_CUPOM
create table dsv_suat.TRR_CONTRATOSERVICO_CUPOM Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CONTRATOSERVICO_CUPOM@orahlg01
;

Prompt ReCriando tabela:TRR_CONTRATO_COBRANCA
create table dsv_suat.TRR_CONTRATO_COBRANCA Tablespace SUAT_BIG_DATA nologging as
select * from dsv_suat.TRR_CONTRATO_COBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_CONTRATO_SERVICO
create table dsv_suat.TRR_CONTRATO_SERVICO Tablespace SUAT_BIG_DATA nologging as
select * from dsv_suat.TRR_CONTRATO_SERVICO@orahlg01
;

Prompt ReCriando tabela:TRR_CONVENIO
create table dsv_suat.TRR_CONVENIO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CONVENIO@orahlg01
;

Prompt ReCriando tabela:TRR_CONVENIO_CLASSEPACOTE
create table dsv_suat.TRR_CONVENIO_CLASSEPACOTE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CONVENIO_CLASSEPACOTE@orahlg01
;

Prompt ReCriando tabela:TRR_CONVENIO_MODCOBRANCA
create table dsv_suat.TRR_CONVENIO_MODCOBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CONVENIO_MODCOBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_CONVENIO_PROMOCAO
create table dsv_suat.TRR_CONVENIO_PROMOCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CONVENIO_PROMOCAO@orahlg01
;

Prompt ReCriando tabela:TRR_CUPOM
create table dsv_suat.TRR_CUPOM Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_CUPOM@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_BAIRRO
create table dsv_suat.TRR_DNE_BAIRRO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_BAIRRO@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_BAIRRO_DIFF
create table dsv_suat.TRR_DNE_BAIRRO_DIFF Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_BAIRRO_DIFF@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_BAIRRO_FAIXACEP
create table dsv_suat.TRR_DNE_BAIRRO_FAIXACEP Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_BAIRRO_FAIXACEP@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_BAIRRO_FAIXACEP_DIFF
create table dsv_suat.TRR_DNE_BAIRRO_FAIXACEP_DIFF Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_BAIRRO_FAIXACEP_DIFF@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_BAIRRO_FAIXACEP_LOAD
create table dsv_suat.TRR_DNE_BAIRRO_FAIXACEP_LOAD Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_BAIRRO_FAIXACEP_LOAD@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_BAIRRO_LOAD
create table dsv_suat.TRR_DNE_BAIRRO_LOAD Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_BAIRRO_LOAD@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_LOCALIDADE
create table dsv_suat.TRR_DNE_LOCALIDADE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_LOCALIDADE@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_LOCALIDADE_DIFF
create table dsv_suat.TRR_DNE_LOCALIDADE_DIFF Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_LOCALIDADE_DIFF@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_LOCALIDADE_FAIXACEP
create table dsv_suat.TRR_DNE_LOCALIDADE_FAIXACEP Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_LOCALIDADE_FAIXACEP@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_LOCALIDADE_LOAD
create table dsv_suat.TRR_DNE_LOCALIDADE_LOAD Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_LOCALIDADE_LOAD@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_LOCAL_FAIXACEP_DIFF
create table dsv_suat.TRR_DNE_LOCAL_FAIXACEP_DIFF Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_LOCAL_FAIXACEP_DIFF@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_LOCAL_FAIXACEP_LOAD
create table dsv_suat.TRR_DNE_LOCAL_FAIXACEP_LOAD Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_LOCAL_FAIXACEP_LOAD@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_LOGRADOURO
create table dsv_suat.TRR_DNE_LOGRADOURO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_LOGRADOURO@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_LOGRADOURO_DIFF
create table dsv_suat.TRR_DNE_LOGRADOURO_DIFF Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_LOGRADOURO_DIFF@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_LOGRADOURO_LOAD
create table dsv_suat.TRR_DNE_LOGRADOURO_LOAD Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_LOGRADOURO_LOAD@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_PAIS
create table dsv_suat.TRR_DNE_PAIS Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_PAIS@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_PAIS_DIFF
create table dsv_suat.TRR_DNE_PAIS_DIFF Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_PAIS_DIFF@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_PAIS_LOAD
create table dsv_suat.TRR_DNE_PAIS_LOAD Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_PAIS_LOAD@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_PATENTE_TITULO
create table dsv_suat.TRR_DNE_PATENTE_TITULO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_PATENTE_TITULO@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_PATENTE_TITULO_DIFF
create table dsv_suat.TRR_DNE_PATENTE_TITULO_DIFF Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_PATENTE_TITULO_DIFF@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_PATENTE_TITULO_LOAD
create table dsv_suat.TRR_DNE_PATENTE_TITULO_LOAD Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_PATENTE_TITULO_LOAD@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_TIPO_LOGRADOURO
create table dsv_suat.TRR_DNE_TIPO_LOGRADOURO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_TIPO_LOGRADOURO@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_TIPO_LOGRADOURO_DIFF
create table dsv_suat.TRR_DNE_TIPO_LOGRADOURO_DIFF Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_TIPO_LOGRADOURO_DIFF@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_TIPO_LOGRADOURO_LOAD
create table dsv_suat.TRR_DNE_TIPO_LOGRADOURO_LOAD Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_TIPO_LOGRADOURO_LOAD@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_UF
create table dsv_suat.TRR_DNE_UF Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_UF@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_UF_DIFF
create table dsv_suat.TRR_DNE_UF_DIFF Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_UF_DIFF@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_UF_FAIXACEP
create table dsv_suat.TRR_DNE_UF_FAIXACEP Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_UF_FAIXACEP@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_UF_FAIXACEP_DIFF
create table dsv_suat.TRR_DNE_UF_FAIXACEP_DIFF Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_UF_FAIXACEP_DIFF@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_UF_FAIXACEP_LOAD
create table dsv_suat.TRR_DNE_UF_FAIXACEP_LOAD Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_UF_FAIXACEP_LOAD@orahlg01
;

Prompt ReCriando tabela:TRR_DNE_UF_LOAD
create table dsv_suat.TRR_DNE_UF_LOAD Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DNE_UF_LOAD@orahlg01
;

Prompt ReCriando tabela:TRR_DOMINIO
create table dsv_suat.TRR_DOMINIO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DOMINIO@orahlg01
;

Prompt ReCriando tabela:TRR_DOMINIO_CARACTERISTICA
create table dsv_suat.TRR_DOMINIO_CARACTERISTICA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_DOMINIO_CARACTERISTICA@orahlg01
;

Prompt ReCriando tabela:TRR_EMAIL_TELEFONICA_FIXA
create table dsv_suat.TRR_EMAIL_TELEFONICA_FIXA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_EMAIL_TELEFONICA_FIXA@orahlg01
;

Prompt ReCriando tabela:TRR_ENTIDADE
create table dsv_suat.TRR_ENTIDADE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_ENTIDADE@orahlg01
;

Prompt ReCriando tabela:TRR_ENTIDADE_CONJOPER
create table dsv_suat.TRR_ENTIDADE_CONJOPER Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_ENTIDADE_CONJOPER@orahlg01
;

Prompt ReCriando tabela:TRR_EQUIPE
create table dsv_suat.TRR_EQUIPE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_EQUIPE@orahlg01
;

Prompt ReCriando tabela:TRR_ETAPASERVICO_RETORNO
create table dsv_suat.TRR_ETAPASERVICO_RETORNO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_ETAPASERVICO_RETORNO@orahlg01
;

Prompt ReCriando tabela:TRR_ETAPA_CICLO
create table dsv_suat.TRR_ETAPA_CICLO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_ETAPA_CICLO@orahlg01
;

Prompt ReCriando tabela:TRR_ETAPA_SERVICO
create table dsv_suat.TRR_ETAPA_SERVICO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_ETAPA_SERVICO@orahlg01
;

Prompt ReCriando tabela:TRR_EXPFATCOB_CONTA
create table dsv_suat.TRR_EXPFATCOB_CONTA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_EXPFATCOB_CONTA@orahlg01
;

Prompt ReCriando tabela:TRR_EXPFATCOB_CONTRATO
create table dsv_suat.TRR_EXPFATCOB_CONTRATO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_EXPFATCOB_CONTRATO@orahlg01
;

Prompt ReCriando tabela:TRR_FAMILIA_PACOTE
create table dsv_suat.TRR_FAMILIA_PACOTE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_FAMILIA_PACOTE@orahlg01
;

Prompt ReCriando tabela:TRR_FORMA_COBRANCA
create table dsv_suat.TRR_FORMA_COBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_FORMA_COBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_GRUPONAMESPACE_VALORATRIB
create table dsv_suat.TRR_GRUPONAMESPACE_VALORATRIB Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_GRUPONAMESPACE_VALORATRIB@orahlg01
;

Prompt ReCriando tabela:TRR_GRUPOPOP_POP
create table dsv_suat.TRR_GRUPOPOP_POP Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_GRUPOPOP_POP@orahlg01
;

Prompt ReCriando tabela:TRR_GRUPO_CIDADE
create table dsv_suat.TRR_GRUPO_CIDADE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_GRUPO_CIDADE@orahlg01
;

Prompt ReCriando tabela:TRR_GRUPO_CONTA
create table dsv_suat.TRR_GRUPO_CONTA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_GRUPO_CONTA@orahlg01
;

Prompt ReCriando tabela:TRR_GRUPO_NAMESPACE
create table dsv_suat.TRR_GRUPO_NAMESPACE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_GRUPO_NAMESPACE@orahlg01
;

Prompt ReCriando tabela:TRR_GRUPO_POP
create table dsv_suat.TRR_GRUPO_POP Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_GRUPO_POP@orahlg01
;

Prompt ReCriando tabela:TRR_GRUPO_TIPOPRELANC
create table dsv_suat.TRR_GRUPO_TIPOPRELANC Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_GRUPO_TIPOPRELANC@orahlg01
;

Prompt ReCriando tabela:TRR_HISTORICO_MODCOBRANCA
create table dsv_suat.TRR_HISTORICO_MODCOBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_HISTORICO_MODCOBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_HISTORICO_PERFILCOMERC
create table dsv_suat.TRR_HISTORICO_PERFILCOMERC Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_HISTORICO_PERFILCOMERC@orahlg01
;

Prompt ReCriando tabela:TRR_HISTORICO_PROMOCAO
create table dsv_suat.TRR_HISTORICO_PROMOCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_HISTORICO_PROMOCAO@orahlg01
;

Prompt ReCriando tabela:TRR_HISTORICO_SENHA
create table dsv_suat.TRR_HISTORICO_SENHA Tablespace SUAT_BIG_DATA nologging as
select * from dsv_suat.TRR_HISTORICO_SENHA@orahlg01
;

Prompt ReCriando tabela:TRR_INFORMACAO_COBRANCA
create table dsv_suat.TRR_INFORMACAO_COBRANCA Tablespace SUAT_BIG_DATA nologging as
select * from dsv_suat.TRR_INFORMACAO_COBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_INSTITUICAO_COBRANCA
create table dsv_suat.TRR_INSTITUICAO_COBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_INSTITUICAO_COBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_INTEGRANTE_EQUIPE
create table dsv_suat.TRR_INTEGRANTE_EQUIPE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_INTEGRANTE_EQUIPE@orahlg01
;

Prompt ReCriando tabela:TRR_INTERFACE_VENDA
create table dsv_suat.TRR_INTERFACE_VENDA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_INTERFACE_VENDA@orahlg01
;

Prompt ReCriando tabela:TRR_INTERFVENDA_MOTIVOSTATUS
create table dsv_suat.TRR_INTERFVENDA_MOTIVOSTATUS Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_INTERFVENDA_MOTIVOSTATUS@orahlg01
;

Prompt ReCriando tabela:TRR_LANCAMENTO
create table dsv_suat.TRR_LANCAMENTO Tablespace SUAT_BIG_DATA nologging as
select * from dsv_suat.TRR_LANCAMENTO@orahlg01
;

Prompt ReCriando tabela:TRR_LINHANEGOCIO_SERVICO
create table dsv_suat.TRR_LINHANEGOCIO_SERVICO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_LINHANEGOCIO_SERVICO@orahlg01
;

Prompt ReCriando tabela:TRR_LINHANEGOCIO_VARREGISTRO
create table dsv_suat.TRR_LINHANEGOCIO_VARREGISTRO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_LINHANEGOCIO_VARREGISTRO@orahlg01
;

Prompt ReCriando tabela:TRR_LINHA_NEGOCIO
create table dsv_suat.TRR_LINHA_NEGOCIO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_LINHA_NEGOCIO@orahlg01
;

Prompt ReCriando tabela:TRR_LOG_ERROTRANSACAO
create table dsv_suat.TRR_LOG_ERROTRANSACAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_LOG_ERROTRANSACAO@orahlg01
;

Prompt ReCriando tabela:TRR_LOG_OPERACAO
create table dsv_suat.TRR_LOG_OPERACAO Tablespace SUAT_LOG_DATA nologging as
select * from dsv_suat.TRR_LOG_OPERACAO@orahlg01 where 1<>1
;

CREATE INDEX "DSV_SUAT"."LOOP_ENTI_FK_I" ON "DSV_SUAT"."TRR_LOG_OPERACAO" ("ID_ENTIDADE")
  TABLESPACE "SUAT_LOG_INDX";

CREATE INDEX "DSV_SUAT"."LOOP_NR_VALOR_CHAVE_IDENT_I" ON "DSV_SUAT"."TRR_LOG_OPERACAO"
("NR_VALOR_CHAVE", "ID_ENTIDADE")
  TABLESPACE "SUAT_LOG_INDX";

CREATE UNIQUE INDEX "DSV_SUAT"."LOOP_PK" ON "DSV_SUAT"."TRR_LOG_OPERACAO"
("NR_LOG_OPERACAO", "ID_REGISTRO_OPERACAO", "ID_ENTIDADE", "DT_REGISTRO_OPERACAO")
  TABLESPACE "SUAT_LOG_INDX";

CREATE INDEX "DSV_SUAT"."LOOP_REOP_FK_I" ON "DSV_SUAT"."TRR_LOG_OPERACAO"
("ID_REGISTRO_OPERACAO", "DT_REGISTRO_OPERACAO")
  TABLESPACE "SUAT_LOG_INDX";


Prompt ReCriando tabela:TRR_LOG_TRANSACAO
create table dsv_suat.TRR_LOG_TRANSACAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_LOG_TRANSACAO@orahlg01
;

Prompt ReCriando tabela:TRR_MIGRACAO_AOL
create table dsv_suat.TRR_MIGRACAO_AOL Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_MIGRACAO_AOL@orahlg01
;

Prompt ReCriando tabela:TRR_MODALIDADE_COBRANCA
create table dsv_suat.TRR_MODALIDADE_COBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_MODALIDADE_COBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_MODCOBRANCA_PROMOCAO
create table dsv_suat.TRR_MODCOBRANCA_PROMOCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_MODCOBRANCA_PROMOCAO@orahlg01
;

Prompt ReCriando tabela:TRR_MODCOBRANCA_TIPOCOBRANCA
create table dsv_suat.TRR_MODCOBRANCA_TIPOCOBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_MODCOBRANCA_TIPOCOBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_MOTIVOSTATUS_PERFILCOMERC
create table dsv_suat.TRR_MOTIVOSTATUS_PERFILCOMERC Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_MOTIVOSTATUS_PERFILCOMERC@orahlg01
;

Prompt ReCriando tabela:TRR_MOTIVO_STATUS
create table dsv_suat.TRR_MOTIVO_STATUS Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_MOTIVO_STATUS@orahlg01
;

Prompt ReCriando tabela:TRR_MV_CARAC_ESPECIFICA
create table dsv_suat.TRR_MV_CARAC_ESPECIFICA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_MV_CARAC_ESPECIFICA@orahlg01
;

Prompt ReCriando tabela:TRR_MV_MOTIVO_STATUS_ATIVO
create table dsv_suat.TRR_MV_MOTIVO_STATUS_ATIVO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_MV_MOTIVO_STATUS_ATIVO@orahlg01
;

Prompt ReCriando tabela:TRR_MV_VALOR_CARACTERISTICAS
create table dsv_suat.TRR_MV_VALOR_CARACTERISTICAS Tablespace SUAT_TMP_DATA nologging as
select * from dsv_suat.TRR_MV_VALOR_CARACTERISTICAS@orahlg01
;

Prompt ReCriando tabela:TRR_NAMESPACE
create table dsv_suat.TRR_NAMESPACE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_NAMESPACE@orahlg01
;

Prompt ReCriando tabela:TRR_NAMESPACE_VALORATRIB
create table dsv_suat.TRR_NAMESPACE_VALORATRIB Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_NAMESPACE_VALORATRIB@orahlg01
;

Prompt ReCriando tabela:TRR_NEWSLETTER
create table dsv_suat.TRR_NEWSLETTER Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_NEWSLETTER@orahlg01
;

Prompt ReCriando tabela:TRR_NIC
create table dsv_suat.TRR_NIC Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_NIC@orahlg01
;

Prompt ReCriando tabela:TRR_OCORRENCIA_ETAPASERVICO
create table dsv_suat.TRR_OCORRENCIA_ETAPASERVICO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_OCORRENCIA_ETAPASERVICO@orahlg01
;

Prompt ReCriando tabela:TRR_OLD_AUMENTOPRECO_CLIENTE
create table dsv_suat.TRR_OLD_AUMENTOPRECO_CLIENTE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_OLD_AUMENTOPRECO_CLIENTE@orahlg01
;

Prompt ReCriando tabela:TRR_OPERACAO
create table dsv_suat.TRR_OPERACAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_OPERACAO@orahlg01
;

Prompt ReCriando tabela:TRR_PACOTECOMERC_PERFILSERV
create table dsv_suat.TRR_PACOTECOMERC_PERFILSERV Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PACOTECOMERC_PERFILSERV@orahlg01
;

Prompt ReCriando tabela:TRR_PACOTECOMERC_PRELANC
create table dsv_suat.TRR_PACOTECOMERC_PRELANC Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PACOTECOMERC_PRELANC@orahlg01
;

Prompt ReCriando tabela:TRR_PACOTECOMERC_SERVICO
create table dsv_suat.TRR_PACOTECOMERC_SERVICO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PACOTECOMERC_SERVICO@orahlg01
;

Prompt ReCriando tabela:TRR_PACOTECOMERC_SERVICO_ERR
create table dsv_suat.TRR_PACOTECOMERC_SERVICO_ERR Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PACOTECOMERC_SERVICO_ERR@orahlg01
;

Prompt ReCriando tabela:TRR_PACOTE_COMERCIAL
create table dsv_suat.TRR_PACOTE_COMERCIAL Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PACOTE_COMERCIAL@orahlg01
;

Prompt ReCriando tabela:TRR_PARAMETRO_SISTEMA
create table dsv_suat.TRR_PARAMETRO_SISTEMA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PARAMETRO_SISTEMA@orahlg01
;

Prompt ReCriando tabela:TRR_PERFILCOMERC_SUBMOTIVO
create table dsv_suat.TRR_PERFILCOMERC_SUBMOTIVO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PERFILCOMERC_SUBMOTIVO@orahlg01
;

Prompt ReCriando tabela:TRR_PERFILCOMERC_TELTERRA
create table dsv_suat.TRR_PERFILCOMERC_TELTERRA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PERFILCOMERC_TELTERRA@orahlg01
;

Prompt ReCriando tabela:TRR_PERFIL_COBRANCA
create table dsv_suat.TRR_PERFIL_COBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PERFIL_COBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_PERFIL_COMERCIAL
create table dsv_suat.TRR_PERFIL_COMERCIAL Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PERFIL_COMERCIAL@orahlg01
;

Prompt ReCriando tabela:TRR_PERFIL_COMPORTAMENTAL
create table dsv_suat.TRR_PERFIL_COMPORTAMENTAL Tablespace SUAT_BIG_DATA nologging as
select * from dsv_suat.TRR_PERFIL_COMPORTAMENTAL@orahlg01
;

Prompt ReCriando tabela:TRR_PERFIL_SERVICO
create table dsv_suat.TRR_PERFIL_SERVICO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PERFIL_SERVICO@orahlg01
;

Prompt ReCriando tabela:TRR_PERGUNTA
create table dsv_suat.TRR_PERGUNTA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PERGUNTA@orahlg01
;

Prompt ReCriando tabela:TRR_PERIODO_COBRANCA
create table dsv_suat.TRR_PERIODO_COBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PERIODO_COBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_PERMISSAO_CONTA
create table dsv_suat.TRR_PERMISSAO_CONTA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PERMISSAO_CONTA@orahlg01
;

Prompt ReCriando tabela:TRR_PERMISSAO_GRUPOCONTA
create table dsv_suat.TRR_PERMISSAO_GRUPOCONTA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PERMISSAO_GRUPOCONTA@orahlg01
;

Prompt ReCriando tabela:TRR_POP
create table dsv_suat.TRR_POP Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_POP@orahlg01
;

Prompt ReCriando tabela:TRR_PRELANCAMENTO_PROMOCAO
create table dsv_suat.TRR_PRELANCAMENTO_PROMOCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PRELANCAMENTO_PROMOCAO@orahlg01
;

Prompt ReCriando tabela:TRR_PRE_LANCAMENTO
create table dsv_suat.TRR_PRE_LANCAMENTO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PRE_LANCAMENTO@orahlg01
;

Prompt ReCriando tabela:TRR_PROFISSAO
create table dsv_suat.TRR_PROFISSAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PROFISSAO@orahlg01
;

Prompt ReCriando tabela:TRR_PROMOCAO
create table dsv_suat.TRR_PROMOCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PROMOCAO@orahlg01
;

Prompt ReCriando tabela:TRR_PROMOCAO_REGRAPROMOCAO
create table dsv_suat.TRR_PROMOCAO_REGRAPROMOCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_PROMOCAO_REGRAPROMOCAO@orahlg01
;

Prompt ReCriando tabela:TRR_REGISTRO_OPERACAO
create table dsv_suat.TRR_REGISTRO_OPERACAO Tablespace SUAT_LOG_DATA nologging as
select * from dsv_suat.TRR_REGISTRO_OPERACAO@orahlg01 where 1<>1
;

CREATE INDEX "DSV_SUAT"."REOP_COOP_FK_I" ON "DSV_SUAT"."TRR_REGISTRO_OPERACAO" ("ID_CONJ_OPERACAO")
  TABLESPACE "SUAT_LOG_INDX";

CREATE INDEX "DSV_SUAT"."REOP_DT_REGISTRO_OPERACAO_I" ON "DSV_SUAT"."TRR_REGISTRO_OPERACAO"
("DT_REGISTRO_OPERACAO")
  TABLESPACE "SUAT_LOG_INDX";

CREATE INDEX "DSV_SUAT"."REOP_LINE_FK_I" ON "DSV_SUAT"."TRR_REGISTRO_OPERACAO"
 ("ID_LINHA_NEGOCIO")
  TABLESPACE "SUAT_LOG_INDX";

CREATE INDEX "DSV_SUAT"."REOP_NAME_FK_I" ON "DSV_SUAT"."TRR_REGISTRO_OPERACAO"
 ("ID_NAMESPACE_OPERADOR")
  TABLESPACE "SUAT_LOG_INDX";

CREATE UNIQUE INDEX "DSV_SUAT"."REOP_PK" ON "DSV_SUAT"."TRR_REGISTRO_OPERACAO"
 ("ID_REGISTRO_OPERACAO", "DT_REGISTRO_OPERACAO")
  TABLESPACE "SUAT_LOG_INDX";


Prompt ReCriando tabela:TRR_REGISTRO_SERVICOCONTA
create table dsv_suat.TRR_REGISTRO_SERVICOCONTA Tablespace SUAT_TRR_REG_SERVICOCONTA_DATA nologging as
select * from dsv_suat.TRR_REGISTRO_SERVICOCONTA@orahlg01
;

Prompt ReCriando tabela:TRR_REGRA_PROMOCAO
create table dsv_suat.TRR_REGRA_PROMOCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_REGRA_PROMOCAO@orahlg01
;

Prompt ReCriando tabela:TRR_REL_GRUPOCIDADE
create table dsv_suat.TRR_REL_GRUPOCIDADE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_REL_GRUPOCIDADE@orahlg01
;

Prompt ReCriando tabela:TRR_REL_GRUPOPOP
create table dsv_suat.TRR_REL_GRUPOPOP Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_REL_GRUPOPOP@orahlg01
;

Prompt ReCriando tabela:TRR_REL_SERVICO
create table dsv_suat.TRR_REL_SERVICO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_REL_SERVICO@orahlg01
;

Prompt ReCriando tabela:TRR_REL_TIPOGRUPOCIDADE
create table dsv_suat.TRR_REL_TIPOGRUPOCIDADE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_REL_TIPOGRUPOCIDADE@orahlg01
;

Prompt ReCriando tabela:TRR_REL_TIPOGRUPOPOP
create table dsv_suat.TRR_REL_TIPOGRUPOPOP Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_REL_TIPOGRUPOPOP@orahlg01
;

Prompt ReCriando tabela:TRR_RESPOSTA
create table dsv_suat.TRR_RESPOSTA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_RESPOSTA@orahlg01
;

Prompt ReCriando tabela:TRR_RES_BAIXA_LANCAMENTO
create table dsv_suat.TRR_RES_BAIXA_LANCAMENTO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_RES_BAIXA_LANCAMENTO@orahlg01
;

Prompt ReCriando tabela:TRR_SERVICO
create table dsv_suat.TRR_SERVICO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_SERVICO@orahlg01
;

Prompt ReCriando tabela:TRR_SPOOLCONTRATO_SISCON
create table dsv_suat.TRR_SPOOLCONTRATO_SISCON Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_SPOOLCONTRATO_SISCON@orahlg01 where 1<>1
;

Prompt ReCriando tabela:TRR_STATUS
create table dsv_suat.TRR_STATUS Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_STATUS@orahlg01
;

Prompt ReCriando tabela:TRR_SUBMOTIVO_STATUS
create table dsv_suat.TRR_SUBMOTIVO_STATUS Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_SUBMOTIVO_STATUS@orahlg01
;

Prompt ReCriando tabela:TRR_TELEFONE_TERRA
create table dsv_suat.TRR_TELEFONE_TERRA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TELEFONE_TERRA@orahlg01
;

Prompt ReCriando tabela:TRR_TEMPLATE_EMAIL
create table dsv_suat.TRR_TEMPLATE_EMAIL Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TEMPLATE_EMAIL@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_CARACSERVICO
create table dsv_suat.TRR_TIPO_CARACSERVICO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_CARACSERVICO@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_CARACTERISTICA
create table dsv_suat.TRR_TIPO_CARACTERISTICA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_CARACTERISTICA@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_CICLO
create table dsv_suat.TRR_TIPO_CICLO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_CICLO@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_COBRANCA
create table dsv_suat.TRR_TIPO_COBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_COBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_COMPORTAMENTAL
create table dsv_suat.TRR_TIPO_COMPORTAMENTAL Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_COMPORTAMENTAL@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_CONTATO
create table dsv_suat.TRR_TIPO_CONTATO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_CONTATO@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_ERROTRANSACAO
create table dsv_suat.TRR_TIPO_ERROTRANSACAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_ERROTRANSACAO@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_GRUPOCIDADE
create table dsv_suat.TRR_TIPO_GRUPOCIDADE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_GRUPOCIDADE@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_GRUPOPOP
create table dsv_suat.TRR_TIPO_GRUPOPOP Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_GRUPOPOP@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_PRELANCAMENTO
create table dsv_suat.TRR_TIPO_PRELANCAMENTO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_PRELANCAMENTO@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_PROMOCAO
create table dsv_suat.TRR_TIPO_PROMOCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_PROMOCAO@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_RELACAO
create table dsv_suat.TRR_TIPO_RELACAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_RELACAO@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_TELEFONE
create table dsv_suat.TRR_TIPO_TELEFONE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_TELEFONE@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_TRANSACAO
create table dsv_suat.TRR_TIPO_TRANSACAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_TRANSACAO@orahlg01
;

Prompt ReCriando tabela:TRR_TIPO_VENDA
create table dsv_suat.TRR_TIPO_VENDA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_TIPO_VENDA@orahlg01
;

Prompt ReCriando tabela:TRR_UNIDADE_METRICA
create table dsv_suat.TRR_UNIDADE_METRICA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_UNIDADE_METRICA@orahlg01
;

Prompt ReCriando tabela:TRR_UNIDADE_TEMPO
create table dsv_suat.TRR_UNIDADE_TEMPO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_UNIDADE_TEMPO@orahlg01
;

Prompt ReCriando tabela:TRR_VALOR_CARACTERISTICA
create table dsv_suat.TRR_VALOR_CARACTERISTICA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VALOR_CARACTERISTICA@orahlg01
;

Prompt ReCriando tabela:TRR_VALOR_COMPORTAMENTAL
create table dsv_suat.TRR_VALOR_COMPORTAMENTAL Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VALOR_COMPORTAMENTAL@orahlg01
;

Prompt ReCriando tabela:TRR_VARIAVEL_REGISTRO
create table dsv_suat.TRR_VARIAVEL_REGISTRO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VARIAVEL_REGISTRO@orahlg01
;

Prompt ReCriando tabela:TRR_VENCIMENTO_COBRANCA
create table dsv_suat.TRR_VENCIMENTO_COBRANCA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VENCIMENTO_COBRANCA@orahlg01
;

Prompt ReCriando tabela:TRR_VENDA_ANTECIPADA
create table dsv_suat.TRR_VENDA_ANTECIPADA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VENDA_ANTECIPADA@orahlg01
;

Prompt ReCriando tabela:TRR_VERIO_DEPARA
create table dsv_suat.TRR_VERIO_DEPARA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VERIO_DEPARA@orahlg01
;

Prompt ReCriando tabela:TRR_VERIO_DEPARA_ERRO
create table dsv_suat.TRR_VERIO_DEPARA_ERRO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VERIO_DEPARA_ERRO@orahlg01
;

Prompt ReCriando tabela:TRR_VERSAO_DISCADOR
create table dsv_suat.TRR_VERSAO_DISCADOR Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VERSAO_DISCADOR@orahlg01
;

Prompt ReCriando tabela:TRR_VM_CLASSE_CACHE
create table dsv_suat.TRR_VM_CLASSE_CACHE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_CLASSE_CACHE@orahlg01
;

Prompt ReCriando tabela:TRR_VM_DICIONARIO
create table dsv_suat.TRR_VM_DICIONARIO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_DICIONARIO@orahlg01
;

Prompt ReCriando tabela:TRR_VM_DICIONARIO_LOG
create table dsv_suat.TRR_VM_DICIONARIO_LOG Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_DICIONARIO_LOG@orahlg01
;

Prompt ReCriando tabela:TRR_VM_ERRO
create table dsv_suat.TRR_VM_ERRO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_ERRO@orahlg01
;

Prompt ReCriando tabela:TRR_VM_ESQUEMA
create table dsv_suat.TRR_VM_ESQUEMA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_ESQUEMA@orahlg01
;

Prompt ReCriando tabela:TRR_VM_EVENTO
create table dsv_suat.TRR_VM_EVENTO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_EVENTO@orahlg01
;

Prompt ReCriando tabela:TRR_VM_EVENTO_PRECEDENCIA
create table dsv_suat.TRR_VM_EVENTO_PRECEDENCIA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_EVENTO_PRECEDENCIA@orahlg01
;

Prompt ReCriando tabela:TRR_VM_FUNCAO
create table dsv_suat.TRR_VM_FUNCAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_FUNCAO@orahlg01
;

Prompt ReCriando tabela:TRR_VM_LINGUAGEM
create table dsv_suat.TRR_VM_LINGUAGEM Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_LINGUAGEM@orahlg01
;

Prompt ReCriando tabela:TRR_VM_MODULO
create table dsv_suat.TRR_VM_MODULO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_MODULO@orahlg01
;

Prompt ReCriando tabela:TRR_VM_MODULO_ESQUEMA
create table dsv_suat.TRR_VM_MODULO_ESQUEMA Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_MODULO_ESQUEMA@orahlg01
;

Prompt ReCriando tabela:TRR_VM_MODULO_EVENTO
create table dsv_suat.TRR_VM_MODULO_EVENTO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_MODULO_EVENTO@orahlg01
;

Prompt ReCriando tabela:TRR_VM_OPERACAO
create table dsv_suat.TRR_VM_OPERACAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_OPERACAO@orahlg01
;

Prompt ReCriando tabela:TRR_VM_PRIORIDADE
create table dsv_suat.TRR_VM_PRIORIDADE Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_PRIORIDADE@orahlg01
;

Prompt ReCriando tabela:TRR_VM_TRANSACAO
create table dsv_suat.TRR_VM_TRANSACAO Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_TRANSACAO@orahlg01
;

Prompt ReCriando tabela:TRR_VM_TRANSACAO_MV
create table dsv_suat.TRR_VM_TRANSACAO_MV Tablespace SUAT_DATA nologging as
select * from dsv_suat.TRR_VM_TRANSACAO_MV@orahlg01
;

spool off;
exit;
