undef own
undef TRIG
set long 1000000
select TRIGGER_BODY from dba_triggers
where owner = upper('&own')
  and TRIGGER_NAME = upper('&TRIG')
/

