select 'alter tablespace '||tablespace_name||' coalesce; ' from dba_tablespaces
/
