col name for a40;
col value for a40;
select name,value,ISDEFAULT,ISSES_MODIFIABLE,ISSYS_MODIFIABLE        from v$parameter where name like '%&string%';
