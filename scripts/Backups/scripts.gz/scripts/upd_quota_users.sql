-- Update those records which the quota has been modified.
--
set echo on
set timing on
set serveroutput on
spool upd_quota_users.log
alter session set sort_area_size = 30000000;

declare

   cursor quota_dif_cur is
   select /*+ use_hash(a,b,c,d,e) */
          a.snh_id, a.obpv_id, b.quota, d.email, e.cod_dominio
     from bd_central.trr_obpv_users a,
	      ciut.trr_usr_assinantes b,
		  bd_central.trr_obp_vars c,
		  bd_central.trr_senhas d,
		  bd_central.trr_cod_dominios e 
	where a.snh_id  = b.snh_id
	  and a.valor  <> b.quota
	  and a.obpv_id = c.obpv_id
	  and c.nome    = 'quota_caixa'
	  and a.snh_id  = d.snh_id
	  and d.cdom_id = e.cdom_id;
   --
   lv_count integer := 0;
--
begin

   for C in quota_dif_cur	  
   loop
   --
      update bd_central.trr_obpv_users
	     set valor   = C.quota
	   where snh_id  = C.snh_id
	     and obpv_id = C.obpv_id;
	  --
       insert into ajustabd.trr_expired_users (email, snh_id, brand, dt_ins)
	  values (C.email, C.snh_id, C.cod_dominio, sysdate);
	  --
       lv_count := lv_count + 1;
   --
   end loop;
   --
   commit;
   --
   dbms_output.put_line ('Final com sucesso. Linhas alteradas:' || lv_count);
   -- 
exception when others then
  rollback;
  raise;
end;
--
/
spool off;
exit;

