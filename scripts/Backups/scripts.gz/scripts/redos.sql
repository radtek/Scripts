select * from v$log;
Select * from v$logfile;
