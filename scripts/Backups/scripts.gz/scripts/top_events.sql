-- top events <nro. de dias passados> < nro de eventos >
set verify off
set feed off
set trimspool on
set lines 1000
set serveroutput on size 1000000

set termout off
col hoje new_value hoje
select 'rel1\top_events' || to_char(sysdate,'yyyymmddhh24mi') || '.txt' hoje
from dual;
spool &hoje
set termout on

declare
   --
   snap_ini         number;
   dt_snap_ini      date;
   snap_fim         number;
   dt_snap_fim      date;
   v_bd_id          number;     -- Id do banco
   v_instance       number;     -- Nro da instance
   v_elapse_seg     number;     -- Tempo em segundos entre os dois snaps
   v_redo_nowait    number;
   v_sort_mem       number;
   v_db_name        varchar2(40);
   --
   -- Par�metros para a chamada da package statspack.stats_change
   --
   lhtr number;
   bfwt number;
   tran number;
   chng number;
   ucal number;
   urol number;
   rsiz number;
   phyr number;
   phyw number;
   prse number;
   hprs number;
   recr number;
   gets number;
   rlsr number;
   rent number;
   srtm number;
   srtd number;
   srtr number;
   strn number;
   call number;
   lhr  number;
   sp   varchar2(512);
   bc   varchar2(512);
   lb   varchar2(512);
   bs   varchar2(512);
   twt  number;
   --
begin
   ------------------------------
   -- Pega os dois �ltimos snaps
   ------------------------------
   dbms_output.enable (100000000);
   --

   begin
     select max(SNAP_ID),max(snap_time)
       into snap_fim,dt_snap_fim
       from STATS$SNAPSHOT;

     select min(SNAP_ID),min(snap_time)
       into snap_ini,dt_snap_ini
       from STATS$SNAPSHOT
      where snap_time >= trunc(sysdate - &1);
   exception
      when no_data_found then
         dbms_output.put_line ('Snap Ini:'|| snap_ini ||' Snap_fim:'|| snap_fim||' DBid:'||v_bd_id||' Instance:'||v_instance);
         raise_application_error (-20002,'N�o foi poss�vel identificar snap inicial e final.');
   end;
   ----------------------
   -- Pega o Id do banco
   ----------------------
   select dbid, name into v_bd_id, v_db_name from v$database;
   ------------------------------------------------
   -- Pega o nro da instance (para parallel server)
   ------------------------------------------------
   select instance_number into v_instance from v$instance;
   ------------------------------------------------
   -- Pega o tempo (em segundos) entre os dois snaps.
   -- E a data do startup do banco
   ------------------------------------------------
   begin
    select round(((e.snap_time - b.snap_time) * 1440 * 60), 0)
      into v_elapse_seg
      from stats$snapshot b, stats$snapshot e
    where b.snap_id         = snap_ini
      and e.snap_id         = snap_fim
      and b.dbid            = v_bd_id
      and e.dbid            = v_bd_id
      and b.instance_number = v_instance
      and e.instance_number = v_instance
      and b.startup_time    = e.startup_time
      and b.snap_time       < e.snap_time;
   exception
    when no_data_found then
      dbms_output.put_line ('Snap Ini:'|| snap_ini ||' Snap_fim:'|| snap_fim||' DBid:'||v_bd_id||' Instance:'||v_instance);
      raise_application_error (-20001,'N�o � poss�vel buscar dados para os snaps informados.');
   end;
   --
   -- Chama a package que calcula os valores.
   --
   STATSPACK.STAT_CHANGES
   ( snap_ini,  snap_fim
   , lhtr, bfwt, tran, chng, ucal, urol, rsiz, phyr, phyw
   , prse, hprs
   , recr, gets, rlsr, rent, srtm, srtd, srtr, strn
   , lhr,  bc,   sp, lb, bs,   twt
   );
   -------------------------------
   -- Mostra um cabe�alho
   -------------------------------
   dbms_output.put_line ('--------------------------------------------------------------------------------');
   dbms_output.put_line ('Base:'||v_db_name||' Data/hora coleta:'|| to_char(sysdate,'dd/mm/yyyy hh24:mi:ss'));
   dbms_output.put_line ('SnapIni:'||snap_ini || '(' || to_char(dt_snap_ini,'dd/mm/yyyy hh24:mi:ss') || ')');
   dbms_output.put_line ('SnapFim:'||snap_fim || '(' || to_char(dt_snap_fim,'dd/mm/yyyy hh24:mi:ss') || ')');
   dbms_output.put_line ('Tempo entre Snaps: '|| to_char(v_elapse_seg/3600,'99999D9999')||' horas.');
   dbms_output.put_line ('--------------------------------------------------------------------------------');
   -------------------------
   -- Top 5 events
   -------------------------
   dbms_output.put_line ('Top &2 events.');
   dbms_output.put_line ('*********************************************************************');
   dbms_output.put_line ('Event                                          Tempo (cs)       Ocorr�ncias            Pct/Total');
   dbms_output.put_line ('------------------------------------------------------------------------------------------------');
   for c in
   (select event
       , waits
       , time
       , round(pctwtt,2) pctwtt
    from (select e.event                               event
               , e.total_waits - nvl(b.total_waits,0)  waits
               , e.time_waited - nvl(b.time_waited,0)  time
               , decode(twt, 0, 0,
                  100*((e.time_waited - nvl(b.time_waited,0))/twt))  pctwtt
            from stats$system_event b
               , stats$system_event e
           where b.snap_id             = snap_ini
             and e.snap_id             = snap_fim
             and b.dbid(+)             = v_bd_id
             and e.dbid                = v_bd_id
             and b.instance_number (+) = v_instance
             and e.instance_number     = v_instance
             and b.event(+)            = e.event
             and e.total_waits         > nvl(b.total_waits,0)
             and e.event not in
                 ( select event
                     from stats$idle_event
                 )
             order by time desc, waits desc
         )
   where rownum < &2+1)
   loop
     --
     dbms_output.put_line (rpad(C.event,30,' ') ||' '
                         ||to_char(C.time  ,'999,999,999,999,999') ||' '
                         ||to_char(C.waits ,'999,999,999,999,999') ||' '
                         ||to_char(C.pctwtt,'999,999,999,999,999'));
     --
   end loop;
   dbms_output.put_line ('*********************************************************************');
end;
/
set feed on
set verify on
spool off
