/*
  CREDITOS VALOR                            COUNT(*)
---------- ------------------------------ ----------
         0 0_OPEN                                 25
         0 1_BASIC                                59
         5 0                                     725
         5 0_OPEN                            2511443
         5 1_BASIC                           3901518
         5 2_PREMIUM                              17
        10 0_OPEN                                  1
        10 1_BASIC                               906
        10 2_PREMIUM                               2
        15 0_OPEN                                 10
        15 1_BASIC                                32

  CREDITOS VALOR                            COUNT(*)
---------- ------------------------------ ----------
        15 2_PREMIUM                           14287
        25 2_PREMIUM                              18

1 - Alterar a sp do SCD trr_fnc_autoreload_account para desconsiderar saldos de 
    contas com o campo "creditos" zerados
2 - Remover os registros do trr_saldos_contas com "creditos" zerados
3 - Ajustar cr�ditos
	0_OPEN: 10 -> 5
			  15 -> 5
	1_BASIC: 10 -> 5
				15 -> 5
	2_PREMIUM: 5 -> 15
				  10 -> 15
				  25 -> 15

*/

spool update_cred.log
set timing on
set echo on
set serveroutput on size 1000000

alter session set sort_area_size=30000000;
alter session set hash_multiblock_io_count=16;
alter session set db_file_multiblock_read_count=16;
alter session set sort_multiblock_read_count=16;


-- Script para inicializa��o dos cr�ditos de usu�rios
--
declare
	cursor c_usr(p_srv_id in number,
					 p_eve_id in number,
					 p_obpv_id in number) is
		select
				 snh.email,
				 obpv.valor sou_user_type
		from bd_central.trr_senhas snh,
			  bd_central.trr_obpv_users obpv,
			  (select /*+ full(usoc) */
			  			 uscd.snh_id,
			  			 SUM(scon.creditos) creditos
			   from cred_debit.trr_usr_creddeb uscd,
			   	  cred_debit.trr_contas con,
			   	  cred_debit.trr_saldos_contas scon,
			   	  cred_debit.trr_uso_creditos usoc
			  	where con.uscd_id = uscd.uscd_id
			  	and	scon.con_id = con.con_id
			  	and	usoc.con_id = con.con_id
				and	usoc.srv_id = p_srv_id
				and	usoc.eve_id = p_eve_id
				and	con.d_status_conta = 'A'
				and	uscd.snh_id is not null
				group by uscd.snh_id
				) scon2
		where snh.snh_id = obpv.snh_id
		and	scon2.snh_id = snh.snh_id
		and	snh.cdom_id = 1
		and 	obpv.obpv_id = p_obpv_id
		and	((obpv.valor in ('0_OPEN','1_BASIC')
		and	  scon2.creditos in (10,15))
		or		 (obpv.valor = '2_PREMIUM'
		and	  scon2.creditos in (5,10,25)));

    ln_srv_id				number;
    ln_eve_id 				number;
    ln_obpv_id				number;
    v_lines_to_commit 	number := 5000;
    ln_count 				number := 0;
    lv_exit 				varchar2(1) := null;
    ln_num_cred 			number;
    ln_num_ok				number := 0;
    ln_num_nok				number := 0;
    ln_ora_2291			number := 0;
    ln_ret					number;

begin
	select obpv_id
	into ln_obpv_id
	from bd_central.trr_obp_vars
	where nome = 'sou_user_type';
	
	select srv_id
	into ln_srv_id
	from bd_central.trr_servicos
	where servico = 'SMS';
	
	select eve_id
	into ln_eve_id
	from cred_debit.trr_eventos
	where srv_id = ln_srv_id
	and	evento = 'credito_sms';
	
	-- Esse loop foi incluido apenas para tratar os poss�veis ORA-1555 (SNAPSHOT TOO OLD).
	lv_exit := 'N';
	loop
		exit when lv_exit = 'S';
		begin
			ln_ora_2291 := 0;
			for c_usr_rec in c_usr (ln_srv_id, ln_eve_id, ln_obpv_id)
			loop
				if c_usr_rec.sou_user_type = '2_PREMIUM' then
					ln_num_cred := 15;
				else
					ln_num_cred := 5;
				end if;
				begin
					ln_ret := cred_debit.trr_fnc_config_account(
										c_usr_rec.email,
										'terra',
										'SMS',
										'credito_sms',
										NULL,
										NULL,
										NULL,
										NULL,
										ln_num_cred,
										'venda_planopacote',
										sysdate + 30,
										'ajuste_saldo');
					if ln_ret = 0 then
						ln_num_ok := ln_num_ok + 1;
					else
						ln_num_nok := ln_num_nok + 1;
						dbms_output.put_line('erro [' || ln_ret || '] user [' || c_usr_rec.email || ']');
					end if;
				exception
					when others then
						if (sqlcode = -2291) then -- parent key not found
							ln_ora_2291 := ln_ora_2291 + 1;
							rollback;
						else
							raise;
						end if;
				end;

				if (ln_count = v_lines_to_commit) then
					commit;
					ln_count := 0;
				else
					ln_count := ln_count + 1;
				end if;
			end loop;

			commit;
			
			if ln_ora_2291 = 0 then
				lv_exit := 'S';
			else
				dbms_output.put_line('erro ora_2291 [' || ln_ora_2291 || ']');
			end if;

		exception when others then
			if (sqlcode = -1555) then -- snapshot too old
				lv_exit := 'N';
				rollback;
			else
				rollback;
				raise;
			end if;
		end;
	end loop;
	dbms_output.put_line('Total de usu�rios processados = ' || (ln_num_ok+ln_num_nok));
	dbms_output.put_line('Total de usu�rios OK = ' || ln_num_ok);
	dbms_output.put_line('Total de usu�rios NOK = ' || ln_num_nok);
end;
/

exit;
