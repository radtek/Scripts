set echo on
set timing on
set time on

spool copia_spool.log

conn suat/tcdpp6

whenener sqlerror exit 1;

alter session set sort_area_size=100000000;

-- ALTERA PARAMETRO SUAT PARA NAO GRAVAR NA TABELA TRR_SPOOLCONTRATO_SISCON
update trr_parametro_sistema
set de_parametro_sistema = 'N'
where id_linha_negocio = 6
and cd_parametro_sistema = 'CVN_SISCON';
COMMIT;

create table trr_spoolcontrato_siscon_copia Nologging as
select spo.ID_SPOOLCONTRATO_SISCON
	,spo.CD_CONTRATO_COBRANCA
	,spo.ID_CONTA_ADM
	,spo.DE_USERNAME
	,spo.ID_INTENCAO
	,spo.CD_CONVENIO
	,spo.CD_PACOTE_COMERCIAL
	,spo.NM_PACOTE_COMERCIAL
	,spo.VL_PACOTE_COMERCIAL
	,spo.CD_PROMOCAO
	,spo.NM_PROMOCAO
	,spo.CD_CLASSE_SERVICO
	,spo.DS_CLASSE_SERVICO
	,spo.ID_CIDADE
	,spo.TP_ACESSO
	,spo.DT_CADASTRO
	,spo.DT_CANCEL
	,spo.NM_ASSINANTE
	,spo.NM_NAMESPACE
	,spo.NR_IDPERM
	,spo.ID_CONTRATO_SERVICO
	,spo.DT_CADASTRO_SPOOL
	,sysdate as DT_PROC_SPOOL
	,spo.ID_ASSINANTE
	,spo.CD_PERFIL_COMERCIAL
	,spo.CD_POP
	,spo.CD_PROMOCAO_PUBL
	,spo.DT_EXPIRACAO_PROMOCAO
	,spo.CD_TIPO_VENDA_GAT
	,spo.DE_ENDERECO
	,spo.DE_NUMERO
	,spo.DE_COMPLEMENTO
	,spo.DE_BAIRRO
	,spo.DE_CIDADE
	,spo.DE_UF
	,spo.DE_CEP
	,spo.DE_DDD_RES
	,spo.DE_TELEFONE_RES
	,spo.DE_DDD_COM
	,spo.DE_TELEFONE_COM
	,spo.DE_DDD_CEL
	,spo.DE_TELEFONE_CEL
	,spo.DE_CPF_CNPJ
	,spo.DE_RG
	,spo.DS_OBSERVACAO
	,spo.CD_CIDADE
from trr_spoolcontrato_siscon spo
	,trr_assinante ass
where ass.id_assinante = spo.id_assinante
  and ass.id_linha_negocio = 6;

create unique index SUAT.SPSI_PK_new on suat.trr_spoolcontrato_siscon_copia(ID_SPOOLCONTRATO_SISCON)
Tablespace suat_indx Unrecoverable;

Alter table suat.trr_spoolcontrato_siscon_copia add constraint SPSI_PK_new primary key (ID_SPOOLCONTRATO_SISCON);


Analyze table suat.trr_spoolcontrato_siscon_copia estimate statistics sample 10 percent;

Alter table siscon.trr_spoolcontrato_siscon rename to trr_spoolcontrato_siscon_old;
Alter table siscon.trr_spoolcontrato_siscon_copia rename to trr_spoolcontrato_siscon;

Grant select on  siscon.trr_spoolcontrato_siscon to selsuat;


-- HABILITA NOVAMENTE O PARAMETRO NO SUAT PARA VOLTAR A GRAVAR NA TABELA TRR_SPOOLCONTRATO_SISCON
update trr_parametro_sistema
set de_parametro_sistema = 'S'
where id_linha_negocio = 6
and cd_parametro_sistema = 'CVN_SISCON';
COMMIT;

spool off;

