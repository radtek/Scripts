set echo on
set time on
spool cr_tables_iboxnet.log

conn iboxnet/iboxnet

Prompt ReCriando tabela:ALERTS
create table iboxnet.ALERTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ALERTS@orass1
;

Prompt ReCriando tabela:ALERTS_COMPANIES
create table iboxnet.ALERTS_COMPANIES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ALERTS_COMPANIES@orass1
;

Prompt ReCriando tabela:ALERTS_DESTINATIONS
create table iboxnet.ALERTS_DESTINATIONS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ALERTS_DESTINATIONS@orass1
;

Prompt ReCriando tabela:ALERTS_LIMITS
create table iboxnet.ALERTS_LIMITS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ALERTS_LIMITS@orass1
;

Prompt ReCriando tabela:ALERTS_MESSAGES
create table iboxnet.ALERTS_MESSAGES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ALERTS_MESSAGES@orass1 where 1<>1
;

Prompt ReCriando tabela:ALERTS_TYPES
create table iboxnet.ALERTS_TYPES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ALERTS_TYPES@orass1
;

Prompt ReCriando tabela:ALERTS_USAGE
create table iboxnet.ALERTS_USAGE Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ALERTS_USAGE@orass1
;

Prompt ReCriando tabela:ARTISTAS
create table iboxnet.ARTISTAS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ARTISTAS@orass1
;

Prompt ReCriando tabela:ARTISTS
create table iboxnet.ARTISTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ARTISTS@orass1
;

Prompt ReCriando tabela:ATTACHMENTS
create table iboxnet.ATTACHMENTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ATTACHMENTS@orass1
;

Prompt ReCriando tabela:AUDCONS
create table iboxnet.AUDCONS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.AUDCONS@orass1
;

Prompt ReCriando tabela:AUDIENCE
create table iboxnet.AUDIENCE Tablespace  nologging as
select * from iboxnet.AUDIENCE@orass1 where STARTDATE = TRUNC(SYSDATE) - 1
;

Prompt ReCriando tabela:AUDIENCE_NAO_PARTICIONADA
create table iboxnet.AUDIENCE_NAO_PARTICIONADA Tablespace IBOXNET_DATA nologging as
select * from iboxnet.AUDIENCE_NAO_PARTICIONADA@orass1
;

Prompt ReCriando tabela:AUDIT_ACTIONS
create table iboxnet.AUDIT_ACTIONS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.AUDIT_ACTIONS@orass1
;

Prompt ReCriando tabela:AUDIT_DATA
create table iboxnet.AUDIT_DATA Tablespace IBOXNET_DATA nologging as
select * from iboxnet.AUDIT_DATA@orass1
;

Prompt ReCriando tabela:AUD_LIVES
create table iboxnet.AUD_LIVES Tablespace  nologging as
select * from iboxnet.AUD_LIVES@orass1 WHERE STARTDATE = TRUNC(SYSDATE) - 1
;

Prompt ReCriando tabela:AUD_LIVE_NAO_PARTICIONADA
create table iboxnet.AUD_LIVE_NAO_PARTICIONADA Tablespace IBOXNET_DATA nologging as
select * from iboxnet.AUD_LIVE_NAO_PARTICIONADA@orass1
;

Prompt ReCriando tabela:AUD_MMEDIAS
create table iboxnet.AUD_MMEDIAS Tablespace  nologging as
select * from iboxnet.AUD_MMEDIAS@orass1 WHERE STARTDATE = TRUNC(SYSDATE) - 1
;

Prompt ReCriando tabela:AUD_MMEDIAS_NAO_PARTICIONADA
create table iboxnet.AUD_MMEDIAS_NAO_PARTICIONADA Tablespace IBOXNET_DATA nologging as
select * from iboxnet.AUD_MMEDIAS_NAO_PARTICIONADA@orass1
;

Prompt ReCriando tabela:AUTHLOG
create table iboxnet.AUTHLOG Tablespace IBOXNET_DATA nologging as
select * from iboxnet.AUTHLOG@orass1
;

Prompt ReCriando tabela:BROADCAST_POINTS
create table iboxnet.BROADCAST_POINTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.BROADCAST_POINTS@orass1
;

Prompt ReCriando tabela:BUSCA_TVC
create table iboxnet.BUSCA_TVC Tablespace IBOXNET_DATA nologging as
select * from iboxnet.BUSCA_TVC@orass1
;

Prompt ReCriando tabela:BUSCA_TVC_HISTORY
create table iboxnet.BUSCA_TVC_HISTORY Tablespace IBOXNET_DATA nologging as
select * from iboxnet.BUSCA_TVC_HISTORY@orass1
;

Prompt ReCriando tabela:BUSCA_TVC_TEMP
create table iboxnet.BUSCA_TVC_TEMP Tablespace IBOXNET_DATA nologging as
select * from iboxnet.BUSCA_TVC_TEMP@orass1
;

Prompt ReCriando tabela:BUSINESSRULES
create table iboxnet.BUSINESSRULES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.BUSINESSRULES@orass1
;

Prompt ReCriando tabela:CACHES
create table iboxnet.CACHES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CACHES@orass1
;

Prompt ReCriando tabela:CAT_CANAIS
create table iboxnet.CAT_CANAIS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CAT_CANAIS@orass1
;

Prompt ReCriando tabela:CAT_PECAS
create table iboxnet.CAT_PECAS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CAT_PECAS@orass1
;

Prompt ReCriando tabela:CAT_SERVICOS
create table iboxnet.CAT_SERVICOS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CAT_SERVICOS@orass1
;

Prompt ReCriando tabela:CDN_BPOINTS
create table iboxnet.CDN_BPOINTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CDN_BPOINTS@orass1
;

Prompt ReCriando tabela:CDN_IPRANGES
create table iboxnet.CDN_IPRANGES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CDN_IPRANGES@orass1
;

Prompt ReCriando tabela:CDN_LIVES
create table iboxnet.CDN_LIVES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CDN_LIVES@orass1
;

Prompt ReCriando tabela:CDN_MIRRORS
create table iboxnet.CDN_MIRRORS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CDN_MIRRORS@orass1
;

Prompt ReCriando tabela:CDN_REGIONS
create table iboxnet.CDN_REGIONS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CDN_REGIONS@orass1
;

Prompt ReCriando tabela:CDS
create table iboxnet.CDS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CDS@orass1
;

Prompt ReCriando tabela:CHANNELS
create table iboxnet.CHANNELS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CHANNELS@orass1
;

Prompt ReCriando tabela:CHATROOM
create table iboxnet.CHATROOM Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CHATROOM@orass1
;

Prompt ReCriando tabela:CONTENTS
create table iboxnet.CONTENTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CONTENTS@orass1
;

Prompt ReCriando tabela:CONTENT_PROVIDERS
create table iboxnet.CONTENT_PROVIDERS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CONTENT_PROVIDERS@orass1
;

Prompt ReCriando tabela:CON_CATEGORIES
create table iboxnet.CON_CATEGORIES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CON_CATEGORIES@orass1
;

Prompt ReCriando tabela:CON_COMMENTS
create table iboxnet.CON_COMMENTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CON_COMMENTS@orass1
;

Prompt ReCriando tabela:CON_FINALISTS
create table iboxnet.CON_FINALISTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CON_FINALISTS@orass1
;

Prompt ReCriando tabela:CON_SUBJECTS
create table iboxnet.CON_SUBJECTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CON_SUBJECTS@orass1
;

Prompt ReCriando tabela:CON_USERVIDEOS
create table iboxnet.CON_USERVIDEOS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CON_USERVIDEOS@orass1
;

Prompt ReCriando tabela:CON_VOTES
create table iboxnet.CON_VOTES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CON_VOTES@orass1
;

Prompt ReCriando tabela:COUNTRIES
create table iboxnet.COUNTRIES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.COUNTRIES@orass1
;

Prompt ReCriando tabela:CSV
create table iboxnet.CSV Tablespace IBOXNET_DATA nologging as
select * from iboxnet.CSV@orass1
;

Prompt ReCriando tabela:DATACENTERS
create table iboxnet.DATACENTERS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.DATACENTERS@orass1
;

Prompt ReCriando tabela:DEFAULT_SEARCHES
create table iboxnet.DEFAULT_SEARCHES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.DEFAULT_SEARCHES@orass1
;

Prompt ReCriando tabela:DEMO_COUNTRIES
create table iboxnet.DEMO_COUNTRIES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.DEMO_COUNTRIES@orass1
;

Prompt ReCriando tabela:DEMO_REGIONS
create table iboxnet.DEMO_REGIONS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.DEMO_REGIONS@orass1
;

Prompt ReCriando tabela:DESTAQUES
create table iboxnet.DESTAQUES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.DESTAQUES@orass1
;

Prompt ReCriando tabela:DISCOS
create table iboxnet.DISCOS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.DISCOS@orass1
;

Prompt ReCriando tabela:DOCS
create table iboxnet.DOCS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.DOCS@orass1
;

Prompt ReCriando tabela:ENEWS
create table iboxnet.ENEWS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ENEWS@orass1
;

Prompt ReCriando tabela:ENEWS_DISPAROS
create table iboxnet.ENEWS_DISPAROS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ENEWS_DISPAROS@orass1
;

Prompt ReCriando tabela:ENEWS_POPULA
create table iboxnet.ENEWS_POPULA Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ENEWS_POPULA@orass1
;

Prompt ReCriando tabela:ENEWS_STATUSENVIO
create table iboxnet.ENEWS_STATUSENVIO Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ENEWS_STATUSENVIO@orass1
;

Prompt ReCriando tabela:ERROS
create table iboxnet.ERROS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.ERROS@orass1
;

Prompt ReCriando tabela:EXTENSOES
create table iboxnet.EXTENSOES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.EXTENSOES@orass1
;

Prompt ReCriando tabela:FAQ_ANSWERS
create table iboxnet.FAQ_ANSWERS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.FAQ_ANSWERS@orass1
;

Prompt ReCriando tabela:FAQ_TOPICS
create table iboxnet.FAQ_TOPICS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.FAQ_TOPICS@orass1
;

Prompt ReCriando tabela:FLASHES
create table iboxnet.FLASHES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.FLASHES@orass1
;

Prompt ReCriando tabela:GCDN_STATS_MIRRORS
create table iboxnet.GCDN_STATS_MIRRORS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.GCDN_STATS_MIRRORS@orass1 where DATEINS >= trunc(sysdate) - 10
;

Prompt ReCriando tabela:GENEROS
create table iboxnet.GENEROS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.GENEROS@orass1
;

Prompt ReCriando tabela:GEOCOUNTRIES
create table iboxnet.GEOCOUNTRIES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.GEOCOUNTRIES@orass1
;

Prompt ReCriando tabela:GEOCOVERINGBPOINT
create table iboxnet.GEOCOVERINGBPOINT Tablespace IBOXNET_DATA nologging as
select * from iboxnet.GEOCOVERINGBPOINT@orass1
;

Prompt ReCriando tabela:GEOCOVERINGMIRROR
create table iboxnet.GEOCOVERINGMIRROR Tablespace IBOXNET_DATA nologging as
select * from iboxnet.GEOCOVERINGMIRROR@orass1
;

Prompt ReCriando tabela:GEOLOGS
create table iboxnet.GEOLOGS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.GEOLOGS@orass1
;

Prompt ReCriando tabela:GEOREGIONS
create table iboxnet.GEOREGIONS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.GEOREGIONS@orass1
;

Prompt ReCriando tabela:GLOSSARIOS
create table iboxnet.GLOSSARIOS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.GLOSSARIOS@orass1
;

Prompt ReCriando tabela:GRPS
create table iboxnet.GRPS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.GRPS@orass1
;

Prompt ReCriando tabela:IMAGES
create table iboxnet.IMAGES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.IMAGES@orass1
;

Prompt ReCriando tabela:IPRANGES
create table iboxnet.IPRANGES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.IPRANGES@orass1
;

Prompt ReCriando tabela:LINKCONTENTS
create table iboxnet.LINKCONTENTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LINKCONTENTS@orass1
;

Prompt ReCriando tabela:LINKOBJECTS
create table iboxnet.LINKOBJECTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LINKOBJECTS@orass1
;

Prompt ReCriando tabela:LINKPERM_CP_USER
create table iboxnet.LINKPERM_CP_USER Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LINKPERM_CP_USER@orass1
;

Prompt ReCriando tabela:LINKPERM_OBJ_GRP
create table iboxnet.LINKPERM_OBJ_GRP Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LINKPERM_OBJ_GRP@orass1
;

Prompt ReCriando tabela:LINKS
create table iboxnet.LINKS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LINKS@orass1
;

Prompt ReCriando tabela:LIVES
create table iboxnet.LIVES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LIVES@orass1
;

Prompt ReCriando tabela:LIVE_BROADCAST
create table iboxnet.LIVE_BROADCAST Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LIVE_BROADCAST@orass1
;

Prompt ReCriando tabela:LIVE_CHANNELS
create table iboxnet.LIVE_CHANNELS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LIVE_CHANNELS@orass1
;

Prompt ReCriando tabela:LOGFILES
create table iboxnet.LOGFILES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LOGFILES@orass1
;

Prompt ReCriando tabela:LOGIN
create table iboxnet.LOGIN Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LOGIN@orass1
;

Prompt ReCriando tabela:LOGIN_STATS
create table iboxnet.LOGIN_STATS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LOGIN_STATS@orass1
;

Prompt ReCriando tabela:LPAG_CONT
create table iboxnet.LPAG_CONT Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LPAG_CONT@orass1
;

Prompt ReCriando tabela:LPLAYLIST
create table iboxnet.LPLAYLIST Tablespace IBOXNET_DATA nologging as
select * from iboxnet.LPLAYLIST@orass1
;

Prompt ReCriando tabela:MEDIA_TYPES
create table iboxnet.MEDIA_TYPES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.MEDIA_TYPES@orass1
;

Prompt ReCriando tabela:MENU_LINKS
create table iboxnet.MENU_LINKS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.MENU_LINKS@orass1
;

Prompt ReCriando tabela:MESSAGES
create table iboxnet.MESSAGES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.MESSAGES@orass1 where 1<>1
;

Prompt ReCriando tabela:MIBLOGS
create table iboxnet.MIBLOGS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.MIBLOGS@orass1
;

Prompt ReCriando tabela:MMEDIAS
create table iboxnet.MMEDIAS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.MMEDIAS@orass1
;

Prompt ReCriando tabela:MMEDIAS_BKP
create table iboxnet.MMEDIAS_BKP Tablespace IBOXNET_DATA nologging as
select * from iboxnet.MMEDIAS_BKP@orass1
;

Prompt ReCriando tabela:MMEDIAS_HOST
create table iboxnet.MMEDIAS_HOST Tablespace IBOXNET_DATA nologging as
select * from iboxnet.MMEDIAS_HOST@orass1
;

Prompt ReCriando tabela:MMEDIAS_HOST_BKP
create table iboxnet.MMEDIAS_HOST_BKP Tablespace IBOXNET_DATA nologging as
select * from iboxnet.MMEDIAS_HOST_BKP@orass1
;

Prompt ReCriando tabela:MMEDIAS_MIRRORS
create table iboxnet.MMEDIAS_MIRRORS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.MMEDIAS_MIRRORS@orass1
;

Prompt ReCriando tabela:MOUNTINGS
create table iboxnet.MOUNTINGS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.MOUNTINGS@orass1
;

Prompt ReCriando tabela:MUSICS
create table iboxnet.MUSICS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.MUSICS@orass1
;

Prompt ReCriando tabela:NLB
create table iboxnet.NLB Tablespace IBOXNET_DATA nologging as
select * from iboxnet.NLB@orass1
;

Prompt ReCriando tabela:PACKAGES
create table iboxnet.PACKAGES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.PACKAGES@orass1
;

Prompt ReCriando tabela:PACKAGES_LINK
create table iboxnet.PACKAGES_LINK Tablespace IBOXNET_DATA nologging as
select * from iboxnet.PACKAGES_LINK@orass1
;

Prompt ReCriando tabela:PAGES
create table iboxnet.PAGES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.PAGES@orass1
;

Prompt ReCriando tabela:PDFS
create table iboxnet.PDFS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.PDFS@orass1
;

Prompt ReCriando tabela:PLAYLISTITEMS
create table iboxnet.PLAYLISTITEMS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.PLAYLISTITEMS@orass1
;

Prompt ReCriando tabela:PLAYLISTS
create table iboxnet.PLAYLISTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.PLAYLISTS@orass1
;

Prompt ReCriando tabela:PROFILES
create table iboxnet.PROFILES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.PROFILES@orass1
;

Prompt ReCriando tabela:PROGRAMS
create table iboxnet.PROGRAMS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.PROGRAMS@orass1
;

Prompt ReCriando tabela:QUALIDADES
create table iboxnet.QUALIDADES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.QUALIDADES@orass1
;

Prompt ReCriando tabela:RANGE_IPS
create table iboxnet.RANGE_IPS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.RANGE_IPS@orass1
;

Prompt ReCriando tabela:RECORDLABELS
create table iboxnet.RECORDLABELS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.RECORDLABELS@orass1
;

Prompt ReCriando tabela:REGIAO_RANGE
create table iboxnet.REGIAO_RANGE Tablespace IBOXNET_DATA nologging as
select * from iboxnet.REGIAO_RANGE@orass1
;

Prompt ReCriando tabela:REGIOES
create table iboxnet.REGIOES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.REGIOES@orass1
;

Prompt ReCriando tabela:SCHEDULE
create table iboxnet.SCHEDULE Tablespace IBOXNET_DATA nologging as
select * from iboxnet.SCHEDULE@orass1
;

Prompt ReCriando tabela:SERVICOS
create table iboxnet.SERVICOS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.SERVICOS@orass1
;

Prompt ReCriando tabela:SOURCES
create table iboxnet.SOURCES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.SOURCES@orass1
;

Prompt ReCriando tabela:SOURCES_BKP
create table iboxnet.SOURCES_BKP Tablespace IBOXNET_DATA nologging as
select * from iboxnet.SOURCES_BKP@orass1
;

Prompt ReCriando tabela:SQLN_EXPLAIN_PLAN
create table iboxnet.SQLN_EXPLAIN_PLAN Tablespace IBOXNET_DATA nologging as
select * from iboxnet.SQLN_EXPLAIN_PLAN@orass1
;

Prompt ReCriando tabela:STR_EXTENSIONS
create table iboxnet.STR_EXTENSIONS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.STR_EXTENSIONS@orass1
;

Prompt ReCriando tabela:STR_MOUNTINGS
create table iboxnet.STR_MOUNTINGS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.STR_MOUNTINGS@orass1
;

Prompt ReCriando tabela:STR_PROFILES
create table iboxnet.STR_PROFILES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.STR_PROFILES@orass1
;

Prompt ReCriando tabela:STR_QUALITIES
create table iboxnet.STR_QUALITIES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.STR_QUALITIES@orass1
;

Prompt ReCriando tabela:STR_SERVERTYPES
create table iboxnet.STR_SERVERTYPES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.STR_SERVERTYPES@orass1
;

Prompt ReCriando tabela:STYLES
create table iboxnet.STYLES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.STYLES@orass1
;

Prompt ReCriando tabela:TEATROS
create table iboxnet.TEATROS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TEATROS@orass1
;

Prompt ReCriando tabela:TEMPLATES
create table iboxnet.TEMPLATES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TEMPLATES@orass1
;

Prompt ReCriando tabela:TEMPLATES_POS
create table iboxnet.TEMPLATES_POS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TEMPLATES_POS@orass1
;

Prompt ReCriando tabela:TEMP_BYTES
create table iboxnet.TEMP_BYTES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TEMP_BYTES@orass1
;

Prompt ReCriando tabela:TEXTS
create table iboxnet.TEXTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TEXTS@orass1
;

Prompt ReCriando tabela:TIMELINES
create table iboxnet.TIMELINES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TIMELINES@orass1
;

Prompt ReCriando tabela:TIMELINE_ITEMS
create table iboxnet.TIMELINE_ITEMS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TIMELINE_ITEMS@orass1
;

Prompt ReCriando tabela:TIMELINE_SECTIONS
create table iboxnet.TIMELINE_SECTIONS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TIMELINE_SECTIONS@orass1
;

Prompt ReCriando tabela:TIMELINE_TLI_LINK
create table iboxnet.TIMELINE_TLI_LINK Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TIMELINE_TLI_LINK@orass1
;

Prompt ReCriando tabela:TIMES
create table iboxnet.TIMES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TIMES@orass1
;

Prompt ReCriando tabela:TIPO_SERVIDOR
create table iboxnet.TIPO_SERVIDOR Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TIPO_SERVIDOR@orass1
;

Prompt ReCriando tabela:TIPO_SERVIDOR_EXTENSOES
create table iboxnet.TIPO_SERVIDOR_EXTENSOES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TIPO_SERVIDOR_EXTENSOES@orass1
;

Prompt ReCriando tabela:TLS_TLI_LINK
create table iboxnet.TLS_TLI_LINK Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TLS_TLI_LINK@orass1
;

Prompt ReCriando tabela:TRRMONSTREAM_EVENTS
create table iboxnet.TRRMONSTREAM_EVENTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TRRMONSTREAM_EVENTS@orass1
;

Prompt ReCriando tabela:TRRMONSTREAM_FAILCONTROL
create table iboxnet.TRRMONSTREAM_FAILCONTROL Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TRRMONSTREAM_FAILCONTROL@orass1
;

Prompt ReCriando tabela:TRRMONSTREAM_OFFLINESERVERS
create table iboxnet.TRRMONSTREAM_OFFLINESERVERS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TRRMONSTREAM_OFFLINESERVERS@orass1
;

Prompt ReCriando tabela:TRRMONSTREAM_STATS
create table iboxnet.TRRMONSTREAM_STATS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.TRRMONSTREAM_STATS@orass1
;

Prompt ReCriando tabela:UPLOADTIMES
create table iboxnet.UPLOADTIMES Tablespace IBOXNET_DATA nologging as
select * from iboxnet.UPLOADTIMES@orass1
;

Prompt ReCriando tabela:USER_PLAYLISTS
create table iboxnet.USER_PLAYLISTS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.USER_PLAYLISTS@orass1
;

Prompt ReCriando tabela:USER_PL_ITENS
create table iboxnet.USER_PL_ITENS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.USER_PL_ITENS@orass1
;

Prompt ReCriando tabela:USRS
create table iboxnet.USRS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.USRS@orass1
;

Prompt ReCriando tabela:UVTAGS
create table iboxnet.UVTAGS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.UVTAGS@orass1
;

Prompt ReCriando tabela:VIEW_FUNCTIONS
create table iboxnet.VIEW_FUNCTIONS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.VIEW_FUNCTIONS@orass1
;

Prompt ReCriando tabela:WAPS
create table iboxnet.WAPS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.WAPS@orass1
;

Prompt ReCriando tabela:XLS
create table iboxnet.XLS Tablespace IBOXNET_DATA nologging as
select * from iboxnet.XLS@orass1
;

Spool off;
