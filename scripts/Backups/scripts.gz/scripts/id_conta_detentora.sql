set serveroutput on size 1000000
spool id_conta_detentora.log
conn suat/tcdpp6
declare
  dtIniProcesso date;
  dtFimProcesso date;
  
  qtTotal number := 0;
  ipTamanhoBlocoCommit number := 10000;
begin
  dtIniProcesso := sysdate;
  
  for reg_cta in (
    select   cta.id_conta            as id
            ,cta.id_conta            as id_detentora
    from     trr_conta               cta
            ,trr_perfil_cobranca     pec
    where    cta.id_conta_detentora  is null
      and    pec.id_perfil_cobranca   = cta.id_perfil_cobranca
      and    pec.cd_perfil_cobranca   = 'PAG'
      and    exists (
        select  *
        from    trr_contrato_servico        cps
        where   cps.id_conta                = cta.id_conta
    )
  ) loop
    
    update   trr_conta               cta
    set      cta.id_conta_detentora  = reg_cta.id_detentora
    where    cta.id_conta            = reg_cta.id;
    
    qtTotal := qtTotal + 1;
    
    if (mod(qtTotal,ipTamanhoBlocoCommit) = 0) then
	  commit;
      dbms_output.put_line('Bloco: ' || to_char(qtTotal,'999,999,990'));
	end if;
    
  end loop;
  
  if (mod(qtTotal,ipTamanhoBlocoCommit) != 0) then
    commit;
  end if;
  
  dtFimProcesso := sysdate;
  
  dbms_output.put_line('Data/hora inicio : ' || to_char(dtIniProcesso,'DD/MM/YYYY HH24:MI:SS'));
  dbms_output.put_line('Data/hora termino: ' || to_char(dtFimProcesso,'DD/MM/YYYY HH24:MI:SS'));
  
  dbms_output.put_line('Qtd Contas Atualizadas: ' || to_char(qtTotal,'999,999,990'));
exception
  when others then
    dbms_output.put_line('[ERRO] ' || to_char(sqlcode) || ' - ' || sqlerrm);
    rollback;
end;
/

exit;

