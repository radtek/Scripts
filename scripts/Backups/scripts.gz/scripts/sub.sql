accept n_dt prompt 'Pr�xima execu��o (dd/mm/yyyy hh24:mi:ss):'
accept inte prompt 'String do intervalo.....................:'
accept p_what prompt 'What:' 

set serveroutput on;

declare
  jobno number;
begin
 DBMS_JOB.SUBMIT (JOBNO,'&p_what;',to_date('&n_dt','dd/mm/yyyy hh24:mi:ss'), '&inte',NULL);
 COMMIT;
 DBMS_OUTPUT.PUT_LINE ('jOB:'||JOBNO||' CRIADO.');
end;
/

