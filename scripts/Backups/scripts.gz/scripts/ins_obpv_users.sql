spool ins_obpv_users.log
set timing on
set echo on
alter session set sort_area_size=30000000;



-- Script to insert new OBP variables.
--
declare
    --
    v_obpv_id_quota         number;
    v_obpv_id_auto_reply    number;	
    v_lines_to_commit       number := 5000;
    v_cont                  number := 0;
    v_exit                  varchar2(01) := null;
    --
    cursor assinantes_cur (p_obpv_id in number) is
    select /*+ use_hash(a,b,d,e) */
           a.snh_id, a.quota, d.email, e.cod_dominio
      from ciut.trr_usr_assinantes a, bd_central.trr_userprodutos b, bd_central.trr_senhas d, BD_CENTRAL.TRR_COD_DOMINIOS e
     where a.snh_id    = b.snh_id
       and b.snh_id    = d.snh_id
       and d.cdom_id   = e.cdom_id
       and b.d_produto = 'CXP'
       and a.snh_id not in (select /*+ hash_aj */ c.snh_id
                              from bd_central.trr_obpv_users c
                             where c.obpv_id = p_obpv_id);
    --
begin
    --
    -- Consulta o id da variavel quota.
    select obpv_id
      into v_obpv_id_quota
      from bd_central.trr_obp_vars
     where nome = 'quota_caixa';

    -- Consulta o id da variavel auto_reply.
    select obpv_id
      into v_obpv_id_auto_reply
      from bd_central.trr_obp_vars
     where nome = 'mail_autoreply';
	 
    -- Esse loop foi incluido apenas para tratar os poss�veis ORA-1555 (SNAPSHOT TOO OLD).
    v_exit := 'N';
    loop
      exit when v_exit = 'S';
      begin
        --
        for C in assinantes_cur (v_obpv_id_quota)
        loop
		  --
			begin
				 insert into bd_central.trr_obpv_users (snh_id, obpv_id, valor)
				 values (C.snh_id, v_obpv_id_quota, C.quota);
			  --
				 insert into bd_central.trr_obpv_users (snh_id, obpv_id, valor)
				 values (C.snh_id, v_obpv_id_auto_reply, 'T');
                          --
                                 insert into ajustabd.trr_expired_users (email, snh_id, brand, dt_ins)
                                 values (C.email, C.snh_id, C.cod_dominio, sysdate);
                          --
			exception
				when others then
					if (sqlcode = -2291) then -- parent key not found
						delete from bd_central.trr_obpv_users
						where snh_id = C.snh_id
						and	obpv_id in (v_obpv_id_quota,v_obpv_id_auto_reply);
					else
						raise;
					end if;
			end;
			  --
			if (v_cont = v_lines_to_commit) then
				commit;
				v_cont := 0;
			else
				v_cont := v_cont + 1;
			end if;
        --
        end loop;
        --
        commit;
        v_exit := 'S';
      exception when others then
        if (sqlcode = -1555) then
           v_exit := 'N';
		   rollback;
        else
		   rollback;
           raise;
        end if;
      end;
    end loop;
    --
end;
--
/

exit;


