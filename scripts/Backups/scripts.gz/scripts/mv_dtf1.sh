sqlplus /nolog <<eof
conn / as sysdba
spool mv_dtf1.log
set echo on

alter tablespace mail_trr_remetentes_data offline;

! cp /o02/oradata/oradb1/mail_trr_remetentes_data_01.dbf /o01/oradata/oradb1/mail_trr_remetentes_data_01.dbf

alter database rename file '/o02/oradata/oradb1/mail_trr_remetentes_data_01.dbf' to '/o01/oradata/oradb1/mail_trr_remetentes_data_01.dbf';

alter tablespace mail_trr_remetentes_data online;


exit;
eof

