spool migra_suat_registro_servicoconta_dir_adquirido_1.log
set echo on
set time on
set timing on

conn suat/tcdpp6

alter session set sort_area_Size=100000000;

insert  /*+ APPEND */ all into trr_registro_servicoconta
    (
    id_registro_servicoconta,
    id_contrato_servico,
    id_pacotecomerc_servico,
    id_conta,
    id_submotivo_status,
    dt_submotivostatus,
    id_cicloservico_registrado
    )
values (
	    id_registro_servicoconta_seq.nextval,
        id_contrato_servico,
        id_pacotecomerc_servico,
        id_conta,
        id_submotivo_status,
        dt_submotivo_status,
        id_cicloservico_registrado
)
	  select
        /*+ ordered use_hash (conta contrato oper cpp p caracGAT cm line ctaSUAT cose paco clpa pase capa lise serv oper1)*/
        cose.id_contrato_servico,
        pase.id_pacotecomerc_servico,
        ctaSUAT.id_conta,
        ctaSUAT.id_submotivo_status,
        ctaSUAT.dt_submotivo_status,
        null id_cicloservico_registrado
from gatmig.conta		conta
	, gatmig.contrato    contrato
	, gatmig.operadora   oper
	, gatmig.contaplanoprod	cpp
	, gatmig.produto    	p
	, gatmig.caracteristica	caracGAT
	, trr_controle_migracao_conta	cm
	, trr_linha_negocio    	line
	, trr_conta				ctaSUAT
	, trr_contrato_servico  cose
	, trr_pacote_comercial  paco
	, trr_classe_pacote    	clpa
	,trr_pacotecomerc_servico  pase
	,trr_caracservico_pacotecom capa
	,trr_linhanegocio_servico   lise
	,trr_servico                serv
	,( select /*+ no_merge */ distinct(upper(linhanegocio)) linhanegocio from gatmig.operadora ) oper1
where oper.COD_OPER                = contrato.COD_OPER
	and contrato.COD_CONTR         = conta.COD_CONTR
	and conta.COD_CONTA            = cpp.COD_CONTA
	and cpp.COD_PROD               = p.COD_PROD
	and cpp.COD_CARAC              = caracGAT.COD_CARAC
	and caracGAT.cod_carac         not in ( 16, 17, 18, 7 )
	and conta.PRINCIPAL    		= 'S'
	and conta.COD_CONTA    		= cm.GAT_CHAVE
	and cm.ID_LINHA_NEGOCIO   	= line.ID_LINHA_NEGOCIO
	and upper(oper.LINHANEGOCIO)   	= line.NM_LINHA_NEGOCIO
	and cm.SUAT_CHAVE     		= ctaSuat.ID_CONTA
	and cm.GAT_TABELA     		= 'CONTA'
	and cm.SUAT_TABELA    		= 'TRR_CONTA'
	and ctaSuat.ID_CONTA    	= cose.ID_CONTA
	and cose.ID_PACOTE_COMERCIAL  	= paco.ID_PACOTE_COMERCIAL
	and paco.ID_CLASSE_PACOTE   	= clpa.ID_CLASSE_PACOTE
	and clpa.BL_DIR_ADQUIRIDO   	= 'S'
	and clpa.id_linha_negocio	= line.id_linha_negocio
	and cpp.VALORCARAC		= decode(capa.TP_VALOR,'N',capa.NR_VALOR_NUMERICO,'S',capa.DE_VALOR_TEXTO)
	and p.cod_prodciut		= serv.cd_servico
   	and paco.ID_PACOTE_COMERCIAL	= pase.ID_PACOTE_COMERCIAL
   	and pase.ID_PACOTECOMERC_SERVICO	= capa.ID_PACOTECOMERC_SERVICO
   	and pase.TP_CONTA_RECEBE_SERVICO	= 'D'
   	and pase.ID_LINHANEGOCIO_SERVICO    = lise.ID_LINHANEGOCIO_SERVICO
   	and lise.id_linha_negocio           = line.id_linha_negocio
   	and lise.ID_SERVICO                 = serv.ID_SERVICO
   	and line.NM_LINHA_NEGOCIO	    = oper1.linhanegocio;
commit;

spool off;

exit;


