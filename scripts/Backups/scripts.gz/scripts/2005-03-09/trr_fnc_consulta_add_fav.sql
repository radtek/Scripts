accept own prompt 'Owner:'

Spool alter_&own..log
set echo on

create index &own..FAV_FLOG_FAV_FK_I2 on &own..trr_favoritos (
FLOG_ID_FAV, dt_criacao desc, flog_id)
Tablespace fotolog_indx Nologging online compute statistics;

Drop index &own..FAV_FLOG_FAV_FK_I;

Create index &own..FORIGEM_FLOG_FK_I2 on &own..trr_flog_origens (
Flog_id, DT_ULTIMO_POST)
Tablespace fotolog_indx Nologging online compute statistics;

Drop index &own..FORIGEM_FLOG_FK_I;

set echo off

create or replace function &own..trr_fnc_consulta_add_fav
 ( c_cur                  in out trr_pck_cur_type.t_cur_type
  ,in_flog_id             in trr_flogs.flog_id%type
  ,iv_nick_flog           in trr_flogs.nick_flog%type
  ,in_dias_post		  in number default NULL
  )


 return integer
 is
 /*
 Nome da fun��o: trr_fnc_consulta_add_fav
 Descri��o: 	Retorna lista de quem adicionou o fotolog como favorito.
 Data: 		29/07/2004
 Autor: 	Cristiano Rech Perozzo

 Par�metros:

    in_flog_id    number(10)    			- OBRIGATORIO/OPCIONAL
    iv_nick_flog  varchar2(60)  			- OBRIGATORIO/OPCIONAL
    in_dias_post  se <> NULL retorna apenas os f�s que tenham feito um post nos �ltimos 'in_dias_post' dias (number)   - OPCIONAL


 Retorno:

     0 - Sucesso
    -1 - Par�metros obrigat�rios n�o informados
    -2 - Flog Inexistente
    -4 - Deve ser informado apenas uma par�metro chave para consulta
    -5 - valor inv�lido para o parametro in_dias_post

Retorno do cursor:

     - flog_id
     - nick_flog
     - data_inclusao

Altera��es:
   08/03/2005 - Cristiano Perozzo
      - inclu�do par�metro de entrada in_dias_post:
      	caso definido retorna apenas os f�s que tiveram no m�nimo um post nos �ltimos 'n' dias
	caso null, retorna todos
      - em caso de sucesso, SP retorna 0 (zero) e n�o mais a quantidade de linhas.

  */


 ln_flog integer;

 Cursor c_cur_flog is
  select flog_id
  from trr_flogs
  where flog_id = in_flog_id;

 Cursor c_cur_nick_flog is
  select flog_id
  from trr_flogs
  where nick_flog = lower(iv_nick_flog);

 begin

   -- Valida par�metros obrigat�rios
   if ((in_flog_id is null) and
       (iv_nick_flog is null)
      ) then
      return(-1); -- Par�metros obrigat�rios n�o informados
   end if;

  -- Valida a pesquisa
  if ((in_flog_id is not null) and (iv_nick_flog is not null)) then
      return(-4); -- Deve ser informado apenas uma par�metro chave para consulta
  end if;

  -- Valida in_dias_post
  if (in_dias_post is not null) then
     if (in_dias_post <= 0) then
         return(-5); -- Deve ser informado apenas uma par�metro chave para consulta
     end if;
  end if;

  -- Valida Flog(flog_id)
  if (in_flog_id is not null) then
      open c_cur_flog;
      fetch c_cur_flog into ln_flog;
      if (c_cur_flog%NOTFOUND) then
        close c_cur_flog;
        return(-2); -- Flog inexistente
      else
        close c_cur_flog;
      end if;

  end if;


  -- Valida Flog(nick_flog)
  if (iv_nick_flog is not null) then
     open c_cur_nick_flog;
     fetch c_cur_nick_flog into ln_flog;
     if (c_cur_nick_flog%NOTFOUND) then
       close c_cur_nick_flog;
       return(-2); -- Flog inexistente
     else
       close c_cur_nick_flog;
     end if;
  end if;



  if (in_dias_post is null) then -- retorna TODOS os f�s
     open c_cur for
	select f.flog_id
	      ,f.nick_flog
	      ,to_char(v.dt_criacao, 'dd/mm/yyyy hh24:mi')  dt_criacao
	from trr_flogs f
  	    ,trr_favoritos v
	where f.flog_id = v.flog_id
	  and v.flog_id_fav = ln_flog
	order by v.dt_criacao desc;
  else
     open c_cur for
        select f.flog_id
              ,f.nick_flog
              ,to_char(v.dt_criacao, 'dd/mm/yyyy hh24:mi') dt_criacao
          from (select v.flog_id, v.dt_criacao
                  from trr_favoritos v
                 where v.flog_id_fav    = ln_flog
                   and exists (select 1
                                 from trr_flog_origens
                                where flog_id                   = v.flog_id
                                  and DT_ULTIMO_POST >= current_date - in_dias_post)
                 order by v.dt_criacao desc) v
            ,trr_flogs f
       where f.flog_id   = v.flog_id;
  end if;

  if (in_dias_post is null) then -- retorna TODOS os f�s
      return(trr_fnc_conta_presenca_fav(ln_flog));
  else
     return(0);
 end if;

end trr_fnc_consulta_add_fav;
/
show err

spool off;

