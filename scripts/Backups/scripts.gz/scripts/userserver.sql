break on server;
compute sum of nro_usuarios on server;
--
select nvl(username,'oracle') usuario,machine, server, count(*) nro_usuarios from v$session group by username,machine, server
order by server
/

