accept table_owner prompt "Owner:"
accept table_name prompt  "Table:"

set ver off;
set long 32000;

col cln                for a30 heading 'Column';
col tipo_status        for a12;
col clfn               for a50 heading 'Ref';
col search_condition   for a80;

break on constraint_name skip 1 on tipo_status;

prompt
prompt Primary, Uniques and foreigns ...


select cns.CONSTRAINT_NAME                              constraint_name,
       decode (cns.constraint_type,'P','PK','R','FK','C','CK','U','UK','XX') ||
       ' (' || substr(cns.STATUS,1,3) || '/' || substr(validated,1,3) || ')'  tipo_status,
        cls.position ||'.'||cls.COLUMN_NAME                                  cln,
       ' '                                              clfn
from 	all_constraints cns,
        all_cons_columns cls
where 	cns.table_name=upper('&table_name')
and 	cns.owner= upper('&table_owner')
and 	cns.CONSTRAINT_TYPE='P'
and 	cns.constraint_name=cls.constraint_name
and     cns.owner = cls.owner
union all
select cns.CONSTRAINT_NAME                              constraint_name,
       decode (cns.constraint_type,'P','PK','R','FK','C','CK','U','UK','XX') ||
       ' (' || substr(cns.STATUS,1,3) || '/' || substr(validated,1,3) || ')'  tipo_status,
        cls.position ||'.'||cls.COLUMN_NAME                                  cln,
       ' '                                              clfn
from 	all_constraints cns,
        all_cons_columns cls
where 	cns.table_name=upper('&table_name')
and 	cns.owner= upper('&table_owner')
and 	cns.CONSTRAINT_TYPE='U'
and 	cns.constraint_name=cls.constraint_name
and     cns.owner = cls.owner
union all
select  cns.CONSTRAINT_NAME                                  CONSTRAINT_NAME,
        decode (cns.constraint_type,'P','PK','R','FK','C','CK','U','UK','XX') ||
        ' (' || substr(cns.STATUS,1,3) || '/' || substr(validated,1,3) || ')'  tipo_status,
        cls.position ||'.'||cls.COLUMN_NAME                                      cln,
        clf.OWNER||'.'||clf.TABLE_NAME||'.'||clf.COLUMN_NAME clfn
from 	all_constraints cns,
        all_cons_columns clf ,
        all_cons_columns cls
where 	cns.table_name      =  upper('&table_name')
and 	cns.owner           =  upper('&table_owner')
and 	cns.CONSTRAINT_TYPE = 'R'
and 	cns.constraint_name = cls.constraint_name
and    clf.CONSTRAINT_NAME = cns.R_CONSTRAINT_NAME
and    clf.OWNER           = cns.OWNER
and    cls.OWNER           = cns.OWNER
and    clf.POSITION        = cls.POSITION
order by tipo_status desc, constraint_name, cln
/

prompt
prompt Check constraints ...

break on constraint_name on tipo_status;

select cns.CONSTRAINT_NAME                                  CONSTRAINT_NAME,
       decode (cns.constraint_type,'P','PK','R','FK','C','CK','U','UK','XX') ||
       ' (' || substr(cns.STATUS,1,3) || '/' || substr(validated,1,3) || ')'  tipo_status,
       search_condition
from all_constraints  cns
where table_name=upper('&table_name')
and owner=  upper('&table_owner')
and CONSTRAINT_TYPE='C'
order by constraint_name
/