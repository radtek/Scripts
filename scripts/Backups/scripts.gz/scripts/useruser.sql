select sid, serial#, logon_time, machine, program, server,osuser, status from v$session where username = upper('&usern') order by logon_time
/
