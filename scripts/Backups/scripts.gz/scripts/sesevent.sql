select * from v$session_event where sid = &sidi
order by time_waited
/
