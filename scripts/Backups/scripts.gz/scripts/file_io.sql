col filename for a55;
col DRIVE FOR A6;

SET PAGES 300;
select  substr(i.name,1,6)"DRIVE",  /*assumes a 6-letter drive name*/
       sum(x.phyrds) +  sum(x.phywrts) "total",         /*Total IO*/
       sum(x.phyrds) "PHYSRDS",        /*Physical Reads*/
       sum(x.phywrts) "PHYSWRT",       /*Physical Writes*/
      sum(x.phyblkrd) "BLK_RDS",      /*Block Reads*/
      sum(x.phyblkwrt) "BLK_WRT"      /*Block Writes*/
  from v$filestat x, sys.ts$ ts, v$datafile i,sys.file$ f
 where i.file#=f.file#
   and ts.ts#=f.ts#
   and x.file#=f.file#
group by substr(i.name,1,6)
order by 2 desc
/

BREAK ON DRIVE SKIP 1;

select substr(i.name,1,6) "DRIVE",
	i.name filename,
    x.phyrds +  x.phywrts "total",          /*Total IO*/
	x.phyrds "PHYSRDS",		/*Physical Reads*/
	x.phywrts "PHYSWRT",		/*Physical Writes*/
	x.phyblkrd "BLK_RDS",		/*Block Reads*/
	x.phyblkwrt "BLK_WRT"		/*Block Writes*/
from v$filestat x, sys.ts$ ts, v$datafile i, sys.file$ f
where i.file#=f.file#
  and ts.ts#=f.ts#
  and x.file#=f.file#
order by 1,3
/