alter session set optimizer_mode=&mode
/
