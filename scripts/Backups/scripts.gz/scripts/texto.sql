select sql_text
  from  v$sqltext
 where HASH_VALUE     = &hash
order by PIECE
/
