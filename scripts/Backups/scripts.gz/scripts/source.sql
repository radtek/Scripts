select text 
  from all_source
 where name = upper('&sp')
   and owner = upper ('&own')
order by type, line
/
