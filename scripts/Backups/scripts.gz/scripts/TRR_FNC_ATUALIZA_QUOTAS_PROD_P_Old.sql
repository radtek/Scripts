CREATE OR REPLACE
FUNCTION ciut.trr_fnc_atualiza_quotas_prod_p
  (Iv_Id                 IN Trr_Pck_Types.T_Snh_EMail
  ,Iv_Lista_Cod          IN VARCHAR2
  ,Iv_Lista_Quota        IN VARCHAR2
  ,Iv_Cod_Dominio        IN Trr_Pck_Types.T_Cdom_Cod_Dominio   DEFAULT 'terra'
  ,Iv_Dominio            IN Trr_Pck_Types.T_Dom_Nome           DEFAULT 'terra.com.br' )
                     RETURN INTEGER
IS
/**----------------------------------------------------------------------------------------------
Nome da fun��o: Trr_Fnc_Atualiza_Quotas_Prod_P
Descri��o: Atualizar as vari�veis OBP com suas respectivas informa��es entre ela as quotas dos
           produtos Terra.
Autor: Paulo - Tecnologia / Acesso TERRA
Data:  12/11/2001

Par�metros:

   Id                   VARCHAR2(60)                                    - Obrigat�rio
   Lista_Cod            VARCHAR2                                        - Obrigat�rio
   Lista_Quota          VARCHAR2                                        - Obrigat�rio
   Cod_Dominio          VARCHAR2(5)  Default: terra                     - Obrigat�rio / Opcional
   Dominio              VARCHAR2(60) Default: terra.com.br              - Obrigat�rio / Opcional

Retorno:

    0 - Sucesso
   -1 - Par�metros obrigat�rios n�o informados
   -2 - Tipo de usu�rio inv�lido.
   -3 - Valor inv�lido para o par�metro Lista_Cod
   -4 - Valor inv�lido para o par�metro Lista_Quota
   -8 - Erro ao inserir usu�rio nos produtos da base central
        (Anteriormente era: Erro ao atualizar tabela AlbumFotos.Trr_Usr_Albs)
   -9 - Erro ao atualizar vari�veis OBP
        (Anteriormente era: Erro ao atualizar tabela DiscoV_Planeta.VDisk)

  -13 - ID n�o cadastrado/inexistente
  -14 - iv_cod_dominio inv�lido ou inexistente
  -15 - iv_dominio inv�lido ou inexistente

  Erros relacionados a chamada da SP trr_fnc_query_account:

  -21	Par�metros obrigat�rios n�o informados
  -22	Usu�rio inv�lido
  -23	Brand inv�lido
  -24	C�digo de servi�o � inv�lido
  -25	Evento inv�lido para esse usu�rio/servi�o

  Erros relacionados a chamada da SP trr_fnc_config_account:

  -31	Par�metros obrigat�rios n�o informados
  -32	Usu�rio inv�lido
  -33	Brand inv�lido
  -34	C�digo de servi�o � inv�lido
  -35	Evento inv�lido para esse usu�rio/servi�o
  -37	Valor inv�lido para par�metro autoreload
  -38	Per�odo de recarga n�o pode ser negativo
  -39	Valor inv�lido para o par�metro keepcredit
  -40	Valor inv�lido para o par�metro keepnegativecredit
  -41 Origem de cr�ditos inv�lida
  -42 N�o foi poss�vel ajustar limite de cr�dito. Usu�rio n�o possui
      saldos de conta n�o-expirados suficientes.
  -43 N�o foi poss�vel atualizar saldo por problema de concorr�ncia.
      Tente novamente.
  -44 Data de expira��o n�o pode ser menor do que hoje
  -72	N�o existe conta n�o-expirada para esse usu�rio/brand/servi�o/evento

  Erros relacionados a chamada da SP trr_fnc_new_account:

  -81	Par�metros obrigat�rios n�o informados
  -82	Usu�rio inv�lido
  -83	Brand inv�lido
  -84	C�digo de servi�o � inv�lido
  -85	Evento inv�lido para esse usu�rio/servi�o
  -86	N�mero de cr�ditos n�o pode ser negativo
  -87	Valor inv�lido para par�metro autoreload
  -88	Per�odo de recarga n�o pode ser negativo
  -89	Valor inv�lido para o par�metro keepcredit
  -90	Valor inv�lido para o par�metro keepnegativecredit
  -91	Valor inv�lido para o par�metro ic_d_unit
  -92	Formato inv�lido para par�metro date
  -93	Valor inv�lido para o par�metro all_events
  -106	Valor inv�lido para origem do cr�dito

  Erros relacionados a chamada da SP trr_fnc_rem_user:

  -121	Par�metros obrigat�rios n�o informados
  -122	Usu�rio inv�lido
  -123	Brand inv�lido
  -141	Usu�rio n�o cadastrado

  Erros relacionados a chamada da SP trr_fnc_autoreload_account:

  -151 Par�metros obrigat�rios n�o informados
  -152 C�digo de servi�o � inv�lido
  -153 Evento inv�lido para esse usu�rio/servi�o
  -154 N�o foi poss�vel obter lock exclusivo em saldos
       de contas. Tente novamente.

Altera��es:
  29/11/2001 - Paulo R. Baptista - Atualizar a coluna quota_pacotes das tabelas de quotas de
                                   produtos com o total de quotas dos pacotes adquiridos.
  17/12/2001 - Paulo R. Baptista - Acertado a chamada de procedures que n�o executam o commit
                                   e alterado o nome para ..._P (PRIV).
  29/01/2001 - Paulo R. Baptista - Alterado par�metros da chamada da fun��o
                                   DiscoV_Planeta.Funct.InsereUsuario_Priv.
  18/03/2001 - Paulo R. Baptista - A fun��o passou a n�o atualizar mais quotas default para
                                   os usu�rios, simplesmete ela ir� atribuir o valor recebido.
                                   As cotas de �lbum de fotos e disco virtual ser�o passadas
                                   como caracter�sticas dos produtos. Foi exclu�do o par�metro
                                   Iv_Quota_open pois n�o � mais necess�rio. Tamb�m n�o atua-
                                   lizar� mais a coluna quota_pacotes.
  23/04/2002 - Paulo R. Baptista - A fun��o passou a atualizar as tabelas Trr_ObpV_Users e
                                   com a lista de valores existentes na tabela Trr_Obp_Vars
                                   atrav�s da coluna Nome_GAT.
  03/05/2002 - Jo�o Frederico - coloca��o em coment�rio dos dbms_output
  03/05/2002 - Observa��o:         Nesta data o Jo�o Frederico tamb�m colocou uma condi��o para
                                   n�o incluir o produto "ALM-Almas G�meas" em fun��o do
                                   CGI n�o estar preparado para tratar (Trr_UserProdutos).
  09/05/2002 - Paulo R. Baptista - A fun��o passou a atualizar as tabelas dos produtos "VDK-
                                   Disco Virtual" e "ALB-�lbum de Fotos" com a quota em disco
                                   igual ao que foi atualizado nas vari�veis OBP, pois o CGI
                                   n�o esta acessando as vari�veis OBP para usu�rios REG.
  06/06/2002 - Paulo R. Baptista - Ao atualizar a vari�vel AntiVirus j� habilita o mesmo na
                                   aplica��o (trr_usr_assinantes).
  08/07/2002 - Paulo R. Baptista - A fun��o passou a atualizar a quota de email na tabela de
                                   assinantes.
  02/08/2002 - Paulo R. Baptista - Passou a atualizar Anti-Virus e Anti_spam na tabela
                                   TRR_EMP_ATRIBUTOS.
  22/10/2002 - Paulo R. Baptista - Desativada a obrigatoriedade de todas as vari�veis de
                                   caixa postal, conforme solicita��o do Sr. Andr� Marquardt.
  28/10/2002 - Paulo R. Baptista - Ao habilitar/desabilitar a vari�vel AntiSpam j� habilita/
                                   desabilita o indicador "extrato di�rio" (Tabela Trr_Emp_
                                   Atributos, coluna D_Extrato_Dia_SN).
                                   Ao habilitar a vari�vel OBP mail_imap com os valores
                                   1_ONLY_WEB e 2_ALLOWED atualiza para S (Sim) a coluna
                                   D_Mail_Imap_Habilitado e ao desabilit�-la (0_NOT_ALLOWED)
                                   colocar N (N�o).
                                   Quando desabiltar a vari�vel OBP mail_imap automaticamente
                                   colocar valor "N" na coluna D_Filtros_Genericos_SN da tabela
                                   Trr_Usr_Assinantes.
  23/01/2003 - Paulo R. Baptista - Passou a habilitar anti-virus para todas as contas
                                   independente de ser a principal para dom�nios DIFERENTES
                                   do TERRA.
  27/01/2003 - Paulo R. Baptista - Atualizar a tabela Trr_Usr_Alms de acordo com o valor recebido
                                   na vari�vel OBP "sou_show_first":
                                     se "T" Trr_Usr_Alms.Grupo_Pesquisa -> "A"
                                     se "F" Trr_Usr_Alms.Grupo_Pesquisa -> "B".
                                   Tamb�m foi retirado a condi��o que n�o atualiza vari�veis
                                   OBP do produto ALM-Almas G�meas, desta forma ser�o atualizadas
                                   todas as vari�veis deste produto.
  28/02/2003 - Jo�o Frederico - Atualizar a tabela Trr_Usr_Alms de acordo com o valor recebido
                                na vari�vel OBP "sou_free_description":
                                     se "T" Trr_Usr_Alms.d_recado_visivel -> "S"
                                     se "F" Trr_Usr_Alms.d_recado_visivel -> "N".
  08/04/2003 - Taise Lorenzi - Atualizar a tabela Trr_Usr_Alms os seguintes campos relacionados a
  										 foto qdo usu�rio passar de Basic para Open :
  										 	- d_status_foto = 'P'
  										 	- arquivo_foto = NULL
  										 	- d_ja_inclui_foto = 'N'.
  										  Atualizar tb o campo d_mostrar_statis.
  29/04/2003 - Jo�o Frederico
     - Chamada da SP trr_fnc_atualiza_obps_almas do usu�rio almasgemeas que atualiza
       campos da tabela almasgemeas.trr_usr_alms em fun��o dos valores de vari�veis OBP.
  07/07/2003 - Taise Lorenzi
  		- Foram inseridas duas fun��es : Fnc_Update_Quota_EMail e Fnc_Update_Mail_Auto_Reply
  		  e as seguintes fun��es foram desabilitadas: Fnc_Update_AntiVirus e Fnc_Update_AntiSpam.
  18/08/2003 - Jo�o Frederico
      - Unifica��o das altera��es para central unificada e mail global
      - Retirada de todos os dbms_output()

  03/10/2003 - Taise Lorenzi
      - Foram retiradas as seguintes fun��es:Fnc_Update_Quota_EMail ,Fnc_Update_Mail_Auto_Reply
      e Fnc_Update_Imap_Habilitar.

  06/01/2004 - Jo�o Frederico
      - Inclus�o/altera��o de cr�ditos no sistema de cr�ditos e d�bitos para o
        servi�o SMS
      - Remo��o do sistema de cr�ditos e d�bitos
  26/03/2004 - Jo�o Frederico
      - Foi eliminado acesso a tabelas das aplica��es disco virtual e �lbum
  11/10/2004 - Jo�o Frederico
      - Eliminado acesso a base de dados do Almas.

----------------------------------------------------------------------------------------------**/

/**-------------------------------------------------------------------------------------------**/
/**                              VARI�VEIS / CURSORES gerais                                  **/
/**-------------------------------------------------------------------------------------------**/
  Lv_Nda            VARCHAR2(1);
  Ln_Ret_Fun        INTEGER;
  Ln_Nao_Atualiza   NUMBER;
  --
  Ln_Snh_Id         Trr_Pck_Types.T_Snh_Snh_Id;
  Lv_Senha          Trr_Pck_Types.T_Snh_Senha;
  Lc_D_Tp_Usuario   Trr_Pck_Types.T_Snh_D_Tp_Usuario;
  Lc_Cod            Trr_UserProdutos.D_Produto%TYPE;
  --
  Ln_Ocor_Serv      NUMBER;
  Ln_Pos_Serv       NUMBER;
  Ln_Pos2_Serv      NUMBER;
  Ln_Pos_Ant_Serv   NUMBER;
  Ln_Pos_Ant2_Serv  NUMBER;
  Ln_Tot_Serv       NUMBER;
  --
  Ln_Ocor_VObp      NUMBER;
  Ln_Pos_VObp       NUMBER;
  Ln_Pos2_VObp      NUMBER;
  Ln_Pos_Ant_VObp   NUMBER;
  Ln_Pos_Ant2_VObp  NUMBER;
  Ln_Tot_VObp       NUMBER;
  --
  Lv_Lista_VObp     VARCHAR2(4000);
  Lv_Valor          VARCHAR2(1);
  Ln_Quota          NUMBER;

  Ln_ret            NUMBER;

/**-------------------------------------------------------------------------------------------**/
/**                          Procedimentos de VALIDA��O / CHECK / UPDATE                      **/
/**-------------------------------------------------------------------------------------------**/

  FUNCTION Fnc_Valida_Insere_Prod
    (Pc_Prod   IN Trr_UserProdutos.D_Produto%TYPE)
           RETURN NUMBER IS
    --
    CURSOR C_TpUsr IS
      SELECT '1'
        FROM cg_ref_codes_central
       WHERE Rv_Domain     = 'PRODUTOS'
         AND Rv_Low_value  = UPPER(Pc_Prod);
    --
    Ln_Snh_Id  NUMBER;
    --
  BEGIN
	OPEN  C_TpUsr;
	FETCH C_TpUsr INTO Lv_Nda;
	IF C_TpUsr%NOTFOUND
	THEN
	  CLOSE C_TpUsr;
	  RETURN(0);  -- Produto inv�lido
	END IF;
	CLOSE C_TpUsr;
	--
	Ln_Snh_Id := Trr_Fnc_InsertUserProd_Central(Iv_Id,
                                                Pc_Prod,
                                                TO_CHAR(SYSDATE,'DD/MM/YYYY HH24:MI:SS'),
                                                Iv_Cod_Dominio,
                                                Iv_Dominio);
	IF Ln_Snh_Id < 1
	THEN
	  RETURN(3); -- Erro ao atualizar produtos na base central
	END IF;
    --
    RETURN(1);  -- Produto v�lido
    --
  END Fnc_Valida_Insere_Prod;
  --
  FUNCTION Fnc_Valida_Atualiza_VObp
    (Pc_Prod       IN Trr_UserProdutos.D_Produto%TYPE,
     Pv_Lista_VObp IN VARCHAR2)
           RETURN NUMBER IS
    --
    CURSOR C_ObpV IS
      SELECT REPLACE(Nome_GAT,Pc_Prod || '_',NULL) Nome_GAT,
             Nome
        FROM Trr_OBP_Vars
       WHERE SUBSTR(Nome_GAT,1,3) = Pc_Prod;
    --
    Ln_Pos_Lista  NUMBER;
    Lv_Valor_Obp  Trr_ObpV_Users.Valor%TYPE;
    Ln_Pos_fim    NUMBER;

    v_Sms_Credit            NUMBER := NULL;
    v_Sms_Auto_Reload  VARCHAR2(1) := NULL;
    v_Sms_Reload_Period     NUMBER := NULL;
    v_Sms_Keep_Credit      VARCHAR2(1) := NULL;
    v_Sms_Keep_Negative_Credit   VARCHAR2(1) := NULL;

    v_Usuario_cadastrado    VARCHAR2(1);

    c_account_info Trr_Pck_Cur_Type.T_Cur_Type;

  BEGIN
    FOR R_ObpV IN C_ObpV
    LOOP
      Ln_Pos_Lista := INSTR(Pv_Lista_VObp,R_ObpV.Nome_GAT,1);
      --
      -- Alterado para n�o obrigar a validar vari�veis para CXP - Paulo 22/10/2002.
      --

      Ln_Nao_Atualiza := 0;
      IF Ln_Pos_Lista = 0
      THEN
        IF Pc_Prod = 'CXP'
        THEN
          Ln_Nao_Atualiza := 1;
        ELSE
          RETURN(0);  -- Vari�vel inv�lida
        END IF;
      END IF;
      --
      IF Ln_Nao_Atualiza = 0
      THEN
        Ln_Pos_Fim := INSTR(Pv_Lista_VObp,'|',Ln_Pos_Lista) - 1;
        IF Ln_Pos_Fim = -1
        THEN
          Ln_Pos_Fim := LENGTH(Pv_Lista_VObp);
        END IF;
        Lv_Valor_Obp := SUBSTR(Pv_Lista_VObp,
                               Ln_Pos_Lista + (LENGTH(R_ObpV.Nome_GAT || '=') ),
                               Ln_Pos_Fim - Ln_Pos_Lista - LENGTH(R_ObpV.Nome_GAT || '=') + 1 );
        --
        --N�o executa para os SMS
        IF Pc_Prod <> 'SMS'
        THEN
           Ln_Ret_Fun := Trr_Fnc_Add_Obp_Var_Priv(Iv_Id,
                                                 R_ObpV.Nome,
                                                 Lv_Valor_Obp,
                                                 Iv_Cod_Dominio);
          IF Ln_Ret_Fun <> 0
          THEN
            RETURN(3);  -- Erro ao atualizar vari�veis OBP
          END IF;
        END IF;

      END IF;

        --
        -- Guarda os valores das vari�veis do SMS. Cristina 29/12/2003.
        --
        IF Pc_Prod = 'SMS'
        THEN
          IF UPPER(TRIM(R_ObpV.Nome)) = UPPER('sms_credit')
          THEN
            v_Sms_Credit := Lv_Valor_Obp;
          END IF;

          IF UPPER(TRIM(R_ObpV.Nome)) = UPPER('sms_automatic_reload')
          THEN
            select decode(Lv_Valor_Obp,'T','S','N')
            into v_Sms_Auto_Reload
            from dual;
          END IF;

          IF UPPER(TRIM(R_ObpV.Nome)) = UPPER('sms_reload_period_day')
          THEN
            v_Sms_Reload_Period := Lv_Valor_Obp;
          END IF;

          IF UPPER(TRIM(R_ObpV.Nome)) = UPPER('sms_extra_credit')
          THEN
            select decode(Lv_Valor_Obp,'T','S','N')
            into v_Sms_Keep_Credit
            from dual;
          END IF;

          IF UPPER(TRIM(R_ObpV.Nome)) = UPPER('sms_negative_credit')
          THEN
            select decode(Lv_Valor_Obp,'T','S','N')
            into v_Sms_Keep_Negative_Credit
            from dual;
          END IF;
        END IF;

    END LOOP;


    -- Insere/Atualiza os cr�ditos
    -- O valor das vari�veis foi pego no loop acima

    IF Pc_Prod = 'SMS'
    THEN
      --VERIFICA SE USUARIO JA EST� CADASTRADO
      v_Usuario_cadastrado := 'S';
      Ln_Ret_Fun := trr_fnc_query_account(c_account_info,
													  Ln_Snh_Id,
													  Iv_Cod_Dominio,
													  Pc_Prod,
													  'info_contas');
		if (Ln_Ret_Fun = 0) then
			/* usu�rio j� cadastrado no sistema de cr�ditos e d�bitos para o servi�o
			   SMS
			 */
			 v_Usuario_cadastrado := 'S';
			 close c_account_info;
		elsif (Ln_Ret_Fun = -42) then
			-- N�o existe conta para esse usu�rio/servi�o/evento
			 v_Usuario_cadastrado := 'N';
		else
			/* N�o � para acontecer. Repassa erro da SP trr_fnc_query_account a
			   partir do c�digo de erro -21. C�digos de erro poss�veis: -21,
			   -22, -23, -24, -25.
			 */
			 return(-20+Ln_Ret_Fun);
		end if;

      --VERIFICA O NUMERO DE CREDITOS
      IF v_Sms_Credit > 0
      THEN

        IF v_Usuario_cadastrado = 'S'
        THEN
          Ln_Ret_Fun := trr_fnc_autoreload_account(
								Ln_Snh_Id,
								Iv_Cod_Dominio,
								Pc_Prod,
								'credito_sms');
			 if (Ln_Ret_Fun <> 0) then
				/* N�o � para acontecer. Repassa erro da SP trr_fnc_autoreload_account a
					partir do c�digo de erro -151. C�digos de erro poss�veis: -151,
					-152, -153, -154.
				 */
				 return(-150+Ln_Ret_Fun);
			 end if;

          --RECONFIGURA CREDITOS E DEBITOS
          Ln_Ret_Fun := trr_fnc_config_account(
								Ln_Snh_Id,
								Iv_Cod_Dominio,
								Pc_Prod,
								'credito_sms',
								v_Sms_Auto_Reload,
								v_Sms_Reload_Period,
								v_Sms_Keep_Credit,
								v_Sms_Keep_Negative_Credit,
								v_Sms_Credit,
								'venda_planopacote',
								sysdate + v_Sms_Reload_Period,
								'ajuste_saldo');
			 if (Ln_Ret_Fun <> 0) then
				/* N�o � para acontecer. Repassa erro da SP trr_fnc_config_account a
					partir do c�digo de erro -31. C�digos de erro poss�veis: -31,
					-32, -33, -34, -35, -37, -38, -40, -41, -42, -43, -44,
					-72.
				 */
				 return(-30+Ln_Ret_Fun);
			 end if;

        ELSE
          --CADASTRA NO SISTEMA DE CREDITOS E DEBITOS

          Ln_Ret_Fun := trr_fnc_new_account (
									Ln_Snh_Id,
									Iv_Cod_Dominio,
									Pc_Prod,
									'credito_sms',
									v_Sms_Credit,
									v_Sms_Auto_reload,
									v_Sms_Reload_Period,
									v_Sms_keep_credit,
									v_Sms_keep_negative_credit,
									'UNI',
									sysdate + v_Sms_Reload_Period,
									'S',
									'venda_planopacote');
			 if (Ln_Ret_Fun <> 0) then
				/* N�o � para acontecer. Repassa erro da SP trr_fnc_new_account a
					partir do c�digo de erro -81. C�digos de erro poss�veis: -81,
					-82, -83, -84, -85, -86, -87, -88, -89, -90, -91, -92, -93,
					-106.
				 */
				 return(-80+Ln_Ret_Fun);
			 end if;

        END IF;

      ELSIF v_Sms_Credit = 0
         THEN
           IF v_Usuario_cadastrado = 'S'
           THEN
             --REMOVE DO SISTEMA DE CREDITOS E DEBITOS
             Ln_Ret_Fun := trr_fnc_rem_user(
										Ln_Snh_Id,
										Iv_Cod_Dominio);
				 if (Ln_Ret_Fun <> 0) then
					/* N�o � para acontecer. Repassa erro da SP trr_fnc_rem_user a
						partir do c�digo de erro -121. C�digos de erro poss�veis: -121,
						-122, -123, -141.
					 */
					 return(-120+Ln_Ret_Fun);
				 end if;

				 delete from trr_userprodutos
				 where snh_id = ln_snh_id
				 and d_produto = 'SMS';

           END IF;
         END IF;
      END IF;
    --
    RETURN(1);  -- Vari�vel v�lida
    --
  END Fnc_Valida_Atualiza_VObp;

/**-------------------------------------------------------------------------------------------**/
/**                                Procedimento PRINCIPAL                                     **/
/**-------------------------------------------------------------------------------------------**/
BEGIN
  --
  -- Verifica se ID existe e Valida Id no dom�nio
  --
  Ln_Snh_Id := Trr_Fnc_Auth_Id_Central (Iv_Id,
                                        Lv_Senha,
                                        Lc_D_Tp_Usuario,
                                        Iv_Cod_Dominio,
                                        Iv_Dominio);
  IF Ln_Snh_Id = 0
  THEN
    RETURN(-13);  -- ID n�o cadastrado/inexistente
  ELSIF Ln_Snh_Id = -1
  THEN
    RETURN(-1);   -- Par�metro(s) obrigatorio(s) nao informado(s)
  ELSIF Ln_Snh_Id = -2
  THEN
    RETURN(-14);  -- Iv_Cod_Dominio inv�lido ou inexistente
  ELSIF Ln_Snh_Id = -3
  THEN
    RETURN(-15);  -- Iv_Dominio inv�lido ou inexistente
  END IF;
  --
  -- Valida��o dos par�metros
  --
  IF Iv_Id               IS NULL OR
     Iv_Lista_Cod        IS NULL OR
     Iv_Lista_Quota      IS NULL
  THEN
    RETURN(-1);  -- Par�metro(s) obrigatorio(s) nao informado(s)
  END IF;
  --
  -- Verifica e atualiza a lista de par�metros de c�digos de produtos/servi�os
  -- e quotas/vari�veis OBP.
  --
  BEGIN
    Ln_Ocor_Serv    := 1;
    Ln_Pos_Serv     := 1;
    Ln_Pos_Ant_Serv := 1;
    Ln_Tot_Serv     := 0;
    --
    Ln_Ocor_VObp    := 1;
    Ln_Pos_VObp     := 1;
    Ln_Pos_Ant_VObp := 1;
    Ln_Tot_VObp     := 0;
    LOOP
      Ln_Tot_Serv   := Ln_Tot_Serv + 1;
      Ln_Pos_Serv   := INSTR(Iv_Lista_Cod,';',1,Ln_Ocor_Serv);
      --
      IF Ln_Pos_Serv = 0
      THEN
        Lc_Cod     := SUBSTR(Iv_Lista_Cod,Ln_Pos_Ant_Serv,(LENGTH(Iv_Lista_Cod)+1)-Ln_Pos_Ant_Serv);
        Ln_Ret_Fun := Fnc_Valida_Insere_Prod(Lc_Cod);
        IF Ln_Ret_Fun = 0
        THEN
          ROLLBACK;
          RETURN(-3);  -- Valor inv�lido para o par�metro Lista_Cod
        ELSIF Ln_Ret_Fun = 3
        THEN
          ROLLBACK;
          RETURN(-8); -- Erro ao inserir usu�rio nos produtos da base central
        END IF;
      END IF;
      --
      Ln_Tot_VObp   := Ln_Tot_VObp + 1;
      Ln_Pos_VObp   := INSTR(Iv_Lista_Quota,';',1,Ln_Ocor_VObp);
      IF Ln_Pos_VObp = 0
      THEN
        Lv_Lista_VObp := SUBSTR(Iv_Lista_Quota,Ln_Pos_Ant_VObp,(LENGTH(Iv_Lista_Quota)+1)-Ln_Pos_Ant_VObp);
        Ln_Ret_Fun    := Fnc_Valida_Atualiza_VObp(Lc_Cod,Lv_Lista_VObp);
        IF Ln_Ret_Fun = 0
        THEN
          ROLLBACK;
          RETURN(-4);  -- Valor inv�lido para o par�metro Lista_Quota
        ELSIF Ln_Ret_Fun = 3
        THEN
          ROLLBACK;
          RETURN(-9);  -- Erro ao atualizar vari�veis OBP
        ELSIF (Ln_Ret_Fun < 0) THEN
        	 ROLLBACK;
        	 RETURN(Ln_Ret_Fun);
        END IF;
        EXIT;
      END IF;
      --
      Lc_Cod        := SUBSTR(Iv_Lista_Cod,Ln_Pos_Ant_Serv,Ln_Pos_Serv-Ln_Pos_Ant_Serv);
      Ln_Ret_Fun := Fnc_Valida_Insere_Prod(Lc_Cod);
      IF Ln_Ret_Fun = 0
      THEN
        ROLLBACK;
        RETURN(-3);  -- Valor inv�lido para o par�metro Lista_Cod
      ELSIF Ln_Ret_Fun = 3
      THEN
        ROLLBACK;
        RETURN(-8); -- Erro ao inserir usu�rio nos produtos da base central
      END IF;
      --
      Ln_Ocor_Serv     := Ln_Ocor_Serv + 1;
      Ln_Pos_Ant_Serv  := Ln_Pos_Serv  + 1;
      --
      Lv_Lista_VObp := SUBSTR(Iv_Lista_Quota,Ln_Pos_Ant_VObp,Ln_Pos_VObp-Ln_Pos_Ant_VObp);
      --
      Ln_Ret_Fun := Fnc_Valida_Atualiza_VObp(Lc_Cod,Lv_Lista_VObp);
      IF Ln_Ret_Fun = 0
      THEN
        ROLLBACK;
        RETURN(-4);  -- Valor inv�lido para o par�metro Lista_Quota
      ELSIF Ln_Ret_Fun = 3
      THEN
        ROLLBACK;
        RETURN(-9);  -- Erro ao atualizar vari�veis OBP
      ELSIF (Ln_Ret_Fun < 0) THEN
  	     ROLLBACK;
	     RETURN(Ln_Ret_Fun);
	   END IF;
      Ln_Ocor_VObp     := Ln_Ocor_VObp + 1;
      Ln_Pos_Ant_VObp  := Ln_Pos_VObp  + 1;
    END LOOP;
  EXCEPTION
    WHEN OTHERS
    THEN
      ROLLBACK;
      RETURN(-3);  -- Valor inv�lido para o par�metro Lista_Cod
  END;

  RETURN(0);

END trr_fnc_atualiza_quotas_prod_p;
/
