def gTitulo     = 'Sumario de Espa�os Livres de Tablespaces'
-- Tablespace criticas (10% espaco livre) com um '*' na ultima coluna
--set linesize 200
set pagesize 300
spool free
comp sum of totsiz avasiz on report
break on report
col tsname  format         a30  heading 'Tablespace' trunc
col nfrags  format         990  heading 'Nro|Frags'
col mxfrag  format 999,999,990  heading 'Maior|Frag(KB)'
col avfrag  format 999,999,990  heading 'M�dia|Frags(KB)'
col totsiz  format 999,999,990  heading 'Total|(KB)'
col avasiz  format 999,999,990  heading 'Livre|(KB)'
col pctfre  format         a04  heading 'Percentual|Livre'
col warn    format          a1  heading 'W'
col ST	    format	   a02	
select
	total.tablespace_name                       tsname,
        decode(total.status,'ONLINE','  ','READ ONLY','RO','UN') ST,
	count(free.bytes)                           nfrags,
	nvl(max(free.bytes)/1024,0)                 mxfrag,
	nvl(avg(free.bytes)/1024,0)                 avfrag,
	total.bytes/1024                            totsiz,
  	nvl(sum(free.bytes)/1024,0)                 avasiz,
        round(nvl(sum(free.bytes),0)/total.bytes*100)||'%'      pctfre,
	decode(greatest(100*nvl(sum(free.bytes),0)/total.bytes,10),
		10,decode(total.status,'ONLINE','*', ' '),' ')                         warn
from
	(       select  a.tablespace_name,
                        b.status,
			sum(a.bytes)        bytes
		from    sys.dba_data_files a, sys.dba_tablespaces b
                where   a.tablespace_name = b.tablespace_name
		group by a.tablespace_name, b.status) total,
	dba_free_space  free
where
	total.tablespace_name = free.tablespace_name(+)
group by
	total.tablespace_name,
	total.bytes,
        TOTAL.STATUS
/
undefine gScript
undefine gTitulo
ttitle off
btitle off
--clear column
--clear breaks

