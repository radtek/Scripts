col operation for a70
select     lpad(' ',2*(level-1))|| decode(id,0,operation||' '||options||' '||object_name||' Cost:'||cost,operation||' '||options||' '||object_name) operation
   , optimizer
   , cardinality num_rows
        , PARTITION_START
        , PARTITION_STOP
   ,object_node
 from (
      select *
      from v$sql_plan a
      where a.hash_value = &Hash_value)
start with id = 0
connect by prior id = parent_id
/
