spool rebuild_idx_reme.log
set echo on 
set time on
set timing on

alter session set sort_area_size=100000000;

alter user mail quota unlimited on mail_trr_remetentes_index;


ALTER INDEX MAIL.REME_PK REBUILD
 TABLESPACE mail_trr_remetentes_index unrecoverable Online;
analyze index MAIL.REME_PK compute statistics;

ALTER INDEX MAIL.REME_EMAIL_LIREME_UK2 REBUILD
 TABLESPACE mail_trr_remetentes_index unrecoverable Online;
analyze index MAIL.REME_EMAIL_LIREME_UK2 compute statistics;

ALTER INDEX MAIL.LIREME_FK_TIPO_REME_EMAIL_ACAO REBUILD
 TABLESPACE mail_trr_remetentes_index unrecoverable Online;
analyze index MAIL.LIREME_FK_TIPO_REME_EMAIL_ACAO compute statistics;


spool off;
exit;



