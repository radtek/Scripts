set echo on
set timing on
set time on
spool cr_new_tablespace.log

/*

create tablespace bd_central_trr_senhas_index datafile 
'/o04/oradata/oradb1/bd_central_trr_senhas_index_01.dbf' size 100m autoextend on next 100m maxsize 2000m,
'/o05/oradata/oradb1/bd_central_trr_senhas_index_02.dbf' size 100m autoextend on next 100m maxsize 2000m,
'/o06/oradata/oradb1/bd_central_trr_senhas_index_03.dbf' size 100m autoextend on next 100m maxsize 2000m
extent management local autoallocate;


*/

create tablespace mail_trr_remetentes_index datafile
'/o04/oradata/oradb1/mail_trr_remetentes_index_01.dbf' size 1500m autoextend on next 100m maxsize 2000m,
'/o05/oradata/oradb1/mail_trr_remetentes_index_02.dbf' size 1500m autoextend on next 100m maxsize 2000m,
'/o06/oradata/oradb1/mail_trr_remetentes_index_03.dbf' size 1500m autoextend on next 100m maxsize 2000m,
'/o04/oradata/oradb1/mail_trr_remetentes_index_04.dbf' size 1500m autoextend on next 100m maxsize 2000m
extent management local uniform size 64m;

spool off;
exit;

