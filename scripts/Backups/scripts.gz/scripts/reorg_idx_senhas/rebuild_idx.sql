spool rebuild_idx.log
set echo on 
set time on
set timing on

alter session set sort_area_size=100000000;

/*
ALTER INDEX BD_CENTRAL.SNH_PK REBUILD
 TABLESPACE bd_central_trr_senhas_index unrecoverable Online;

analyze index BD_CENTRAL.SNH_PK compute statistics; 

ALTER INDEX BD_CENTRAL.SNHID_CDOMID_TPUSU_SENHA REBUILD
 TABLESPACE bd_central_trr_senhas_index unrecoverable Online;

analyze index BD_CENTRAL.SNHID_CDOMID_TPUSU_SENHA compute statistics;
*/


ALTER INDEX BD_CENTRAL.IDX_EMAIL_DEF_CDOM_ID REBUILD  PARTITION TRR_SENHAS_OTHERS
 TABLESPACE bd_central_trr_senhas_index nologging Online;

ALTER INDEX BD_CENTRAL.IDX_EMAIL_DEF_CDOM_ID REBUILD  PARTITION TRR_SENHAS_TERRA
 TABLESPACE bd_central_trr_senhas_index nologging  Online;

analyze index BD_CENTRAL.IDX_EMAIL_DEF_CDOM_ID compute statistics;
alter index BD_CENTRAL.IDX_EMAIL_DEF_CDOM_ID  logging;

ALTER INDEX BD_CENTRAL.snh_uk REBUILD partition SNH_UK_OTHERS
 TABLESPACE bd_central_trr_senhas_index nologging Online;

ALTER INDEX BD_CENTRAL.snh_uk REBUILD partition SNH_UK_TERRA
 TABLESPACE bd_central_trr_senhas_index nologging Online;
 
analyze index BD_CENTRAL.snh_uk compute statistics;

alter index BD_CENTRAL.snh_uk logging;


spool off;
exit;



