select 'alter rollback segment '||segment_name||' shrink;'
  from dba_rollback_segs
 where status = 'ONLINE';
