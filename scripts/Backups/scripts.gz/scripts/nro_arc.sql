select trunc(first_time),count(*) from v$log_history
group by trunc(first_time)
order by  trunc(first_time)
/
