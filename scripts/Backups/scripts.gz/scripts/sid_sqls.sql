undefine sidi;
select DISTINCT b.disk_reads,b.executions,b.sql_text,b.hash_value, b.rows_processed
 from v$open_cursor a, v$sqlarea b
where a.address    = b.address
  and a.hash_value = b.hash_value
  and a.sid        = &sidi
order by 1,2
/
