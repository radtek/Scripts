set echo on
set timing on
set lines 100
set pages 0
spool /home/oracle/list_to_expire.txt
select email || decode (brand,'terra',null,'!'||brand) email
from ajustabd.trr_expired_users
where dt_ins >= '11/10/2003';
spool off;
exit;

