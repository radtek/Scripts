select d.tablespace_name,d.file_name,
       to_char(b.time,'dd/mm/yyyy hh24:mi:ss') Data,b.status
  from dba_data_files d, v$backup b
 where d.file_id = b.file# 
order by b.status,d.tablespace_name,d.file_name,b.time;
