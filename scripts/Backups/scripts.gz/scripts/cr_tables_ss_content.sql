spool cr_tables_ss_content.log
set echo on
set timing on
set time on

conn ss_content/s7lmf3ps

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_CAMPEONATOS
create table ss_content.BR_AOVIVO_FUTEBOL_CAMPEONATOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_CAMPEONATOS@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_EQUIPES
create table ss_content.BR_AOVIVO_FUTEBOL_EQUIPES Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_EQUIPES@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_ESCALACAO
create table ss_content.BR_AOVIVO_FUTEBOL_ESCALACAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_ESCALACAO@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_ESTATISTICA
create table ss_content.BR_AOVIVO_FUTEBOL_ESTATISTICA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_ESTATISTICA@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_FASES
create table ss_content.BR_AOVIVO_FUTEBOL_FASES Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_FASES@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_GOLS
create table ss_content.BR_AOVIVO_FUTEBOL_GOLS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_GOLS@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_GRUPO
create table ss_content.BR_AOVIVO_FUTEBOL_GRUPO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_GRUPO@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_GRUPO_EQUIPE
create table ss_content.BR_AOVIVO_FUTEBOL_GRUPO_EQUIPE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_GRUPO_EQUIPE@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_ICONES
create table ss_content.BR_AOVIVO_FUTEBOL_ICONES Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_ICONES@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_JGNARRA
create table ss_content.BR_AOVIVO_FUTEBOL_JGNARRA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_JGNARRA@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_JOGADOR
create table ss_content.BR_AOVIVO_FUTEBOL_JOGADOR Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_JOGADOR@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_JOGOS
create table ss_content.BR_AOVIVO_FUTEBOL_JOGOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_JOGOS@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_NARRACAO
create table ss_content.BR_AOVIVO_FUTEBOL_NARRACAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_NARRACAO@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_FUTEBOL_TEMPO
create table ss_content.BR_AOVIVO_FUTEBOL_TEMPO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_FUTEBOL_TEMPO@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_SEQUENCIA
create table ss_content.BR_AOVIVO_SEQUENCIA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_SEQUENCIA@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_TENIS_ESTATISTICA
create table ss_content.BR_AOVIVO_TENIS_ESTATISTICA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_TENIS_ESTATISTICA@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_TENIS_JOGOS
create table ss_content.BR_AOVIVO_TENIS_JOGOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_TENIS_JOGOS@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_TENIS_NARRACAO
create table ss_content.BR_AOVIVO_TENIS_NARRACAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_TENIS_NARRACAO@orass1
;

Prompt ReCriando tabela:BR_AOVIVO_TENIS_PLACAR
create table ss_content.BR_AOVIVO_TENIS_PLACAR Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_AOVIVO_TENIS_PLACAR@orass1
;

Prompt ReCriando tabela:BR_CAPA_CHAMADAS
create table ss_content.BR_CAPA_CHAMADAS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CAPA_CHAMADAS@orass1
;

Prompt ReCriando tabela:BR_CAPA_CIDADES
create table ss_content.BR_CAPA_CIDADES Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CAPA_CIDADES@orass1
;

Prompt ReCriando tabela:BR_CAPA_CONFIG
create table ss_content.BR_CAPA_CONFIG Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CAPA_CONFIG@orass1
;

Prompt ReCriando tabela:BR_CAPA_LOCK
create table ss_content.BR_CAPA_LOCK Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CAPA_LOCK@orass1
;

Prompt ReCriando tabela:BR_CAPA_LOG
create table ss_content.BR_CAPA_LOG Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CAPA_LOG@orass1
;

Prompt ReCriando tabela:BR_CAPA_LOG_BAK
create table ss_content.BR_CAPA_LOG_BAK Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CAPA_LOG_BAK@orass1
;

Prompt ReCriando tabela:BR_CAPA_MODELOS
create table ss_content.BR_CAPA_MODELOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CAPA_MODELOS@orass1
;

Prompt ReCriando tabela:BR_CAPA_MURAL
create table ss_content.BR_CAPA_MURAL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CAPA_MURAL@orass1
;

Prompt ReCriando tabela:BR_CAPA_POPUPREGIONAL
create table ss_content.BR_CAPA_POPUPREGIONAL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CAPA_POPUPREGIONAL@orass1
;

Prompt ReCriando tabela:BR_CAPA_PRINCIPAL
create table ss_content.BR_CAPA_PRINCIPAL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CAPA_PRINCIPAL@orass1
;

Prompt ReCriando tabela:BR_CAPA_PRINCIPAL_CONFIG
create table ss_content.BR_CAPA_PRINCIPAL_CONFIG Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CAPA_PRINCIPAL_CONFIG@orass1
;

Prompt ReCriando tabela:BR_CAPA_SECAO
create table ss_content.BR_CAPA_SECAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CAPA_SECAO@orass1
;

Prompt ReCriando tabela:BR_CARNAVAL2002_AOVIVO
create table ss_content.BR_CARNAVAL2002_AOVIVO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CARNAVAL2002_AOVIVO@orass1
;

Prompt ReCriando tabela:BR_CARNAVAL2002_AOVIVODEFAULT
create table ss_content.BR_CARNAVAL2002_AOVIVODEFAULT Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CARNAVAL2002_AOVIVODEFAULT@orass1
;

Prompt ReCriando tabela:BR_CARNAVAL2002_AOVIVO_BAK
create table ss_content.BR_CARNAVAL2002_AOVIVO_BAK Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CARNAVAL2002_AOVIVO_BAK@orass1
;

Prompt ReCriando tabela:BR_CARNAVAL_APURACAO_ESCOLA
create table ss_content.BR_CARNAVAL_APURACAO_ESCOLA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CARNAVAL_APURACAO_ESCOLA@orass1
;

Prompt ReCriando tabela:BR_CARNAVAL_APURACAO_QUESITO
create table ss_content.BR_CARNAVAL_APURACAO_QUESITO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CARNAVAL_APURACAO_QUESITO@orass1
;

Prompt ReCriando tabela:BR_CARNAVAL_APURACAO_RESULTADO
create table ss_content.BR_CARNAVAL_APURACAO_RESULTADO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CARNAVAL_APURACAO_RESULTADO@orass1
;

Prompt ReCriando tabela:BR_CIDADES_CIDADE
create table ss_content.BR_CIDADES_CIDADE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDADES_CIDADE@orass1
;

Prompt ReCriando tabela:BR_CIDADES_CINEMA
create table ss_content.BR_CIDADES_CINEMA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDADES_CINEMA@orass1
;

Prompt ReCriando tabela:BR_CIDADES_FILMESESTREIAS_TEMP
create table ss_content.BR_CIDADES_FILMESESTREIAS_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDADES_FILMESESTREIAS_TEMP@orass1
;

Prompt ReCriando tabela:BR_CIDADES_GRUPOCINEMA
create table ss_content.BR_CIDADES_GRUPOCINEMA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDADES_GRUPOCINEMA@orass1
;

Prompt ReCriando tabela:BR_CIDADES_SALACINEMA
create table ss_content.BR_CIDADES_SALACINEMA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDADES_SALACINEMA@orass1
;

Prompt ReCriando tabela:BR_CIDADES_SESSAOCINEMA
create table ss_content.BR_CIDADES_SESSAOCINEMA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDADES_SESSAOCINEMA@orass1
;

Prompt ReCriando tabela:BR_CIDADES_SESSAOCINEMA_TEMP
create table ss_content.BR_CIDADES_SESSAOCINEMA_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDADES_SESSAOCINEMA_TEMP@orass1
;

Prompt ReCriando tabela:BR_CIDADES_SESSAOESTADO
create table ss_content.BR_CIDADES_SESSAOESTADO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDADES_SESSAOESTADO@orass1
;

Prompt ReCriando tabela:BR_CIDADES_SESSAO_CINEMA_LOG
create table ss_content.BR_CIDADES_SESSAO_CINEMA_LOG Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDADES_SESSAO_CINEMA_LOG@orass1
;

Prompt ReCriando tabela:BR_CIDADES_USUARIOCIDADE
create table ss_content.BR_CIDADES_USUARIOCIDADE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDADES_USUARIOCIDADE@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_AGENDAMENTO
create table ss_content.BR_CIDVIRT_AGENDAMENTO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_AGENDAMENTO@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_AMBIENTE
create table ss_content.BR_CIDVIRT_AMBIENTE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_AMBIENTE@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_CARTAO_CREDITO
create table ss_content.BR_CIDVIRT_CARTAO_CREDITO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_CARTAO_CREDITO@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_CARTOES_ACEITOS
create table ss_content.BR_CIDVIRT_CARTOES_ACEITOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_CARTOES_ACEITOS@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_CARTOES_TEMP
create table ss_content.BR_CIDVIRT_CARTOES_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_CARTOES_TEMP@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_CATEGORIA
create table ss_content.BR_CIDVIRT_CATEGORIA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_CATEGORIA@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_CIDADE
create table ss_content.BR_CIDVIRT_CIDADE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_CIDADE@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_EDITORIA_EXTRAS
create table ss_content.BR_CIDVIRT_EDITORIA_EXTRAS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_EDITORIA_EXTRAS@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_ESPECIALIDADE
create table ss_content.BR_CIDVIRT_ESPECIALIDADE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_ESPECIALIDADE@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_EVENTO
create table ss_content.BR_CIDVIRT_EVENTO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_EVENTO@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_EVENTO2
create table ss_content.BR_CIDVIRT_EVENTO2 Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_EVENTO2@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_EVENTO_FAIXAPRECO
create table ss_content.BR_CIDVIRT_EVENTO_FAIXAPRECO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_EVENTO_FAIXAPRECO@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_FILME_STATUS
create table ss_content.BR_CIDVIRT_FILME_STATUS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_FILME_STATUS@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_FILME_STATUS_BAK
create table ss_content.BR_CIDVIRT_FILME_STATUS_BAK Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_FILME_STATUS_BAK@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_GENERO
create table ss_content.BR_CIDVIRT_GENERO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_GENERO@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_LOCAL
create table ss_content.BR_CIDVIRT_LOCAL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_LOCAL@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_LOCAL_ELEMENTO
create table ss_content.BR_CIDVIRT_LOCAL_ELEMENTO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_LOCAL_ELEMENTO@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_LOCAL_FAIXAPRECO
create table ss_content.BR_CIDVIRT_LOCAL_FAIXAPRECO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_LOCAL_FAIXAPRECO@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_PATROCINIO
create table ss_content.BR_CIDVIRT_PATROCINIO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_PATROCINIO@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_PREMIOS
create table ss_content.BR_CIDVIRT_PREMIOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_PREMIOS@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_PREMIOS_GANHO
create table ss_content.BR_CIDVIRT_PREMIOS_GANHO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_PREMIOS_GANHO@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_PUBLICIDADE
create table ss_content.BR_CIDVIRT_PUBLICIDADE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_PUBLICIDADE@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_SERVICO
create table ss_content.BR_CIDVIRT_SERVICO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_SERVICO@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_SERVICO_ELEMENTO
create table ss_content.BR_CIDVIRT_SERVICO_ELEMENTO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_SERVICO_ELEMENTO@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_SERV_CART_ACEITOS
create table ss_content.BR_CIDVIRT_SERV_CART_ACEITOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_SERV_CART_ACEITOS@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_TEMP1
create table ss_content.BR_CIDVIRT_TEMP1 Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_TEMP1@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_TEMP2
create table ss_content.BR_CIDVIRT_TEMP2 Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_TEMP2@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_VALEREF
create table ss_content.BR_CIDVIRT_VALEREF Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_VALEREF@orass1
;

Prompt ReCriando tabela:BR_CIDVIRT_VALEREF_ACEITOS
create table ss_content.BR_CIDVIRT_VALEREF_ACEITOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CIDVIRT_VALEREF_ACEITOS@orass1
;

Prompt ReCriando tabela:BR_CINEMA_ATOR
create table ss_content.BR_CINEMA_ATOR Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_ATOR@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CAPABILHETERIA
create table ss_content.BR_CINEMA_CAPABILHETERIA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CAPABILHETERIA@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CAPAENQUETE
create table ss_content.BR_CINEMA_CAPAENQUETE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CAPAENQUETE@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CAPAESPECIAL
create table ss_content.BR_CINEMA_CAPAESPECIAL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CAPAESPECIAL@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CAPAESTREIAS
create table ss_content.BR_CINEMA_CAPAESTREIAS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CAPAESTREIAS@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CAPANOTICIA
create table ss_content.BR_CINEMA_CAPANOTICIA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CAPANOTICIA@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CAPAPARTICIPE
create table ss_content.BR_CINEMA_CAPAPARTICIPE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CAPAPARTICIPE@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CAPA_BILHETERIATEMP
create table ss_content.BR_CINEMA_CAPA_BILHETERIATEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CAPA_BILHETERIATEMP@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CAPA_ENQUETETEMP
create table ss_content.BR_CINEMA_CAPA_ENQUETETEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CAPA_ENQUETETEMP@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CAPA_ESPECIALTEMP
create table ss_content.BR_CINEMA_CAPA_ESPECIALTEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CAPA_ESPECIALTEMP@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CAPA_ESTREIASTEMP
create table ss_content.BR_CINEMA_CAPA_ESTREIASTEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CAPA_ESTREIASTEMP@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CAPA_NOTICIATEMP
create table ss_content.BR_CINEMA_CAPA_NOTICIATEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CAPA_NOTICIATEMP@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CAPA_PARTICIPETEMP
create table ss_content.BR_CINEMA_CAPA_PARTICIPETEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CAPA_PARTICIPETEMP@orass1
;

Prompt ReCriando tabela:BR_CINEMA_CINEMAS
create table ss_content.BR_CINEMA_CINEMAS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_CINEMAS@orass1
;

Prompt ReCriando tabela:BR_CINEMA_DVDS
create table ss_content.BR_CINEMA_DVDS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_DVDS@orass1
;

Prompt ReCriando tabela:BR_CINEMA_DVDS_DUBLAGEM
create table ss_content.BR_CINEMA_DVDS_DUBLAGEM Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_DVDS_DUBLAGEM@orass1
;

Prompt ReCriando tabela:BR_CINEMA_DVDS_LEGENDA
create table ss_content.BR_CINEMA_DVDS_LEGENDA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_DVDS_LEGENDA@orass1
;

Prompt ReCriando tabela:BR_CINEMA_DVD_RECURSOS
create table ss_content.BR_CINEMA_DVD_RECURSOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_DVD_RECURSOS@orass1
;

Prompt ReCriando tabela:BR_CINEMA_EQUIPE
create table ss_content.BR_CINEMA_EQUIPE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_EQUIPE@orass1
;

Prompt ReCriando tabela:BR_CINEMA_ESTREIA_DESTAQUE
create table ss_content.BR_CINEMA_ESTREIA_DESTAQUE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_ESTREIA_DESTAQUE@orass1
;

Prompt ReCriando tabela:BR_CINEMA_ESTUDIO
create table ss_content.BR_CINEMA_ESTUDIO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_ESTUDIO@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FESTIVAL
create table ss_content.BR_CINEMA_FESTIVAL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FESTIVAL@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FESTIVALEDICAO
create table ss_content.BR_CINEMA_FESTIVALEDICAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FESTIVALEDICAO@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FESTIVAL_TIPO
create table ss_content.BR_CINEMA_FESTIVAL_TIPO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FESTIVAL_TIPO@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILME
create table ss_content.BR_CINEMA_FILME Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILME@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILMECARTAZ_TEMP
create table ss_content.BR_CINEMA_FILMECARTAZ_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILMECARTAZ_TEMP@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILMECONSULTA_TEMP
create table ss_content.BR_CINEMA_FILMECONSULTA_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILMECONSULTA_TEMP@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILMEESTUDIO
create table ss_content.BR_CINEMA_FILMEESTUDIO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILMEESTUDIO@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILMEGENERO
create table ss_content.BR_CINEMA_FILMEGENERO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILMEGENERO@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILMEGENERO_BAK
create table ss_content.BR_CINEMA_FILMEGENERO_BAK Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILMEGENERO_BAK@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILMEGENERO_TEMP
create table ss_content.BR_CINEMA_FILMEGENERO_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILMEGENERO_TEMP@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILMELINGUA
create table ss_content.BR_CINEMA_FILMELINGUA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILMELINGUA@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILMEPAIS
create table ss_content.BR_CINEMA_FILMEPAIS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILMEPAIS@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILMES2
create table ss_content.BR_CINEMA_FILMES2 Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILMES2@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILMES2_TEMP
create table ss_content.BR_CINEMA_FILMES2_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILMES2_TEMP@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILMESITE
create table ss_content.BR_CINEMA_FILMESITE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILMESITE@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILME_LINGUA
create table ss_content.BR_CINEMA_FILME_LINGUA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILME_LINGUA@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILME_PAIS
create table ss_content.BR_CINEMA_FILME_PAIS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILME_PAIS@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILME_STATUS
create table ss_content.BR_CINEMA_FILME_STATUS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILME_STATUS@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILME_TEMP
create table ss_content.BR_CINEMA_FILME_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILME_TEMP@orass1
;

Prompt ReCriando tabela:BR_CINEMA_FILME_VOTACAO
create table ss_content.BR_CINEMA_FILME_VOTACAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_FILME_VOTACAO@orass1
;

Prompt ReCriando tabela:BR_CINEMA_GENERO
create table ss_content.BR_CINEMA_GENERO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_GENERO@orass1
;

Prompt ReCriando tabela:BR_CINEMA_NOTICIA
create table ss_content.BR_CINEMA_NOTICIA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_NOTICIA@orass1
;

Prompt ReCriando tabela:BR_CINEMA_NOTICIA_CATEGORIA
create table ss_content.BR_CINEMA_NOTICIA_CATEGORIA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_NOTICIA_CATEGORIA@orass1
;

Prompt ReCriando tabela:BR_CINEMA_NOTICIA_TEMP
create table ss_content.BR_CINEMA_NOTICIA_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_NOTICIA_TEMP@orass1
;

Prompt ReCriando tabela:BR_CINEMA_PREMIO
create table ss_content.BR_CINEMA_PREMIO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_PREMIO@orass1
;

Prompt ReCriando tabela:BR_CINEMA_PREMIOFILME
create table ss_content.BR_CINEMA_PREMIOFILME Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_PREMIOFILME@orass1
;

Prompt ReCriando tabela:BR_CINEMA_PREMIOPESSOA
create table ss_content.BR_CINEMA_PREMIOPESSOA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_PREMIOPESSOA@orass1
;

Prompt ReCriando tabela:BR_CINEMA_RECURSO
create table ss_content.BR_CINEMA_RECURSO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_RECURSO@orass1
;

Prompt ReCriando tabela:BR_CINEMA_STATUS_SUB
create table ss_content.BR_CINEMA_STATUS_SUB Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_STATUS_SUB@orass1
;

Prompt ReCriando tabela:BR_CINEMA_TRAILER
create table ss_content.BR_CINEMA_TRAILER Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_TRAILER@orass1
;

Prompt ReCriando tabela:BR_CINEMA_TRAILER_DESTAQUE
create table ss_content.BR_CINEMA_TRAILER_DESTAQUE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CINEMA_TRAILER_DESTAQUE@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_ACOMPANHAMENTO
create table ss_content.BR_CULINARIA_ACOMPANHAMENTO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_ACOMPANHAMENTO@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_CATEGORIA
create table ss_content.BR_CULINARIA_CATEGORIA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_CATEGORIA@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_DORIANA_TEMP
create table ss_content.BR_CULINARIA_DORIANA_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_DORIANA_TEMP@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_INGREDIENTES
create table ss_content.BR_CULINARIA_INGREDIENTES Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_INGREDIENTES@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_RECEITA
create table ss_content.BR_CULINARIA_RECEITA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_RECEITA@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_RECEITA_TERRA
create table ss_content.BR_CULINARIA_RECEITA_TERRA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_RECEITA_TERRA@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_RECEITA_USUARIO
create table ss_content.BR_CULINARIA_RECEITA_USUARIO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_RECEITA_USUARIO@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_REINGRED
create table ss_content.BR_CULINARIA_REINGRED Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_REINGRED@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_UNILEVER_CLASSREC
create table ss_content.BR_CULINARIA_UNILEVER_CLASSREC Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_UNILEVER_CLASSREC@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_UNILEVER_IDS
create table ss_content.BR_CULINARIA_UNILEVER_IDS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_UNILEVER_IDS@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_UNILEVER_MARCA
create table ss_content.BR_CULINARIA_UNILEVER_MARCA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_UNILEVER_MARCA@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_UNILEVER_OCASIAO
create table ss_content.BR_CULINARIA_UNILEVER_OCASIAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_UNILEVER_OCASIAO@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_UNILEVER_PRODUTO
create table ss_content.BR_CULINARIA_UNILEVER_PRODUTO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_UNILEVER_PRODUTO@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_UNILEVER_RECEITA
create table ss_content.BR_CULINARIA_UNILEVER_RECEITA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_UNILEVER_RECEITA@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_UNILEVER_RECPROD
create table ss_content.BR_CULINARIA_UNILEVER_RECPROD Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_UNILEVER_RECPROD@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_UNILEVER_TPRECEIT
create table ss_content.BR_CULINARIA_UNILEVER_TPRECEIT Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_UNILEVER_TPRECEIT@orass1
;

Prompt ReCriando tabela:BR_CULINARIA_UNILEVER_USO
create table ss_content.BR_CULINARIA_UNILEVER_USO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_CULINARIA_UNILEVER_USO@orass1
;

Prompt ReCriando tabela:BR_DEBUG_LOG
create table ss_content.BR_DEBUG_LOG Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_DEBUG_LOG@orass1 where 1<>1
;

Prompt ReCriando tabela:BR_DIVNET_ELEICOES
create table ss_content.BR_DIVNET_ELEICOES Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_DIVNET_ELEICOES@orass1
;

Prompt ReCriando tabela:BR_DIVNET_LOCAISVOT
create table ss_content.BR_DIVNET_LOCAISVOT Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_DIVNET_LOCAISVOT@orass1
;

Prompt ReCriando tabela:BR_DIVNET_MSGS_USUARIOS
create table ss_content.BR_DIVNET_MSGS_USUARIOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_DIVNET_MSGS_USUARIOS@orass1
;

Prompt ReCriando tabela:BR_EDUCACAO_PROVAOAREA
create table ss_content.BR_EDUCACAO_PROVAOAREA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_EDUCACAO_PROVAOAREA@orass1
;

Prompt ReCriando tabela:BR_EDUCACAO_PROVAOAREA_BAK
create table ss_content.BR_EDUCACAO_PROVAOAREA_BAK Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_EDUCACAO_PROVAOAREA_BAK@orass1
;

Prompt ReCriando tabela:BR_EDUCACAO_PROVAOAVALIACAO
create table ss_content.BR_EDUCACAO_PROVAOAVALIACAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_EDUCACAO_PROVAOAVALIACAO@orass1
;

Prompt ReCriando tabela:BR_EDUCACAO_PROVAOAVALIACAO_BA
create table ss_content.BR_EDUCACAO_PROVAOAVALIACAO_BA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_EDUCACAO_PROVAOAVALIACAO_BA@orass1
;

Prompt ReCriando tabela:BR_EDUCACAO_PROVAOCAMPUS
create table ss_content.BR_EDUCACAO_PROVAOCAMPUS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_EDUCACAO_PROVAOCAMPUS@orass1
;

Prompt ReCriando tabela:BR_EDUCACAO_PROVAOCAMPUS_BAK
create table ss_content.BR_EDUCACAO_PROVAOCAMPUS_BAK Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_EDUCACAO_PROVAOCAMPUS_BAK@orass1
;

Prompt ReCriando tabela:BR_EDUCACAO_PROVAOCIDADES
create table ss_content.BR_EDUCACAO_PROVAOCIDADES Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_EDUCACAO_PROVAOCIDADES@orass1
;

Prompt ReCriando tabela:BR_EDUCACAO_PROVAOCIDADES_BAK
create table ss_content.BR_EDUCACAO_PROVAOCIDADES_BAK Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_EDUCACAO_PROVAOCIDADES_BAK@orass1
;

Prompt ReCriando tabela:BR_EDUCACAO_PROVAOINSTITUICAO
create table ss_content.BR_EDUCACAO_PROVAOINSTITUICAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_EDUCACAO_PROVAOINSTITUICAO@orass1
;

Prompt ReCriando tabela:BR_EDUCACAO_PROVAOINSTITUICAO_
create table ss_content.BR_EDUCACAO_PROVAOINSTITUICAO_ Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_EDUCACAO_PROVAOINSTITUICAO_@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_CANDIDATO
create table ss_content.BR_ELEICOES_CANDIDATO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_CANDIDATO@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_CANDIDATOS
create table ss_content.BR_ELEICOES_CANDIDATOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_CANDIDATOS@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_CARGO
create table ss_content.BR_ELEICOES_CARGO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_CARGO@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_COLIG_PART_ISOLADO
create table ss_content.BR_ELEICOES_COLIG_PART_ISOLADO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_COLIG_PART_ISOLADO@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_MUNICIPIO
create table ss_content.BR_ELEICOES_MUNICIPIO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_MUNICIPIO@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_PARTIDO
create table ss_content.BR_ELEICOES_PARTIDO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_PARTIDO@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_RESULTADO
create table ss_content.BR_ELEICOES_RESULTADO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_RESULTADO@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_SUBSTITUIDO
create table ss_content.BR_ELEICOES_SUBSTITUIDO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_SUBSTITUIDO@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_TOTAIS
create table ss_content.BR_ELEICOES_TOTAIS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_TOTAIS@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_VICE
create table ss_content.BR_ELEICOES_VICE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_VICE@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_VOTCOLIG_PART_ISOL
create table ss_content.BR_ELEICOES_VOTCOLIG_PART_ISOL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_VOTCOLIG_PART_ISOL@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_VOTOSCANDIDATO
create table ss_content.BR_ELEICOES_VOTOSCANDIDATO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_VOTOSCANDIDATO@orass1
;

Prompt ReCriando tabela:BR_ELEICOES_VOTOSPARTIDO
create table ss_content.BR_ELEICOES_VOTOSPARTIDO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ELEICOES_VOTOSPARTIDO@orass1
;

Prompt ReCriando tabela:BR_ENQUETE_ENQUETE
create table ss_content.BR_ENQUETE_ENQUETE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ENQUETE_ENQUETE@orass1
;

Prompt ReCriando tabela:BR_ENQUETE_VOTOS
create table ss_content.BR_ENQUETE_VOTOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ENQUETE_VOTOS@orass1
;

Prompt ReCriando tabela:BR_ENQUETE_VOTOS_FILA
create table ss_content.BR_ENQUETE_VOTOS_FILA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ENQUETE_VOTOS_FILA@orass1
;

Prompt ReCriando tabela:BR_ESPORTES_TENIS_JOGADOR
create table ss_content.BR_ESPORTES_TENIS_JOGADOR Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ESPORTES_TENIS_JOGADOR@orass1
;

Prompt ReCriando tabela:BR_ESPORTES_TENIS_TORNEIO
create table ss_content.BR_ESPORTES_TENIS_TORNEIO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_ESPORTES_TENIS_TORNEIO@orass1
;

Prompt ReCriando tabela:BR_GERADOR_CANAL_CAPA_D
create table ss_content.BR_GERADOR_CANAL_CAPA_D Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_GERADOR_CANAL_CAPA_D@orass1
;

Prompt ReCriando tabela:BR_GERADOR_CANAL_D
create table ss_content.BR_GERADOR_CANAL_D Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_GERADOR_CANAL_D@orass1
;

Prompt ReCriando tabela:BR_GERADOR_CANAL_MENU_D
create table ss_content.BR_GERADOR_CANAL_MENU_D Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_GERADOR_CANAL_MENU_D@orass1
;

Prompt ReCriando tabela:BR_GERADOR_MENUOPCAO_D
create table ss_content.BR_GERADOR_MENUOPCAO_D Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_GERADOR_MENUOPCAO_D@orass1
;

Prompt ReCriando tabela:BR_GERADOR_MENU_D
create table ss_content.BR_GERADOR_MENU_D Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_GERADOR_MENU_D@orass1
;

Prompt ReCriando tabela:BR_GERADOR_TEMPLATECAPA_D
create table ss_content.BR_GERADOR_TEMPLATECAPA_D Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_GERADOR_TEMPLATECAPA_D@orass1
;

Prompt ReCriando tabela:BR_IBM_CADASTRO
create table ss_content.BR_IBM_CADASTRO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_IBM_CADASTRO@orass1
;

Prompt ReCriando tabela:BR_IBM_OBRAS
create table ss_content.BR_IBM_OBRAS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_IBM_OBRAS@orass1
;

Prompt ReCriando tabela:BR_IBM_PRECADASTRO
create table ss_content.BR_IBM_PRECADASTRO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_IBM_PRECADASTRO@orass1
;

Prompt ReCriando tabela:BR_IBM_VOTOS
create table ss_content.BR_IBM_VOTOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_IBM_VOTOS@orass1
;

Prompt ReCriando tabela:BR_IMPORT_TEMP
create table ss_content.BR_IMPORT_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_IMPORT_TEMP@orass1
;

Prompt ReCriando tabela:BR_INVERTIA_ACOES
create table ss_content.BR_INVERTIA_ACOES Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_INVERTIA_ACOES@orass1
;

Prompt ReCriando tabela:BR_INVERTIA_BOLSAS
create table ss_content.BR_INVERTIA_BOLSAS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_INVERTIA_BOLSAS@orass1
;

Prompt ReCriando tabela:BR_INVERTIA_MOEDAS
create table ss_content.BR_INVERTIA_MOEDAS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_INVERTIA_MOEDAS@orass1
;

Prompt ReCriando tabela:BR_LOG_PARAM_ERRORS
create table ss_content.BR_LOG_PARAM_ERRORS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOG_PARAM_ERRORS@orass1 where 1<>1
;

Prompt ReCriando tabela:BR_LOTERIAS_CHAMADAS
create table ss_content.BR_LOTERIAS_CHAMADAS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_CHAMADAS@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_CHAMADAS_BKP
create table ss_content.BR_LOTERIAS_CHAMADAS_BKP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_CHAMADAS_BKP@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_CONCURSO
create table ss_content.BR_LOTERIAS_CONCURSO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_CONCURSO@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_CONCURSORESULTADO
create table ss_content.BR_LOTERIAS_CONCURSORESULTADO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_CONCURSORESULTADO@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_CONCURSORESUL_BKP
create table ss_content.BR_LOTERIAS_CONCURSORESUL_BKP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_CONCURSORESUL_BKP@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_CONCURSO_BKP
create table ss_content.BR_LOTERIAS_CONCURSO_BKP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_CONCURSO_BKP@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_FAIXA
create table ss_content.BR_LOTERIAS_FAIXA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_FAIXA@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_FAIXA_BKP
create table ss_content.BR_LOTERIAS_FAIXA_BKP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_FAIXA_BKP@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_PREMIACAO
create table ss_content.BR_LOTERIAS_PREMIACAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_PREMIACAO@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_PREMIACAO_BKP
create table ss_content.BR_LOTERIAS_PREMIACAO_BKP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_PREMIACAO_BKP@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_PREMIOLOCALIDADE
create table ss_content.BR_LOTERIAS_PREMIOLOCALIDADE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_PREMIOLOCALIDADE@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_PREMIOLOCALID_BKP
create table ss_content.BR_LOTERIAS_PREMIOLOCALID_BKP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_PREMIOLOCALID_BKP@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_RESULTESPORTIVA
create table ss_content.BR_LOTERIAS_RESULTESPORTIVA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_RESULTESPORTIVA@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_RESULTESPORT_BKP
create table ss_content.BR_LOTERIAS_RESULTESPORT_BKP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_RESULTESPORT_BKP@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_TIPOLOTERIA
create table ss_content.BR_LOTERIAS_TIPOLOTERIA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_TIPOLOTERIA@orass1
;

Prompt ReCriando tabela:BR_LOTERIAS_TIPOLOTERIA_BKP
create table ss_content.BR_LOTERIAS_TIPOLOTERIA_BKP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_LOTERIAS_TIPOLOTERIA_BKP@orass1
;

Prompt ReCriando tabela:BR_MEDIAS_APAGAR_TEMP
create table ss_content.BR_MEDIAS_APAGAR_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_MEDIAS_APAGAR_TEMP@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_CAPACONFIG
create table ss_content.BR_NOTICIAS_CAPACONFIG Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_CAPACONFIG@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_CHAMADA
create table ss_content.BR_NOTICIAS_CHAMADA Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_CHAMADA@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_CHAMADA_AUX
create table ss_content.BR_NOTICIAS_CHAMADA_AUX Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_CHAMADA_AUX@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_DESTAQUE
create table ss_content.BR_NOTICIAS_DESTAQUE Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_DESTAQUE@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_DESTAQUEELEMENTO
create table ss_content.BR_NOTICIAS_DESTAQUEELEMENTO Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_DESTAQUEELEMENTO@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_EDITEL_TEMP
create table ss_content.BR_NOTICIAS_EDITEL_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_NOTICIAS_EDITEL_TEMP@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_EDITORIA
create table ss_content.BR_NOTICIAS_EDITORIA Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_EDITORIA@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_EDITORIACAPA
create table ss_content.BR_NOTICIAS_EDITORIACAPA Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_EDITORIACAPA@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_EDITORIAELEMENTO
create table ss_content.BR_NOTICIAS_EDITORIAELEMENTO Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_EDITORIAELEMENTO@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_EDITORIA_TRANS
create table ss_content.BR_NOTICIAS_EDITORIA_TRANS Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_EDITORIA_TRANS@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_ELEMENTO
create table ss_content.BR_NOTICIAS_ELEMENTO Tablespace  nologging as
select * from ss_content.BR_NOTICIAS_ELEMENTO@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_FEEDS
create table ss_content.BR_NOTICIAS_FEEDS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_NOTICIAS_FEEDS@orass1 where DATA_PUBLICACAO >= trunc(sysdate - 30)
;

Prompt ReCriando tabela:BR_NOTICIAS_LINK
create table ss_content.BR_NOTICIAS_LINK Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_NOTICIAS_LINK@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_LOG
create table ss_content.BR_NOTICIAS_LOG Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_LOG@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_NOTICIA
create table ss_content.BR_NOTICIAS_NOTICIA Tablespace BR_NOTICIA_NOTICIA_DATA nologging as
select /*+ All_Rows Use_Hash(A B) */
       A.*
  from ss_content.BR_NOTICIAS_NOTICIA@orass1 A,
	   SS_CONTENT.BR_NOTICIAS_ELEMENTO@orass1 B
 Where A.IDNOTICIA         = B.IDELEMENTO
   AND A.IDTIPONOTICIA     = B.IDTIPOELEMENTO
   And B.DATAPUBLICACAO    >= trunc(sysdate - 30)
;

Prompt ReCriando tabela:BR_NOTICIAS_NOTICIAELEMENTO
create table ss_content.BR_NOTICIAS_NOTICIAELEMENTO Tablespace BR_NOTICIA_NOTICIAELEMENTO_D nologging as
select * from ss_content.BR_NOTICIAS_NOTICIAELEMENTO@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_SMS
create table ss_content.BR_NOTICIAS_SMS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_NOTICIAS_SMS@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_SUBTIPO
create table ss_content.BR_NOTICIAS_SUBTIPO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_NOTICIAS_SUBTIPO@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_TEMPLATECAPA
create table ss_content.BR_NOTICIAS_TEMPLATECAPA Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_TEMPLATECAPA@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_USUARIOEDITORIA
create table ss_content.BR_NOTICIAS_USUARIOEDITORIA Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_USUARIOEDITORIA@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_VEJATAMBEM
create table ss_content.BR_NOTICIAS_VEJATAMBEM Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_VEJATAMBEM@orass1
;

Prompt ReCriando tabela:BR_NOTICIAS_VEJATAMBEM_AUX
create table ss_content.BR_NOTICIAS_VEJATAMBEM_AUX Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_NOTICIAS_VEJATAMBEM_AUX@orass1
;

Prompt ReCriando tabela:BR_PARCEIROS_GREENPEACE_FIL
create table ss_content.BR_PARCEIROS_GREENPEACE_FIL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PARCEIROS_GREENPEACE_FIL@orass1
;

Prompt ReCriando tabela:BR_PIADAS_CATEGORIA
create table ss_content.BR_PIADAS_CATEGORIA Tablespace USERS nologging as
select * from ss_content.BR_PIADAS_CATEGORIA@orass1
;

Prompt ReCriando tabela:BR_PIADAS_PIADA
create table ss_content.BR_PIADAS_PIADA Tablespace USERS nologging as
select * from ss_content.BR_PIADAS_PIADA@orass1
;

Prompt ReCriando tabela:BR_PIADAS_PIADASUB
create table ss_content.BR_PIADAS_PIADASUB Tablespace USERS nologging as
select * from ss_content.BR_PIADAS_PIADASUB@orass1
;

Prompt ReCriando tabela:BR_PIADAS_SUBCAT
create table ss_content.BR_PIADAS_SUBCAT Tablespace USERS nologging as
select * from ss_content.BR_PIADAS_SUBCAT@orass1
;

Prompt ReCriando tabela:BR_PIADAS_VOTACAO
create table ss_content.BR_PIADAS_VOTACAO Tablespace USERS nologging as
select * from ss_content.BR_PIADAS_VOTACAO@orass1
;

Prompt ReCriando tabela:BR_PIADAS_VOTACAO_BAK
create table ss_content.BR_PIADAS_VOTACAO_BAK Tablespace USERS nologging as
select * from ss_content.BR_PIADAS_VOTACAO_BAK@orass1
;

Prompt ReCriando tabela:BR_PORTAL_ANIMACAO
create table ss_content.BR_PORTAL_ANIMACAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_ANIMACAO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_BUNDLE
create table ss_content.BR_PORTAL_BUNDLE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_BUNDLE@orass1
;

Prompt ReCriando tabela:BR_PORTAL_BUNDLE_LONG
create table ss_content.BR_PORTAL_BUNDLE_LONG Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_BUNDLE_LONG@orass1
;

Prompt ReCriando tabela:BR_PORTAL_BUNDLE_LONG2
create table ss_content.BR_PORTAL_BUNDLE_LONG2 Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_BUNDLE_LONG2@orass1
;

Prompt ReCriando tabela:BR_PORTAL_EDITORIA
create table ss_content.BR_PORTAL_EDITORIA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_EDITORIA@orass1
;

Prompt ReCriando tabela:BR_PORTAL_EDITORIA_GRUPOS
create table ss_content.BR_PORTAL_EDITORIA_GRUPOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_EDITORIA_GRUPOS@orass1
;

Prompt ReCriando tabela:BR_PORTAL_EDITORIA_PANAM_TEMP
create table ss_content.BR_PORTAL_EDITORIA_PANAM_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_EDITORIA_PANAM_TEMP@orass1
;

Prompt ReCriando tabela:BR_PORTAL_ELEMENTO_LOG
create table ss_content.BR_PORTAL_ELEMENTO_LOG Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_ELEMENTO_LOG@orass1
;

Prompt ReCriando tabela:BR_PORTAL_ELEMENTO_SUBELEMENTO
create table ss_content.BR_PORTAL_ELEMENTO_SUBELEMENTO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_ELEMENTO_SUBELEMENTO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_FEED_NEWS_MAPPING
create table ss_content.BR_PORTAL_FEED_NEWS_MAPPING Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_FEED_NEWS_MAPPING@orass1
;

Prompt ReCriando tabela:BR_PORTAL_FONTE
create table ss_content.BR_PORTAL_FONTE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_FONTE@orass1
;

Prompt ReCriando tabela:BR_PORTAL_FONTE2
create table ss_content.BR_PORTAL_FONTE2 Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_PORTAL_FONTE2@orass1
;

Prompt ReCriando tabela:BR_PORTAL_FUNCAO
create table ss_content.BR_PORTAL_FUNCAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_FUNCAO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_GALERIA
create table ss_content.BR_PORTAL_GALERIA Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_PORTAL_GALERIA@orass1
;

Prompt ReCriando tabela:BR_PORTAL_GALERIA_ELEMENTO
create table ss_content.BR_PORTAL_GALERIA_ELEMENTO Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_PORTAL_GALERIA_ELEMENTO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_IMAGEM
create table ss_content.BR_PORTAL_IMAGEM Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_IMAGEM@orass1
;

Prompt ReCriando tabela:BR_PORTAL_IMAGEM2
create table ss_content.BR_PORTAL_IMAGEM2 Tablespace NOTICIAS_DATA nologging as
select * from ss_content.BR_PORTAL_IMAGEM2@orass1
;

Prompt ReCriando tabela:BR_PORTAL_LINGUA
create table ss_content.BR_PORTAL_LINGUA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_LINGUA@orass1
;

Prompt ReCriando tabela:BR_PORTAL_LINGUAS
create table ss_content.BR_PORTAL_LINGUAS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_LINGUAS@orass1
;

Prompt ReCriando tabela:BR_PORTAL_LOCALIDADE
create table ss_content.BR_PORTAL_LOCALIDADE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_LOCALIDADE@orass1
;

Prompt ReCriando tabela:BR_PORTAL_LOCALIDADE_CESAR
create table ss_content.BR_PORTAL_LOCALIDADE_CESAR Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_LOCALIDADE_CESAR@orass1
;

Prompt ReCriando tabela:BR_PORTAL_LOCALIDADE_CORRECAO
create table ss_content.BR_PORTAL_LOCALIDADE_CORRECAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_LOCALIDADE_CORRECAO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_LOCALIDADE_ELEICOES
create table ss_content.BR_PORTAL_LOCALIDADE_ELEICOES Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_LOCALIDADE_ELEICOES@orass1
;

Prompt ReCriando tabela:BR_PORTAL_LOCALIDADE_ELEITORES
create table ss_content.BR_PORTAL_LOCALIDADE_ELEITORES Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_LOCALIDADE_ELEITORES@orass1
;

Prompt ReCriando tabela:BR_PORTAL_LOCALIDADE_IBGE
create table ss_content.BR_PORTAL_LOCALIDADE_IBGE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_LOCALIDADE_IBGE@orass1
;

Prompt ReCriando tabela:BR_PORTAL_LOCALIDADE_LOC_VOT
create table ss_content.BR_PORTAL_LOCALIDADE_LOC_VOT Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_LOCALIDADE_LOC_VOT@orass1
;

Prompt ReCriando tabela:BR_PORTAL_LOCALIDADE_TSE
create table ss_content.BR_PORTAL_LOCALIDADE_TSE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_LOCALIDADE_TSE@orass1
;

Prompt ReCriando tabela:BR_PORTAL_LOCALIDADE_ZONEL
create table ss_content.BR_PORTAL_LOCALIDADE_ZONEL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_LOCALIDADE_ZONEL@orass1
;

Prompt ReCriando tabela:BR_PORTAL_LOG
create table ss_content.BR_PORTAL_LOG Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_LOG@orass1 where 1<>1
;

Prompt ReCriando tabela:BR_PORTAL_MOBILE
create table ss_content.BR_PORTAL_MOBILE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_MOBILE@orass1
;

Prompt ReCriando tabela:BR_PORTAL_MULTIMEDIA
create table ss_content.BR_PORTAL_MULTIMEDIA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_MULTIMEDIA@orass1
;

Prompt ReCriando tabela:BR_PORTAL_MULTIMEDIA123
create table ss_content.BR_PORTAL_MULTIMEDIA123 Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_MULTIMEDIA123@orass1
;

Prompt ReCriando tabela:BR_PORTAL_MULTIMEDIA_T
create table ss_content.BR_PORTAL_MULTIMEDIA_T Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_MULTIMEDIA_T@orass1
;

Prompt ReCriando tabela:BR_PORTAL_PESQUISA
create table ss_content.BR_PORTAL_PESQUISA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_PESQUISA@orass1
;

Prompt ReCriando tabela:BR_PORTAL_PESQUISA_OPCAO
create table ss_content.BR_PORTAL_PESQUISA_OPCAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_PESQUISA_OPCAO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_PESQUISA_PERIODO
create table ss_content.BR_PORTAL_PESQUISA_PERIODO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_PESQUISA_PERIODO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_PESQUISA_VALOR
create table ss_content.BR_PORTAL_PESQUISA_VALOR Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_PESQUISA_VALOR@orass1
;

Prompt ReCriando tabela:BR_PORTAL_PESSOA
create table ss_content.BR_PORTAL_PESSOA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_PESSOA@orass1
;

Prompt ReCriando tabela:BR_PORTAL_PESSOA_ELEMENTO
create table ss_content.BR_PORTAL_PESSOA_ELEMENTO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_PESSOA_ELEMENTO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_PESSOA_FUNCAO
create table ss_content.BR_PORTAL_PESSOA_FUNCAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_PESSOA_FUNCAO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_REGRAS
create table ss_content.BR_PORTAL_REGRAS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_REGRAS@orass1
;

Prompt ReCriando tabela:BR_PORTAL_SITE
create table ss_content.BR_PORTAL_SITE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_SITE@orass1
;

Prompt ReCriando tabela:BR_PORTAL_SUBELEMENTO
create table ss_content.BR_PORTAL_SUBELEMENTO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_SUBELEMENTO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_SUBELEMENTO_REL
create table ss_content.BR_PORTAL_SUBELEMENTO_REL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_SUBELEMENTO_REL@orass1
;

Prompt ReCriando tabela:BR_PORTAL_SUB_PESSOA
create table ss_content.BR_PORTAL_SUB_PESSOA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_SUB_PESSOA@orass1
;

Prompt ReCriando tabela:BR_PORTAL_TEMPLATES_CONTEUDO
create table ss_content.BR_PORTAL_TEMPLATES_CONTEUDO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_TEMPLATES_CONTEUDO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_UNIDADE_NEGOCIO
create table ss_content.BR_PORTAL_UNIDADE_NEGOCIO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_UNIDADE_NEGOCIO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_USUARIO
create table ss_content.BR_PORTAL_USUARIO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_USUARIO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_USUARIOGRUPO
create table ss_content.BR_PORTAL_USUARIOGRUPO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_USUARIOGRUPO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_USUARIO_PREF
create table ss_content.BR_PORTAL_USUARIO_PREF Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_USUARIO_PREF@orass1
;

Prompt ReCriando tabela:BR_PORTAL_VIDEO
create table ss_content.BR_PORTAL_VIDEO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_VIDEO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_VIDEO_GRUPO
create table ss_content.BR_PORTAL_VIDEO_GRUPO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_VIDEO_GRUPO@orass1
;

Prompt ReCriando tabela:BR_PORTAL_VIDEO_TIPO
create table ss_content.BR_PORTAL_VIDEO_TIPO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_PORTAL_VIDEO_TIPO@orass1
;

Prompt ReCriando tabela:BR_TEMPO_ESTACAO
create table ss_content.BR_TEMPO_ESTACAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TEMPO_ESTACAO@orass1
;

Prompt ReCriando tabela:BR_TEMPO_ESTACAO_TEMP
create table ss_content.BR_TEMPO_ESTACAO_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TEMPO_ESTACAO_TEMP@orass1
;

Prompt ReCriando tabela:BR_TEMPO_ICONE
create table ss_content.BR_TEMPO_ICONE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TEMPO_ICONE@orass1
;

Prompt ReCriando tabela:BR_TEMPO_IMAGEM
create table ss_content.BR_TEMPO_IMAGEM Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TEMPO_IMAGEM@orass1
;

Prompt ReCriando tabela:BR_TEMPO_LOCALIDADE
create table ss_content.BR_TEMPO_LOCALIDADE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TEMPO_LOCALIDADE@orass1
;

Prompt ReCriando tabela:BR_TEMPO_LOCALIDADE_TEMP
create table ss_content.BR_TEMPO_LOCALIDADE_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TEMPO_LOCALIDADE_TEMP@orass1
;

Prompt ReCriando tabela:BR_TEMPO_OBSERVACAO
create table ss_content.BR_TEMPO_OBSERVACAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TEMPO_OBSERVACAO@orass1
;

Prompt ReCriando tabela:BR_TEMPO_OBSERVACAO_TEMP
create table ss_content.BR_TEMPO_OBSERVACAO_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TEMPO_OBSERVACAO_TEMP@orass1
;

Prompt ReCriando tabela:BR_TEMPO_OBSERVACAO_TEMP2
create table ss_content.BR_TEMPO_OBSERVACAO_TEMP2 Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TEMPO_OBSERVACAO_TEMP2@orass1
;

Prompt ReCriando tabela:BR_TEMPO_PREVISAO
create table ss_content.BR_TEMPO_PREVISAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TEMPO_PREVISAO@orass1
;

Prompt ReCriando tabela:BR_TEMPO_PREVISAO_TEMP
create table ss_content.BR_TEMPO_PREVISAO_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TEMPO_PREVISAO_TEMP@orass1
;

Prompt ReCriando tabela:BR_TEMPO_TRADUCAO
create table ss_content.BR_TEMPO_TRADUCAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TEMPO_TRADUCAO@orass1
;

Prompt ReCriando tabela:BR_TRAILER_IMPORTACAO
create table ss_content.BR_TRAILER_IMPORTACAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TRAILER_IMPORTACAO@orass1
;

Prompt ReCriando tabela:BR_TRANSITO_BOLETIM
create table ss_content.BR_TRANSITO_BOLETIM Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TRANSITO_BOLETIM@orass1
;

Prompt ReCriando tabela:BR_TRANSITO_CATEGORIA
create table ss_content.BR_TRANSITO_CATEGORIA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TRANSITO_CATEGORIA@orass1
;

Prompt ReCriando tabela:BR_TRANSITO_CORREDOR
create table ss_content.BR_TRANSITO_CORREDOR Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TRANSITO_CORREDOR@orass1
;

Prompt ReCriando tabela:BR_TRANSITO_NOTICIA
create table ss_content.BR_TRANSITO_NOTICIA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TRANSITO_NOTICIA@orass1
;

Prompt ReCriando tabela:BR_TRANSITO_RESUMO
create table ss_content.BR_TRANSITO_RESUMO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TRANSITO_RESUMO@orass1
;

Prompt ReCriando tabela:BR_TRANSITO_SENTIDO
create table ss_content.BR_TRANSITO_SENTIDO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TRANSITO_SENTIDO@orass1
;

Prompt ReCriando tabela:BR_TRANSITO_TRECHO
create table ss_content.BR_TRANSITO_TRECHO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_TRANSITO_TRECHO@orass1
;

Prompt ReCriando tabela:BR_VESTIBULAR_CANDIDATOS
create table ss_content.BR_VESTIBULAR_CANDIDATOS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.BR_VESTIBULAR_CANDIDATOS@orass1
;

Prompt ReCriando tabela:CONTENT_INVENTORY
create table ss_content.CONTENT_INVENTORY Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.CONTENT_INVENTORY@orass1
;

Prompt ReCriando tabela:EDITORIA_BR_LATAM
create table ss_content.EDITORIA_BR_LATAM Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.EDITORIA_BR_LATAM@orass1
;

Prompt ReCriando tabela:LATAM_BACKUP_TEMP
create table ss_content.LATAM_BACKUP_TEMP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LATAM_BACKUP_TEMP@orass1
;

Prompt ReCriando tabela:LA_PANAM_BUSINESS_UNIT
create table ss_content.LA_PANAM_BUSINESS_UNIT Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_PANAM_BUSINESS_UNIT@orass1
;

Prompt ReCriando tabela:LA_PANAM_COUNTRY_DESC
create table ss_content.LA_PANAM_COUNTRY_DESC Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_PANAM_COUNTRY_DESC@orass1
;

Prompt ReCriando tabela:LA_PANAM_MEDAL_SCORE
create table ss_content.LA_PANAM_MEDAL_SCORE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_PANAM_MEDAL_SCORE@orass1
;

Prompt ReCriando tabela:LA_PANAM_NEWS_SOURCES
create table ss_content.LA_PANAM_NEWS_SOURCES Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_PANAM_NEWS_SOURCES@orass1
;

Prompt ReCriando tabela:LA_PANAM_PARTICIPANT_DESCRIP
create table ss_content.LA_PANAM_PARTICIPANT_DESCRIP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_PANAM_PARTICIPANT_DESCRIP@orass1
;

Prompt ReCriando tabela:LA_PANAM_PLAYER_ACHIEVEMENTS
create table ss_content.LA_PANAM_PLAYER_ACHIEVEMENTS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_PANAM_PLAYER_ACHIEVEMENTS@orass1
;

Prompt ReCriando tabela:LA_PANAM_PLAYER_DESC
create table ss_content.LA_PANAM_PLAYER_DESC Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_PANAM_PLAYER_DESC@orass1
;

Prompt ReCriando tabela:LA_PANAM_SPORT_DESK
create table ss_content.LA_PANAM_SPORT_DESK Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_PANAM_SPORT_DESK@orass1
;

Prompt ReCriando tabela:LA_TOURN_COLLECTIVE_TYPE
create table ss_content.LA_TOURN_COLLECTIVE_TYPE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_COLLECTIVE_TYPE@orass1
;

Prompt ReCriando tabela:LA_TOURN_DESC_PLAYER_ATTR
create table ss_content.LA_TOURN_DESC_PLAYER_ATTR Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_DESC_PLAYER_ATTR@orass1
;

Prompt ReCriando tabela:LA_TOURN_EVENT
create table ss_content.LA_TOURN_EVENT Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_EVENT@orass1
;

Prompt ReCriando tabela:LA_TOURN_GENRE_TYPE
create table ss_content.LA_TOURN_GENRE_TYPE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_GENRE_TYPE@orass1
;

Prompt ReCriando tabela:LA_TOURN_LOCATION
create table ss_content.LA_TOURN_LOCATION Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_LOCATION@orass1
;

Prompt ReCriando tabela:LA_TOURN_LOCATION_TYPE
create table ss_content.LA_TOURN_LOCATION_TYPE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_LOCATION_TYPE@orass1
;

Prompt ReCriando tabela:LA_TOURN_MEDAL_TYPE
create table ss_content.LA_TOURN_MEDAL_TYPE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_MEDAL_TYPE@orass1
;

Prompt ReCriando tabela:LA_TOURN_MODALITY
create table ss_content.LA_TOURN_MODALITY Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_MODALITY@orass1
;

Prompt ReCriando tabela:LA_TOURN_MODALITY_HISTORY
create table ss_content.LA_TOURN_MODALITY_HISTORY Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_MODALITY_HISTORY@orass1
;

Prompt ReCriando tabela:LA_TOURN_PARTICIPANT
create table ss_content.LA_TOURN_PARTICIPANT Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_PARTICIPANT@orass1
;

Prompt ReCriando tabela:LA_TOURN_PARTICIPANT_ATTRIBUTE
create table ss_content.LA_TOURN_PARTICIPANT_ATTRIBUTE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_PARTICIPANT_ATTRIBUTE@orass1
;

Prompt ReCriando tabela:LA_TOURN_PARTICIPANT_EVENT
create table ss_content.LA_TOURN_PARTICIPANT_EVENT Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_PARTICIPANT_EVENT@orass1
;

Prompt ReCriando tabela:LA_TOURN_PARTICIPANT_INSTANCE
create table ss_content.LA_TOURN_PARTICIPANT_INSTANCE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_PARTICIPANT_INSTANCE@orass1
;

Prompt ReCriando tabela:LA_TOURN_RECORD
create table ss_content.LA_TOURN_RECORD Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_RECORD@orass1
;

Prompt ReCriando tabela:LA_TOURN_RECORD_TYPE
create table ss_content.LA_TOURN_RECORD_TYPE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_RECORD_TYPE@orass1
;

Prompt ReCriando tabela:LA_TOURN_SPORT
create table ss_content.LA_TOURN_SPORT Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_SPORT@orass1
;

Prompt ReCriando tabela:LA_TOURN_SPORT_DESCRIPTION
create table ss_content.LA_TOURN_SPORT_DESCRIPTION Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_SPORT_DESCRIPTION@orass1
;

Prompt ReCriando tabela:LA_TOURN_TEAM
create table ss_content.LA_TOURN_TEAM Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_TEAM@orass1
;

Prompt ReCriando tabela:LA_TOURN_TOURNAMENT
create table ss_content.LA_TOURN_TOURNAMENT Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_TOURNAMENT@orass1
;

Prompt ReCriando tabela:LA_TOURN_TOURNAMENT_CATEGORY
create table ss_content.LA_TOURN_TOURNAMENT_CATEGORY Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_TOURNAMENT_CATEGORY@orass1
;

Prompt ReCriando tabela:LA_TOURN_TOURNAMENT_MODAL
create table ss_content.LA_TOURN_TOURNAMENT_MODAL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_TOURNAMENT_MODAL@orass1
;

Prompt ReCriando tabela:LA_TOURN_TOURN_PARTIC
create table ss_content.LA_TOURN_TOURN_PARTIC Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_TOURN_PARTIC@orass1
;

Prompt ReCriando tabela:LA_TOURN_UNIT_MEASURE
create table ss_content.LA_TOURN_UNIT_MEASURE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LA_TOURN_UNIT_MEASURE@orass1
;

Prompt ReCriando tabela:LOG_TESTE
create table ss_content.LOG_TESTE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.LOG_TESTE@orass1
;

Prompt ReCriando tabela:NEW_TEST_TABLE
create table ss_content.NEW_TEST_TABLE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.NEW_TEST_TABLE@orass1
;

Prompt ReCriando tabela:NEXT_ID
create table ss_content.NEXT_ID Tablespace USERS nologging as
select * from ss_content.NEXT_ID@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_CHAMADAS
create table ss_content.OLD_BR_CAPA_CHAMADAS Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_CHAMADAS@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_CHAMADASPPI
create table ss_content.OLD_BR_CAPA_CHAMADASPPI Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_CHAMADASPPI@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_CHAMADAS_LIXEIRA
create table ss_content.OLD_BR_CAPA_CHAMADAS_LIXEIRA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_CHAMADAS_LIXEIRA@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_CHAMADAS_SUGEST
create table ss_content.OLD_BR_CAPA_CHAMADAS_SUGEST Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_CHAMADAS_SUGEST@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_CONFIG
create table ss_content.OLD_BR_CAPA_CONFIG Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_CONFIG@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_CONFIGPPI
create table ss_content.OLD_BR_CAPA_CONFIGPPI Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_CONFIGPPI@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_CORUJAO
create table ss_content.OLD_BR_CAPA_CORUJAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_CORUJAO@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_HISTORICO
create table ss_content.OLD_BR_CAPA_HISTORICO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_HISTORICO@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_LOCK
create table ss_content.OLD_BR_CAPA_LOCK Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_LOCK@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_LOG
create table ss_content.OLD_BR_CAPA_LOG Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_LOG@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_POPUPREGIONAL
create table ss_content.OLD_BR_CAPA_POPUPREGIONAL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_POPUPREGIONAL@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_PRINCIPAL
create table ss_content.OLD_BR_CAPA_PRINCIPAL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_PRINCIPAL@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_PRINCIPAL_CONFIG
create table ss_content.OLD_BR_CAPA_PRINCIPAL_CONFIG Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_PRINCIPAL_CONFIG@orass1
;

Prompt ReCriando tabela:OLD_BR_CAPA_SECAO
create table ss_content.OLD_BR_CAPA_SECAO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.OLD_BR_CAPA_SECAO@orass1
;

Prompt ReCriando tabela:PORTAL_IMAGE
create table ss_content.PORTAL_IMAGE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.PORTAL_IMAGE@orass1
;

Prompt ReCriando tabela:PORTAL_IMAGE_BACKUP
create table ss_content.PORTAL_IMAGE_BACKUP Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.PORTAL_IMAGE_BACKUP@orass1
;

Prompt ReCriando tabela:PORTAL_IMAGE_DATA
create table ss_content.PORTAL_IMAGE_DATA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.PORTAL_IMAGE_DATA@orass1
;

Prompt ReCriando tabela:PORTAL_IMAGE_TYPE
create table ss_content.PORTAL_IMAGE_TYPE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.PORTAL_IMAGE_TYPE@orass1
;

Prompt ReCriando tabela:REPLICA_CIDADES_CINEMA
create table ss_content.REPLICA_CIDADES_CINEMA Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.REPLICA_CIDADES_CINEMA@orass1
;

Prompt ReCriando tabela:REPLICA_CV_ESPECIALIDADE
create table ss_content.REPLICA_CV_ESPECIALIDADE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.REPLICA_CV_ESPECIALIDADE@orass1
;

Prompt ReCriando tabela:REPLICA_CV_EVENTO_FAIXAPRECO
create table ss_content.REPLICA_CV_EVENTO_FAIXAPRECO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.REPLICA_CV_EVENTO_FAIXAPRECO@orass1
;

Prompt ReCriando tabela:REPLICA_CV_LOCAL
create table ss_content.REPLICA_CV_LOCAL Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.REPLICA_CV_LOCAL@orass1
;

Prompt ReCriando tabela:REPLICA_CV_LOCAL_FAIXAPRECO
create table ss_content.REPLICA_CV_LOCAL_FAIXAPRECO Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.REPLICA_CV_LOCAL_FAIXAPRECO@orass1
;

Prompt ReCriando tabela:SOURCE_HIST
create table ss_content.SOURCE_HIST Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.SOURCE_HIST@orass1
;

Prompt ReCriando tabela:TESTE
create table ss_content.TESTE Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.TESTE@orass1
;

Prompt ReCriando tabela:TMP1
create table ss_content.TMP1 Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.TMP1@orass1
;

Prompt ReCriando tabela:TMP2
create table ss_content.TMP2 Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.TMP2@orass1
;

Prompt ReCriando tabela:TMP_EDITORIAS
create table ss_content.TMP_EDITORIAS Tablespace  nologging as
select * from ss_content.TMP_EDITORIAS@orass1
;

Prompt ReCriando tabela:TRIGGER_ERROR_LOG
create table ss_content.TRIGGER_ERROR_LOG Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.TRIGGER_ERROR_LOG@orass1
;

Prompt ReCriando tabela:VGN_ALTCONTENT
create table ss_content.VGN_ALTCONTENT Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.VGN_ALTCONTENT@orass1
;

Prompt ReCriando tabela:VGN_CMASSOC
create table ss_content.VGN_CMASSOC Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.VGN_CMASSOC@orass1
;

Prompt ReCriando tabela:VGN_CMG_CM
create table ss_content.VGN_CMG_CM Tablespace SS_CONTENT_DATA nologging as
select * from ss_content.VGN_CMG_CM@orass1
;
spool off;
exit;
