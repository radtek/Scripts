col total for a15
col usado for a15
col sobra for 9999999999
col full for a6
accept tbs prompt 'Tablespace:'
SELECT /*+ ordered */ d.file_name
     , v.status
     , d.file_id
     , TO_CHAR((d.bytes), '99999990000') Total
     , NVL(TO_CHAR(((d.bytes - s.bytes)),'99999990000'),TO_CHAR((d.bytes),'99999990000')) Usado
     , (TO_CHAR((d.bytes), '99999990000')) - NVL(TO_CHAR(((d.bytes - s.bytes)),'99999990000'),TO_CHAR((d.bytes),'99999990000')
) Sobra
     , (NVL(TO_CHAR(((d.bytes - s.bytes)),'99999990000'),TO_CHAR((d.bytes),'99999990000'))*100)/TO_CHAR((d.bytes), '99999990000') ||'%' "FULL %"
 FROM sys.dba_data_files d
     , v$datafile v
     , (SELECT file_id, SUM(bytes) bytes
         FROM sys.dba_free_space
         WHERE tablespace_name = upper('&tbs')  GROUP BY file_id) s
WHERE (s.file_id (+)= d.file_id)
      AND (d.tablespace_name = upper('&tbs'))
      AND (d.file_name = v.name)
/

