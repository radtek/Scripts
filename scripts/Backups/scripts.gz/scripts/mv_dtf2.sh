sqlplus /nolog <<eof
conn / as sysdba
spool mv_dtf2.log
set echo on

alter tablespace mail_trr_usr_mails_data  offline;

! cp /o02/oradata/oradb1/mail_trr_usr_mails_data_01.dbf /o03/oradata/oradb1/mail_trr_usr_mails_data_01.dbf

alter database rename file '/o02/oradata/oradb1/mail_trr_usr_mails_data_01.dbf' to '/o03/oradata/oradb1/mail_trr_usr_mails_data_01.dbf';

alter tablespace mail_trr_usr_mails_data  online;


exit;
eof

