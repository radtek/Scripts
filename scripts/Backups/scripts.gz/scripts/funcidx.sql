undef own
select a.*, b.status, b.FUNCIDX_STATUS
 from dba_ind_expressions a, dba_indexes b
where a.index_owner like upper('&own') ||'%'
  and a.index_owner = b.owner
  and a.index_name  = b.index_name
order by a.index_owner, a.index_name;

