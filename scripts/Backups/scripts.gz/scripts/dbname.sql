select sys_context('userenv','db_name') banco from dual;
