UNDEF TBL;

select file_name, bytes,
AUTOEXTENSIBLE,         
MAXBYTES      ,         
INCREMENT_BY           
 from dba_data_files where tablespace_name = upper('&tBL');