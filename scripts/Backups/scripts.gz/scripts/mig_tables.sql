Define own = &1;
define dbl = &2;

col DATA_DEFAULT for a10
col column_name for a30;

set head off;
set feed off;


spool mig_&own..sql

prompt Set echo on
Prompt Set timming on
Prompt Spool mig_&own..log

select 'create table &own..' || table_name || ' nologging' || chr(10) ||
       'as select * from &own..' || table_name ||'@&dbl;'
  from dba_tables a
 where a.owner          = upper('&own')
   and a.iot_type	is null
   and not exists	(select 1 
			   from dba_tab_columns b
                          where a.owner          = b.owner
   			    and a.table_name     = b.table_name
   			    and b.data_default   is not null)
   and not exists	(select 1
			   from dba_part_key_columns c
			  where a.owner          = c.owner
   			    and a.table_name     = c.name);

select 'alter table &own..' || a.table_name || ' modify ' || 
        b.column_name || ' default ' || b.data_default ||';'
  from dba_tables a, dba_tab_columns b
 where a.owner          = upper('&own')
   and a.owner          = b.owner
   and a.table_name     = b.table_name
   and b.data_default   is not null;
  




 

set head on

prompt /**********************************************
Prompt Tabelas especias. Devem ser criadas separadas:
prompt **********************************************
Prompt Tabelas com valor default em colunas:
select a.table_name, b.column_name, b.data_default
  from dba_tables a, dba_tab_columns b
 where a.owner          = upper('&own')
   and a.owner          = b.owner
   and a.table_name     = b.table_name
   and b.data_default   is not null
  order by 1,2;

Prompt Tabelas que s\343o IOT:
select table_name
  from dba_tables
 where owner            = upper('&own')
   and iot_type         = 'IOT';

Prompt Tabelas que s\343o Particionadas:
sElect a.table_name, b.column_name
  from dba_tables a, dba_part_key_columns b
 where a.owner          = upper('&own')
   and a.owner          = b.owner
   and a.table_name     = b.name
  order by a.table_name, b.column_position;

prompt **********************************************/

prompt Spool off;


spool off;

