--set pagesize 66;
--set linesize 200;
break on report;
compute sum of tam_kb on report;
col NOME_OBJETO format a30;
col TIPO        format a17;
col TABLESPACE  format a30;
col DONO        format a20;
set ver off
prompt ***************************************************
prompt            Relatorio de extents
prompt ***************************************************
accept tablespace prompt 'Digite o nome da tablespace (null para todas)......:' default null
accept arq        prompt 'Digite o nome do arquivo a ser gerado. (off = sem arquivo):' default 'off'
spool &arq;
select segment_name NOME_OBJETO,partition_name,segment_type TIPO,owner DONO, 
       bytes/1024 TAM_KB,initial_extent/1024 INICIAL_KB,
       next_extent/1024 PROXIMOS_KB,extents NRO_EXTENTS,max_extents MAXIMO_EXTENTS
 from sys.dba_segments where (tablespace_name = upper('&tablespace') or upper('&tablespace') is null)
order by bytes;
spool off;
prompt Gerado o &arq
