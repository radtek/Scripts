set ver off;
accept banco prompt 'Banco:'
connect system@&banco
select * from v$instance;
show user
set sqlprompt '&banco> ';

