spool cr_tbs_suat.log
set echo on
set time on

--SUAT_BIG_DATA                        8320
create Tablespace SUAT_BIG_DATA Datafile
'/b01/oradata/oradsv/suat_big_data_01.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b02/oradata/oradsv/suat_big_data_02.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b01/oradata/oradsv/suat_big_data_03.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b02/oradata/oradsv/suat_big_data_04.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b01/oradata/oradsv/suat_big_data_05.dbf' size 500m autoextend on next 100m maxsize 2000m
Extent management local autoallocate;

--SUAT_BIG_INDX                       10304
create Tablespace SUAT_BIG_INDX Datafile
'/b03/oradata/oradsv/suat_big_indx_01.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b04/oradata/oradsv/suat_big_indx_02.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b03/oradata/oradsv/suat_big_indx_03.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b04/oradata/oradsv/suat_big_indx_04.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b03/oradata/oradsv/suat_big_indx_05.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b04/oradata/oradsv/suat_big_indx_06.dbf' size 500m autoextend on next 100m maxsize 2000m
Extent management local autoallocate;

--SUAT_DATA 6703
create Tablespace SUAT_DATA Datafile
'/b01/oradata/oradsv/suat_data_01.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b02/oradata/oradsv/suat_data_02.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b01/oradata/oradsv/suat_data_03.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b02/oradata/oradsv/suat_data_04.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b01/oradata/oradsv/suat_data_05.dbf' size 500m autoextend on next 100m maxsize 2000m
Extent management local autoallocate;

--SUAT_INDX 6129
create Tablespace SUAT_INDX Datafile
'/b03/oradata/oradsv/suat_indx_01.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b04/oradata/oradsv/suat_indx_02.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b03/oradata/oradsv/suat_indx_03.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b04/oradata/oradsv/suat_indx_04.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b03/oradata/oradsv/suat_indx_05.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b04/oradata/oradsv/suat_indx_06.dbf' size 500m autoextend on next 100m maxsize 2000m
Extent management local autoallocate;

--SUAT_LOG_DATA 864
--SUAT_LOG_INDX                        1760
--SUAT_TMP_DATA 69
create tablespace SUAT_TMP_DATA datafile
'/b03/oradata/oradsv/suat_tmp_data_01.dbf' size 50m autoextend on next 100m maxsize 2000m
Extent management local autoallocate;

--SUAT_TRR_CONTA_DATA                  3648
Create tablespace SUAT_TRR_CONTA_DATA datafile
'/b03/oradata/oradsv/suat_trr_conta_data_01.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b04/oradata/oradsv/suat_trr_conta_data_02.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b03/oradata/oradsv/suat_trr_conta_data_03.dbf' size 500m autoextend on next 100m maxsize 2000m
Extent management local autoallocate;

--SUAT_TRR_CONTA_INDX 4352
create Tablespace SUAT_trr_conta_INDX Datafile
'/b03/oradata/oradsv/suat_trr_conta_indx_01.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b04/oradata/oradsv/suat_trr_conta_indx_02.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b03/oradata/oradsv/suat_trr_conta_indx_03.dbf' size 500m autoextend on next 100m maxsize 2000m
Extent management local autoallocate;

--SUAT_TRR_REG_SERVICOCONTA_DATA       1792
Create tablespace SUAT_TRR_REG_SERVICOCONTA_DATA datafile
'/b03/oradata/oradsv/suat_trr_reg_servicoconta_data_01.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b04/oradata/oradsv/suat_trr_reg_servicoconta_data_02.dbf' size 500m autoextend on next 100m maxsize 2000m
Extent management local autoallocate;

--SUAT_TRR_REG_SERVICOCONTA_INDX 5456
create Tablespace SUAT_TRR_REG_SERVICOCONTA_INDX Datafile
'/b03/oradata/oradsv/suat_trr_reg_servicoconta_indx_01.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b04/oradata/oradsv/suat_trr_reg_servicoconta_indx_02.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b03/oradata/oradsv/suat_trr_reg_servicoconta_indx_03.dbf' size 500m autoextend on next 100m maxsize 2000m,
'/b04/oradata/oradsv/suat_trr_reg_servicoconta_indx_03.dbf' size 500m autoextend on next 100m maxsize 2000m
Extent management local autoallocate;


spool off;
exit;

