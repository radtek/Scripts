set echo off;
break on indice skip 1;
set ver off;
COL COLUMN_NAME FOR A30;
col indice for a80;
accept own prompt 'Owner da Tabela:'
accept tab prompt 'Nome da tabela.:'


select 	a.index_owner||'.'||a.index_name ||' ('||b.uniqueness||')' || 
        '(TBL:' ||b.tablespace_name||')' ||
        '(Bytes:'|| c.bytes ||' Ext:'|| c.extents||')' indice ,
	a.column_name
from ALL_ind_columns a, all_indexes b, dba_segments c
where b.table_name  	= upper('&tab')
  and b.owner           = upper('&own')
  and b.table_name  	= a.table_name
  and b.index_name  	= a.index_name
  and b.owner 		= a.index_owner
  and b.index_name      = c.segment_name
  and b.owner           = c.owner
  and c.segment_type 	= 'INDEX'
order by indice,column_position;

