spool cr_tables.log
set echo on
set timing on
set time on

conn gaia_tstcarga/gaia_tstcarga

create database link orahlg01 connect to bkp identified by bkporahlg01 using 'orahlg01' ; 

Prompt Criando tabela:CARACTERISTICAS
create table gaia_tstcarga.CARACTERISTICAS nologging as
select * from gaia.CARACTERISTICAS@orahlg01
;

Prompt Criando tabela:CATEGORIAS_COMUNIDADES
create table gaia_tstcarga.CATEGORIAS_COMUNIDADES nologging as
select * from gaia.CATEGORIAS_COMUNIDADES@orahlg01
;

Prompt Criando tabela:CG_REF_CODES
create table gaia_tstcarga.CG_REF_CODES nologging as
select * from gaia.CG_REF_CODES@orahlg01
;

Prompt Criando tabela:COMUNIDADES
create table gaia_tstcarga.COMUNIDADES nologging as
select * from gaia.COMUNIDADES@orahlg01
;

Prompt Criando tabela:COMUNIDADES_AFINS
create table gaia_tstcarga.COMUNIDADES_AFINS nologging as
select * from gaia.COMUNIDADES_AFINS@orahlg01
;

Prompt Criando tabela:CONTADORES
create table gaia_tstcarga.CONTADORES nologging as
select * from gaia.CONTADORES@orahlg01
;

Prompt Criando tabela:DEPOIMENTOS
create table gaia_tstcarga.DEPOIMENTOS nologging as
select * from gaia.DEPOIMENTOS@orahlg01
;

Prompt Criando tabela:GRPA_LAMIS
create table gaia_tstcarga.GRPA_LAMIS nologging as
select * from gaia.GRPA_LAMIS@orahlg01
;

Prompt Criando tabela:GRUPOS_AMIGOS
create table gaia_tstcarga.GRUPOS_AMIGOS nologging as
select * from gaia.GRUPOS_AMIGOS@orahlg01
;

Prompt Criando tabela:LISTAS_PERFIS
create table gaia_tstcarga.LISTAS_PERFIS nologging as
select * from gaia.LISTAS_PERFIS@orahlg01
;

Prompt Criando tabela:LISTA_AMIGOS
create table gaia_tstcarga.LISTA_AMIGOS nologging as
select * from gaia.LISTA_AMIGOS@orahlg01
;

Prompt Criando tabela:MEMBROS_COMUNIDADES
create table gaia_tstcarga.MEMBROS_COMUNIDADES nologging as
select * from gaia.MEMBROS_COMUNIDADES@orahlg01
;

Prompt Criando tabela:NAMESPACES
create table gaia_tstcarga.NAMESPACES nologging as
select * from gaia.NAMESPACES@orahlg01
;

Prompt Criando tabela:PAISES
create table gaia_tstcarga.PAISES nologging as
select * from gaia.PAISES@orahlg01
;

Prompt Criando tabela:PERFIS
create table gaia_tstcarga.PERFIS nologging as
select * from gaia.PERFIS@orahlg01
;

Prompt Criando tabela:REGIOES
create table gaia_tstcarga.REGIOES nologging as
select * from gaia.REGIOES@orahlg01
;

Prompt Criando tabela:SERVICOS
create table gaia_tstcarga.SERVICOS nologging as
select * from gaia.SERVICOS@orahlg01
;

Prompt Criando tabela:SERVICOS_TEMAS
create table gaia_tstcarga.SERVICOS_TEMAS nologging as
select * from gaia.SERVICOS_TEMAS@orahlg01
;

Prompt Criando tabela:TEMAS
create table gaia_tstcarga.TEMAS nologging as
select * from gaia.TEMAS@orahlg01
;

Prompt Criando tabela:TIMEZONE_PERFIS
create table gaia_tstcarga.TIMEZONE_PERFIS nologging as
select * from gaia.TIMEZONE_PERFIS@orahlg01
;

Prompt Criando tabela:TIPOS_LISTAS
create table gaia_tstcarga.TIPOS_LISTAS nologging as
select * from gaia.TIPOS_LISTAS@orahlg01
;

Prompt Criando tabela:TIPOS_SERVICOS
create table gaia_tstcarga.TIPOS_SERVICOS nologging as
select * from gaia.TIPOS_SERVICOS@orahlg01
;

Prompt Criando tabela:USR_VAL_CARACTS
create table gaia_tstcarga.USR_VAL_CARACTS nologging as
select * from gaia.USR_VAL_CARACTS@orahlg01
;

Prompt Criando tabela:VAL_CARACTS
create table gaia_tstcarga.VAL_CARACTS nologging as
select * from gaia.VAL_CARACTS@orahlg01
;

drop database link orahlg01;

spool off;

exit;

