col descr FOR A60 heading "Event(sid . username . event . Hash_valeu)";
break on descr skip 1;

select /*+ first_rows */
      s.sid ||' | '||s.username||' | '||w.event ||' | '||t.hash_value as descr, t.sql_text --,p1,p2,p3,s.sql_hash_value
 from
      v$session s,
      v$sqltext  t,
      v$session_wait w
where s.sql_address = t.address and
      s.sql_hash_value = t.hash_value and
      s.sid = w.sid and
      s.username not in ('SYSTEM') and
--      s.username is not null and
      s.status = 'ACTIVE' and
--      rtrim(t.sql_text) <> null and
      w.event <> 'SQL*Net message from client' and
--      w.event <> 'Null event' and
      w.event <> 'rdbms ipc message' and
      w.event <> 'pmon timer' and
      w.event <> 'smon timer' and
--      w.event <> 'SQL*Net message to client' and
      w.event <> 'pipe get'
order by s.sid,s.sql_hash_value,s.sql_address,t.piece
/


