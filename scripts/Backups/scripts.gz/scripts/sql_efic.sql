/*

((DeltaExecuteCount - (DeltaParseCountTotal)) / DeltaExecuteCount) * 100

DeltaParseCountTotal: difference in 'select value from v$sysstat 
                      where name='parse count (total)'' between sample end and start

DeltaExecuteCount: difference in 'select value from v$sysstat 
	           where name='execute count''  between sample end and start

*/


select ((DeltaExecuteCount - (DeltaParseCountTotal)) / DeltaExecuteCount) * 100
 from (select a.value DeltaExecuteCount,
              b.value DeltaParseCountTotal
         from v$sysstat a, v$sysstat b
        where a.name = 'execute count'
          and b.name = 'parse count (total)')
/

     