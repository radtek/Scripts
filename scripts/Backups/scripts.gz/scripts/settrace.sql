undefine sidi;
undefine serial;
exec sys.dbms_system.set_sql_trace_in_session (&sidi,&serial,&true_false);
