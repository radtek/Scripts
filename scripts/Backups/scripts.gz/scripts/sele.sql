break on report;
compute sum of count(*) on report;
accept Tabela prompt 'Tabela:'
Accept Campo  prompt 'Campo.:'
select &campo,count(*) 
  from &tabela 
group by &campo
 order by 2;