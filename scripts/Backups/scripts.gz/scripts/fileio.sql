column drive format A6                     
column filename format a60
column physrds format 9999999999
column physwrt format 9999999999
column blk_rds format 9999999999
column blk_wrt format 9999999999
column total   format 9999999999
break on report
compute sum of physrds on report
compute sum of physwrt on report
compute sum of blk_rds on report
compute sum of blk_wrt on report
compute sum of total on report
select
   substr(i.name,1,6)"DRIVE",      /*assumes a 6-letter drive name*/
   sum(x.phyrds) +
   sum(x.phywrts) "total",                 /*Total IO*/
   sum(x.phyrds) "PHYSRDS",                /*Physical Reads*/
   sum(x.phywrts) "PHYSWRT",               /*Physical Writes*/
   sum(x.phyblkrd) "BLK_RDS",              /*Block Reads*/
   sum(x.phyblkwrt) "BLK_WRT"              /*Block Writes*/
from v$filestat x, sys.ts$ ts, v$datafile i,sys.file$ f
where i.file#=f.file#
and ts.ts#=f.ts#
and x.file#=f.file#
group by
   substr(i.name,1,6)
order by 2 desc;
clear breaks
break on drive skip 1 on report
compute sum of total on drive
compute sum of physrds on drive
compute sum of physwrt on drive
compute sum of blk_rds on drive
compute sum of blk_wrt on drive
select
   substr(i.name,1,6) "DRIVE",     
   i.name filename,
   x.phyrds +
   x.phywrts "total",                      /*Total IO*/
   x.phyrds "PHYSRDS",             /*Physical Reads*/
   x.phywrts "PHYSWRT",            /*Physical Writes*/
   x.phyblkrd "BLK_RDS",           /*Block Reads*/
   x.phyblkwrt "BLK_WRT"           /*Block Writes*/
from v$filestat x, sys.ts$ ts, v$datafile i, sys.file$ f
where i.file#=f.file#
and ts.ts#=f.ts#
and x.file#=f.file#
order by 1,2;


