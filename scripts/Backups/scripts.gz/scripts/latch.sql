select * from v$latchname where latch# = &latch;
