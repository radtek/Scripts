select 'alter table fatcobtre.'||a.table_name|| ' add constraint '||a.constraint_Name||' primary key ('|| b.column_name ||')'|| chr(10) ||
'using index tablespace fatcobtre_indx;'
from dba_constraints a, dba_cons_columns b
where a.owner = 'FATCOBCARGA'
  and a.constraint_type = 'P'
  and a.table_name = b.table_name
  and a.constraint_name = b.constraint_name
  and a.owner = b.owner
  and not exists (select 1 from dba_constraints c
		   where c.owner = 'FATCOBTRE'
                     AND C.TABLE_NAME = A.TABLE_NAME
		     AND C.CONSTRAINT_NAME = A.CONSTRAINT_NAME)
/
