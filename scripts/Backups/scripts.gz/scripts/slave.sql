col ERROR_MSG      for a100;
col ERROR_LINE	   for a100;
select * from (
select * from stat.parallel_stat_load_slaves order by carga_id desc)
where rownum <=10
/


