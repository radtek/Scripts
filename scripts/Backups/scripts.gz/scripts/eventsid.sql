accept sidi prompt 'Sid:'
select event, p1, p2, p3, seconds_in_wait
 from v$session_wait
where sid = &sidi
/
