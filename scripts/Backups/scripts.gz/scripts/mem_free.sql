select * 
  from v$sgastat 
 where name like '%free memory%'
/
