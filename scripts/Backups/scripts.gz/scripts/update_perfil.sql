spool update_perfil.log
set timing on
set echo on
alter session set sort_area_size=30000000;



-- Script to insert new OBP variables.
--
declare
    --
    v_lines_to_commit       number := 5000;
    v_cont                  number := 0;
    v_exit                  varchar2(01) := null;
    --
    cursor assinantes_cur is
		select
			uass.uassi_id
		from 
			bd_central.trr_senhas snh,
			ciut.trr_usr_assinantes uass,
			ciut.trr_contas cont,
			ciut.trr_operadoras ope
		where 
			snh.snh_id 				= uass.snh_id
			and uass.cont_id	 	= cont.cont_id
			and ope.oper_id 		= uass.oper_id
			and ope.sigla 			in ('POA', 'SAO', 'BRA', 'TLF')
			and snh.d_tp_usuario	= 'PAG'
			and snh.cdom_id 		= 1
			and cont.descricao 		<> 'CAIXA POSTAL'
			and uass.perfil 		is null
			and uass.d_status_credito <> 'CAN';
--
begin
    --
    -- Esse loop foi incluido apenas para tratar os poss�veis ORA-1555 (SNAPSHOT TOO OLD).
    v_exit := 'N';
    loop
      exit when v_exit = 'S';
      begin
        --
        for C in assinantes_cur
        loop
		  --
			begin
				 update ciut.trr_usr_assinantes
				 set perfil = 'ISP'
				 where uassi_id = C.uassi_id;

			exception
				when others then
					raise;
			end;
			  --
			if (v_cont = v_lines_to_commit) then
				commit;
				v_cont := 0;
			else
				v_cont := v_cont + 1;
			end if;
        --
        end loop;
        --
        commit;
        v_exit := 'S';
      exception when others then
        if (sqlcode = -1555) then
           v_exit := 'N';
		   rollback;
        else
		   rollback;
           raise;
        end if;
      end;
    end loop;
    --
end;
--
/

exit;


