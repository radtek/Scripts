
select * from stats$snapshot order by snap_time
/
