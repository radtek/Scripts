set timing on
set echo on

alter session set sort_area_SIZE = 50000000;
alter session set db_file_multiblock_read_count = 128;

create index almasgemeas.idx_dt_alt_nro_denuncias on almasgemeas.trr_usr_alms
(data_alteracao, nro_denuncias)
online global nologging
tablespace almas_index
storage (initial 50m next 10m);

alter index almasgemeas.idx_dt_alt_nro_denuncias logging;
analyze index almasgemeas.idx_dt_alt_nro_denuncias compute statistics;


exit;

