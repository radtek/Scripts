col p2text for a08 trunc;
col p1text for a10 trunc;

select decode(b.username,null,'ora_'||substr(b.program,instr(b.program,'(')+1,4),b.username) username,
       b.sid,
       b.serial#,
       a.event,
       a.p1text,a.p1,a.
       p2text,a.p2,
       a.p3,
       a.seconds_in_wait,
       a.state
from v$session_wait a,v$session b
where a.event not like '%message from%'
  and a.event not like '%SQL*Net%'
  and a.event not like '%rdbms ipc message%'
  and a.event not like '%timer%'
  and a.sid=b.sid
order by b.username
/
                  
