rem Script que mata a sess�o de um usu�rio no banco
rem Recebe o SID e o nro serial
col comando for a40;
set ver off;
prompt ==================================================
prompt Script que mata a sess�o de um usu�rio no banco
prompt ==================================================
select sid Sid,serial# Serial,substr(username,1,15)Usu�rio,
       substr(machine,1,15)M�quina,terminal Terminal,
       'alter system kill session '||''''||sid||','||serial#||''''||';' Comando
  from sys.v_$session
  where username is not null and
        username not in ('SYS');
accept p_sid     prompt 'Entre com o Sid da sess�o...:'
accept p_serial  prompt 'Entre com o Serial da sess�o:'
alter system kill session '&p_sid,&p_serial' immediate;
Prompt Sess�o finalizada

