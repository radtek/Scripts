break on report
compute sum of qtd on report
accept owner prompt 'Owner:'
select object_type, status, count(*) Qtd from dba_objects where owner = upper('&owner') group by object_type, status order by 1,2
/

