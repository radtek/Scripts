set serveroutput on;

accept intervalo prompt 'Intervalo em segundos:'
---
column v_data heading v_data new_value v_data for a16;
select to_char(sysdate,'ddmmyyyyhh24miss') v_data from dual;
----
declare
   --
   v_req_ini_shared number := 0;
   v_req_fin_shared number := 0;

   v_req_ini_geral  number := 0;
   v_req_fin_geral  number := 0;

   v_par_ini_geral  number := 0;
   v_par_fin_geral  number := 0;

   v_par_ini_hard   number := 0;
   v_par_fin_hard   number := 0;

   v_sql_ini	    number := 0;
   v_sql_fin	    number := 0;

   v_log_ini	    number := 0;
   v_log_fin	    number := 0;

   v_exe_ini	    number := 0;
   v_exe_fin	    number := 0;
   --
   v_rdo_ini        number := 0;
   v_rdo_fin        number := 0;
   --
   v_tra_ini        number := 0;
   v_tra_fin        number := 0;
   --

begin
   --
   select sum(requests) 	into v_req_ini_shared from v$shared_server;
   select value 		into v_req_ini_geral  from v$sysstat where name = 'user calls';
   select value			into v_par_ini_geral  from v$sysstat where name = 'parse count (total)';
   select value			into v_par_ini_hard   from v$sysstat where name = 'parse count (hard)';
   select sum(executions) 	into v_sql_ini	      from v$sqlarea where sql_text not like '%#%';
   select value			into v_log_ini        from v$sysstat where name = 'logons cumulative';
   select value			into v_exe_ini	      from v$sysstat where name = 'execute count';
   select nvl(max(value),0)         into v_rdo_ini        from v$sysstat where name = 'redo size';
   select sum(value)                into v_tra_ini        from v$sysstat where name in ('user rollbacks','user commits');
   --dbms_output.put_line ('Req ini:' || v_req_ini_geral);

   dbms_lock.sleep (&intervalo);

   select sum(requests) 	into v_req_fin_shared from v$shared_server;
   select value 		into v_req_fin_geral  from v$sysstat where name = 'user calls';
   select value			into v_par_fin_geral  from v$sysstat where name = 'parse count (total)';
   select value			into v_par_fin_hard   from v$sysstat where name = 'parse count (hard)';
   select sum(executions) 	into v_sql_fin	      from v$sqlarea where sql_text not like '%#%';
   select value			into v_log_fin        from v$sysstat where name = 'logons cumulative';
   select value			into v_exe_fin	      from v$sysstat where name = 'execute count';
   select nvl(max(value),0)         into v_rdo_fin        from v$sysstat where name = 'redo size';
   select sum(value)                into v_tra_fin        from v$sysstat where name in ('user rollbacks','user commits');
   --
   --dbms_output.put_line ('Req fin:' || v_req_fin_geral);

   dbms_output.put_line ('------------------------------------------');
   dbms_output.put_line ('Intervalo (segundos):&intervalo ('|| to_char(sysdate,'dd/mm/yyyy hh24:mi:ss')||')');
   dbms_output.put_line ('------------------------------------------');
   dbms_output.put_line ('Total de requisi��es geral:' || to_char(v_req_fin_geral - v_req_ini_geral));
   dbms_output.put_line ('Requisi��es geral por seg.:' || to_char(round((v_req_fin_geral - v_req_ini_geral) / &intervalo)));
   dbms_output.put_line ('--');
   dbms_output.put_line ('Total de requisi��es mts..:' || to_char(v_req_fin_shared - v_req_ini_shared));
   dbms_output.put_line ('Requisi��es mts por seg...:' || to_char(round((v_req_fin_shared - v_req_ini_shared) / &intervalo)));
   dbms_output.put_line ('--');
   dbms_output.put_line ('Total de parse geral......:' || to_char(v_par_fin_geral - v_par_ini_geral));
   dbms_output.put_line ('Parses geral por seg......:' || to_char(round((v_par_fin_geral - v_par_ini_geral) / &intervalo)));
   dbms_output.put_line ('--');
   dbms_output.put_line ('Total de parse hard.......:' || to_char(v_par_fin_hard - v_par_ini_hard));
   dbms_output.put_line ('Parses hard por seg.......:' || to_char(round((v_par_fin_hard - v_par_ini_hard) / &intervalo)));
   dbms_output.put_line ('--');
   dbms_output.put_line ('Total de executions.......:' || to_char(v_exe_fin - v_exe_ini));
   dbms_output.put_line ('Total de executions p seg.:' || to_char(round((v_exe_fin - v_exe_ini) / &intervalo)));
   dbms_output.put_line ('--');
   dbms_output.put_line ('Total de sqls (nao recurs):' || to_char(v_sql_fin - v_sql_ini));
   dbms_output.put_line ('Sqls por seg (nao recurs).:' || to_char(round((v_sql_fin - v_sql_ini) / &intervalo)));
   dbms_output.put_line ('--');
   dbms_output.put_line ('Total de logons...........:' || to_char(v_log_fin - v_log_ini));
   dbms_output.put_line ('Total de logons por seg ..:' || to_char(round((v_log_fin - v_log_ini) / &intervalo)));
   dbms_output.put_line ('--');
   dbms_output.put_line ('Total de Redo Size........:' || to_char(round((v_rdo_fin - v_rdo_ini)/1024)) || ' Kb');
   dbms_output.put_line ('Total de Redo por seg ....:' || to_char(round(((v_rdo_fin - v_rdo_ini) / &intervalo)/1024))  || ' Kb');
   dbms_output.put_line ('--');
   dbms_output.put_line ('Total de Transa��es ......:' || to_char(v_tra_fin - v_tra_ini));
   dbms_output.put_line ('Total de Trans por seg ...:' || to_char(round((v_tra_fin - v_tra_ini) / &intervalo)));

   dbms_output.put_line ('------------------------------------------');
   --
end;
/



