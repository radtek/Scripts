accept dono prompt 'User:'

alter session set current_schema = &dono;

