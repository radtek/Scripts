Break On Owner skip 1;
compute sum of Mb on Owner;
undef own;
select owner, Tablespace_name, Segment_type, round(sum(bytes)/1024/1024) Mb
from dba_segments
where owner Like upper('&own')||'%'
group by owner, Tablespace_name, Segment_type
order by owner, Tablespace_name, Segment_type
/

