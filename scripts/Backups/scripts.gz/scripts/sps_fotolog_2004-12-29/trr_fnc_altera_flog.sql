 create or replace function trr_fnc_altera_flog
 (in_flog_id               in trr_flogs.flog_id%type
 ,iv_nick_usuario          in trr_usr_nick.nick_usuario%type
 ,iv_nick_flog             in trr_flogs.nick_flog%type
 ,iv_titulo                in trr_flogs.titulo%type
 ,ic_d_habilitado          in trr_flogs.d_habilitado%type
 ,ic_d_visivel_busca       in trr_flogs.d_visivel_busca%type
 ,ic_d_aceita_votos        in trr_flogs.d_aceita_votos%type
 ,ic_d_aceita_comentarios  in trr_flogs.d_aceita_comentarios%type
 ,ic_d_aviso_comentarios   in trr_flogs.d_aviso_comentarios%type
 ,ic_d_comunitario         in trr_flogs.d_comunitario%type
 ,iv_config_template       in trr_flogs.config_template%type
 ,iv_ip                    in trr_flogs.ip%type
 ,iv_ip_forward            in trr_flogs.ip_forward%type
 ,iv_senha		   in trr_flogs.senha%type
 ,iv_d_aceita_posts_outros in trr_flogs.senha%type
 ,iv_d_aceita_comentarios_outros  in trr_flogs.senha%type
 ,in_limite_sms_dia	   in trr_flogs.limite_sms_dia%type default null
  )


 return integer
 is
 /*
 Nome da fun��o: trr_fnc_altera_flog
 Descri��o: 	 Altera flog do usu�rio.
 Data: 		 05/05/2004
 Autor: 	 Taise Lorenzi
 
 Par�metros:
  
    in_flog_id    	    	number(10)                  - OBRIGATORIO
    iv_nick_usuario         	varchar2(60)                - OPCIONAL
    iv_nick_flog            	varchar2(60)                - OPCIONAL
    iv_titulo               	varchar2(100)               - OPCIONAL
    ic_d_habilitado         	char(01)                    - OPCIONAL
    ic_d_visivel_busca      	char(01)                    - OPCIONAL
    ic_d_aceita_votos       	char(01)                    - OPCIONAL
    ic_d_aceita_comentarios 	char(01)                    - OPCIONAL
    ic_d_aviso_comentarios  	char(01)                    - OPCIONAL
    ic_d_comunitario        	char(01)                    - OPCIONAL
    iv_config_template      	varchar2(255)               - OPCIONAL
    iv_ip                   	varchar2(20)                - OPCIONAL
    iv_ip_forward           	varchar2(255)               - OPCIONAL
    iv_senha		     	varchar2(30)		    - OPCIONAL
    iv_d_aceita_posts_outros 	char(01)		    - OPCIONAL
    iv_d_aceita_comentarios_outros  char(01)		    - OPCIONAL
    in_limite_sms_dia	        number(10)		    - OPCIONAL
        
 Retorno:
 
     0 - Sucesso
    -1 - Par�metros obrigat�rios n�o informados
    -2 - Flog Inexistente
    -3 - Nick inexistente
    -4 - Nick Flog j� existe
    -5 - Valor inv�lido para par�metro d_habilitado
    -6 - Valor inv�lido para par�metro d_visivel_busca
    -7 - Valor inv�lido para par�metro d_aceita_votos
    -8 - Valor inv�lido para par�metro d_aceita_comentarios
    -9 - Valor inv�lido para par�metro d_aviso_comentarios
   -10 - Valor inv�lido para par�metro d_comunitario
   -11 - Valor inv�lido para par�metro d_aceita_posts_outros
   -12 - Valor inv�lido para par�metro d_aceita_comentarios_outros  
   -13 - Valor inv�lido para par�metro in_limite_sms_dia

    
Altera��es:

   20/05/2004 - Cristiano Perozzo
      - Retirados os par�metros de entrada in_espaco_ocupado e in_hits.
      - Inclu�do valor '3' para d_aceita_comentarios
      
   21/05/2004 - Cristiano Perozzo
      - Caso o usr_nick_id do flog que est� sendo alterado mude e o anterior n�o esteja sendo usado por nenhum outro flog do usu�rio o registro do usr_nick � exclu�do da tabela trr_usr_nick

   23/08/2004 - Cristiano Perozzo
      - Inclu�dos par�metros iv_senha, iv_d_aceita_posts_outros, iv_d_aceita_comentarios_outros
      - Criados valores de retorno -11 e -12

   25/10/2004 - Cristiano Perozzo
      - aceito o valor 'M' no campo d_aviso_comentarios 

   13/12/2004 - Cristiano Perozzo
      - inclu�do par�metro de entrada in_limite_sms_dia (OPCIONAL)
      - inclu�do c�digo de retorno de erro: -13

   28/12/2004 - Cristiano Perozzo
      - acrescentados os "substr" nos valores alterados para evitar erros no banco para caracteres especiais que s�o armazenados como mais de um char

  */
 
 
 ln_usr_nick_id  trr_flogs.usr_nick_id%type;
 ln_usr_nick_id_alterado  trr_flogs.usr_nick_id%type;
 ln_usrf_id      trr_usr_flogs.usrf_id%type;
 ln_ret          integer;
 lv_sql          varchar2(3000);
 ln_flag         integer;
 ln_aux	         number;
  
 Cursor c_cur_flog is
   select usr_nick_id
   from trr_flogs
   where flog_id = in_flog_id;
   
 Cursor c_cur_usrf is
  select usrf_id
  from trr_usr_nick
  where usr_nick_id = ln_usr_nick_id;
  
Cursor c_cur_nick is
 select usr_nick_id
 from trr_usr_nick
 where usrf_id = ln_usrf_id 
   and lower(nick_usuario) = lower(iv_nick_usuario);
   
 Cursor c_cur_nick_flog is
  select 1
  from trr_flogs 
  where lower(nick_flog) = lower(iv_nick_flog);
  
 Cursor c_cur_flogs_do_nick (l_usr_nick_id number) is
  select 1
  from trr_flogs
  where usr_nick_id = l_usr_nick_id;

 
 begin
   -- Valida Par�metros obrigatorios
   if (in_flog_id is null) then 
     return(-1);-- Par�metros obrigat�rios n�o informados
   end if;
   
   -- Valida flog
   open c_cur_flog;
   fetch c_cur_flog into ln_usr_nick_id;
   if(c_cur_flog%NOTFOUND) then 
   	close c_cur_flog;
   	return(-2); -- Flog inexistente
   else
   	close c_cur_flog;
   end if;
   
   
   -- Valida nick usuario
   if (iv_nick_usuario is not null) then 
      
      -- Obtem usrf_id
      open c_cur_usrf;
      fetch c_cur_usrf into ln_usrf_id;
      close c_cur_usrf;
      
      -- Verifica se nick_usuario � do usu�rio dono do flog
      open c_cur_nick;
      fetch c_cur_nick into ln_usr_nick_id_alterado;
      if (c_cur_nick%NOTFOUND) then
        close c_cur_nick;
        return(-3);-- Nick Inexistente
      else
        close c_cur_nick;
      end if;
  
     
   end if;
   
 -- Valida nick_flog
 if (iv_nick_flog is not null) then 
   
   open c_cur_nick_flog;
   fetch c_cur_nick_flog into ln_ret;
   if (c_cur_nick_flog%FOUND) then
     close c_cur_nick_flog;
     return(-4);-- Nick Flog j� existe
   else
     close c_cur_nick_flog;
   end if;
 end if;
 
 
  -- Valida par�metro d_habilitado
  if (ic_d_habilitado not in ('S', 'N') ) then 
  	return(-5); -- Valor Inv�lido para o par�metro ic_d_habilitado
  end if;
  
  -- Valida par�metro d_visivel_busca
  if (ic_d_visivel_busca not in ('S', 'N') ) then 
  	return(-6); -- Valor Inv�lido para o par�metro ic_d_visivel_busca
  end if;
  
  -- Valida par�metro d_aceita_votos
  if (ic_d_aceita_votos not in ('S', 'N') ) then 
  	return(-7); -- Valor Inv�lido para o par�metro ic_d_aceita_votos
  end if;
  
  -- Valida par�metro d_aceita_comentarios
  if (ic_d_aceita_comentarios not in ('0', '1', '2', '3') ) then 
  	return(-8); -- Valor Inv�lido para o par�metro ic_d_aceita_comentarios
  end if;
  
 -- Valida par�metro d_aviso_comentarios
  if (ic_d_aviso_comentarios not in ('S', 'N', 'M') ) then 
  	return(-9); -- Valor Inv�lido para o par�metro ic_d_aviso_comentarios
  end if;
  
 -- Valida par�metro d_comunitario
  if (ic_d_comunitario not in ('S', 'N') ) then 
  	return(-10); -- Valor Inv�lido para o par�metro ic_d_comunitario
  end if;

 -- Valida par�metro d_aceita_posts_outros
  if (iv_d_aceita_posts_outros not in ('0', '1', '2') ) then 
  	return(-11); 
  end if;

 -- Valida par�metro d_aceita_comentarios_outros
  if (iv_d_aceita_comentarios_outros not in ('S', 'N') ) then 
  	return(-12); 
  end if;

 -- Valida limite_sms_dia  
 if (in_limite_sms_dia is not null) then
    if (in_limite_sms_dia < -1) then
       return(-13);
    end if;
 end if;
 
 -- Altera flog
 lv_sql:= 'update trr_flogs set ';
 
 if (iv_nick_usuario is not null) then
   lv_sql:= lv_sql || ' usr_nick_id = ' || ln_usr_nick_id_alterado;
   ln_flag := 1; 
 end if;
 
 if (iv_nick_flog is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,nick_flog = ''' || substr(iv_nick_flog, 1, 60) || '''';
	else
		lv_sql:= lv_sql || ' nick_flog = ''' || substr(iv_nick_flog, 1, 60) || '''';
		ln_flag := 1;
	end if;
 end if;
 
 if (iv_titulo is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,titulo = ''' || substr(replace(iv_titulo, '''', ''''''), 1, 100) || '''';
	else
		lv_sql:= lv_sql || ' titulo = ''' || substr(replace(iv_titulo, '''', ''''''), 1, 100) || '''';
		ln_flag := 1;
	end if;
 end if;
 

 if (ic_d_habilitado is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,d_habilitado = ''' || ic_d_habilitado || '''';
	else
		lv_sql:= lv_sql || ' d_habilitado = ''' || ic_d_habilitado || '''';
		ln_flag := 1;
	end if;
 end if;


 if (ic_d_visivel_busca is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,d_visivel_busca = ''' || ic_d_visivel_busca || '''';
	else
		lv_sql:= lv_sql || ' d_visivel_busca = ''' || ic_d_visivel_busca || '''';
		ln_flag := 1;
	end if;
 end if;


 if (ic_d_aceita_votos is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,d_aceita_votos = ''' || ic_d_aceita_votos || '''';
	else
		lv_sql:= lv_sql || ' d_aceita_votos = ''' || ic_d_aceita_votos || '''';
		ln_flag := 1;
	end if;
 end if;


 if (ic_d_aceita_comentarios is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,d_aceita_comentarios = ''' || ic_d_aceita_comentarios || '''';
	else
		lv_sql:= lv_sql || ' d_aceita_comentarios = ''' || ic_d_aceita_comentarios || '''';
		ln_flag := 1;
	end if;
 end if;


 if (ic_d_aviso_comentarios is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,d_aviso_comentarios = ''' || ic_d_aviso_comentarios || '''';
	else
		lv_sql:= lv_sql || ' d_aviso_comentarios = ''' || ic_d_aviso_comentarios || '''';
		ln_flag := 1;
	end if;
 end if;


 if (ic_d_comunitario is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,d_comunitario = ''' || ic_d_comunitario || '''';
	else
		lv_sql:= lv_sql || ' d_comunitario = ''' || ic_d_comunitario || '''';
		ln_flag := 1;
	end if;
 end if;


 if (iv_config_template is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,config_template = ''' || iv_config_template || '''';
	else
		lv_sql:= lv_sql || ' config_template = ''' || iv_config_template || '''';
		ln_flag := 1;
	end if;
 end if;


 if (iv_ip is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,ip = ''' || iv_ip || '''';
	else
		lv_sql:= lv_sql || ' ip = ''' || iv_ip || '''';
		ln_flag := 1;
	end if;
 end if;


 if (iv_ip_forward is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,ip_forward = ''' || iv_ip_forward || '''';
	else
		lv_sql:= lv_sql || ' ip_forward = ''' || iv_ip_forward || '''';
		ln_flag := 1;
	end if;
 end if;

 if (iv_senha is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,senha = lower(''' || iv_senha || ''')';
	else
		lv_sql:= lv_sql || ' senha = lower(''' || iv_senha || ''')';
		ln_flag := 1;
	end if;
 end if;

 if (iv_d_aceita_posts_outros is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,d_aceita_posts_outros = ''' || iv_d_aceita_posts_outros || '''';
	else
		lv_sql:= lv_sql || ' d_aceita_posts_outros = ''' || iv_d_aceita_posts_outros || '''';
		ln_flag := 1;
	end if;
 end if;

 if (iv_d_aceita_comentarios_outros is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,d_aceita_comentarios_outros = ''' || iv_d_aceita_comentarios_outros || '''';
	else
		lv_sql:= lv_sql || ' d_aceita_comentarios_outros = ''' || iv_d_aceita_comentarios_outros || '''';
		ln_flag := 1;
	end if;
 end if;

 if (in_limite_sms_dia is not null) then
	if (ln_flag = 1) then 
		lv_sql:= lv_sql || ' ,limite_sms_dia = ' || in_limite_sms_dia;
	else
		lv_sql:= lv_sql || ' limite_sms_dia = ' || in_limite_sms_dia;
		ln_flag := 1;
	end if;
 end if;
 
 lv_sql:= lv_sql || ' where flog_id = ' || in_flog_id;
 
 execute immediate lv_sql;

 -- Exclui nick original da tabela de nicks caso n�o tenha nenhum flog associado ao nick
 if (ln_usr_nick_id_alterado <> ln_usr_nick_id) then
    open c_cur_flogs_do_nick(ln_usr_nick_id);
    fetch c_cur_flogs_do_nick into ln_aux;
    if (c_cur_flogs_do_nick%NOTFOUND) then 
       delete from trr_usr_nick
       where usr_nick_id = ln_usr_nick_id;
    else
       close c_cur_flogs_do_nick;
    end if;
 end if;


 commit;
 return(0);   

 
 end trr_fnc_altera_flog;
/
