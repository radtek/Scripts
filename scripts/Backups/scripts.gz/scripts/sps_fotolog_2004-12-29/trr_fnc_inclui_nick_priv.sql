   create or replace function trr_fnc_inclui_nick_priv
   (in_usrf_id       in trr_usr_flogs.usrf_id%type,
    iv_nick_usuario  in trr_usr_nick.nick_usuario%type,
    iv_cidade        in trr_usr_nick.cidade%type,
    iv_estado        in trr_usr_nick.estado%type,
    iv_pais          in trr_usr_nick.pais%type,
    ic_sexo          in trr_usr_nick.sexo%type,
    iv_dt_nasc       in varchar2,
    iv_est_civil     in trr_usr_nick.est_civil%type,
    iv_e_mail        in trr_usr_nick.e_mail%type,
    iv_perfil        in trr_usr_nick.perfil%type
   )

   return integer
   is
   /*
   Nome da fun��o: trr_fnc_inclui_nick_priv
   Descri��o: Insere nick para o usuario (n�o faz commit).
   Data: 05/05/2004
   Autor: Taise Lorenzi
   
   Par�metros:
   
       in_usrf_id      number(10)     - OBRIGATORIO
       iv_nick_usuario varchar2(60)   - OBRIGATORIO
       iv_cidade       varchar2(60)   - OPCIONAL
       iv_estado       varchar2(2)    - OPCIONAL
       iv_pais         varchar2(60)   - OPCIONAL
       ic_sexo         char(1)        - OPCIONAL
       iv_dt_nasc      varchar2       - OPCIONAL
       iv_est_civil    varchar2(20)   - OPCIONAL
       iv_e_mail       varchar2(60)   - OPCIONAL
       iv_perfil       varchar2(4000) - OPCIONAL


   Retorno:
   
      >0 - Sucesso
      -1 - Par�metros obrigat�rios n�o informados
      -2 - Usu�rio Inexistente
      -3 - Formato inv�lido para par�metro dt_nasc
      -4 - Nickname j� existe para este usu�rio
      
   Altera��es:
	
	21/05/2004 - Cristiano Perozzo
		- Corrigido o tipo do par�metro dt_nasc e a inclus�o (to_date).

        28/12/2004 - Cristiano Perozzo
      		- acrescentados os "substr" nos valores inclu�dos para evitar erros no banco para caracteres especiais que s�o armazenados como mais de um char
   	
    */
   
   ld_data          trr_usr_nick.dt_nasc%type;
   ln_usr_nick_id   trr_usr_nick.usr_nick_id%type;
   ln_aux           number(10);

   
   Cursor c_cur_user is
    select 1 
    from trr_usr_flogs
    where usrf_id = in_usrf_id;
   
   
   Cursor c_cur_nickname is
    select usr_nick_id 
    from trr_usr_nick 
    where lower(nick_usuario) = lower(iv_nick_usuario)
      and usrf_id = in_usrf_id;
   
   
   begin
   
    -- Valida par�metros obrigat�rios
    if ( (in_usrf_id is null) or 
         (iv_nick_usuario is null) 
        )then 
      return(-1); --  Par�metros obrigat�rios n�o informados
    end if;
    
    
    -- Valida Usu�rio
    open c_cur_user;
    fetch c_cur_user into ln_aux;
    if(c_cur_user%NOTFOUND)then 
      close c_cur_user;
      return(-2); -- c_cur_user
    else
      close c_cur_user;
    end if;
    
    -- Valida formato do par�metro dt_nasc
    if (iv_dt_nasc is not null) then 
    
    begin
    	   ld_data:= to_date(iv_dt_nasc,'dd/mm/yyyy');
    		exception 
    		  when others then
   		    return(-3); -- Formato inv�lido para o par�metro iv_dt_nasc 
    end;
   
   end if;
   
   
   -- Consulta se nick existe
      open c_cur_nickname;
      fetch c_cur_nickname into ln_usr_nick_id;
      if (c_cur_nickname%NOTFOUND) then 
	   	-- Insere novo nick
	   	insert into trr_usr_nick(  usrf_id
	   	                          ,nick_usuario
	   	                          ,cidade
	   	                          ,estado
	   	                          ,pais
	   	                          ,sexo
	   	                          ,dt_nasc
	   	                          ,est_civil
	   	                          ,e_mail
	   	                          ,perfil
	   	                         )
	      values (   in_usrf_id
	                ,substr(iv_nick_usuario, 1, 60)
	                ,substr(iv_cidade, 1, 60)
	                ,substr(iv_estado, 1, 2)
	                ,substr(iv_pais, 1, 60)
	                ,ic_sexo
	                ,to_date(iv_dt_nasc, 'dd/mm/yyyy')
	                ,substr(iv_est_civil, 1, 20)
	                ,substr(iv_e_mail, 1, 60)
	                ,substr(iv_perfil, 1, 4000)
	                )
	     returning usr_nick_id into ln_usr_nick_id;
	     close c_cur_nickname;
	                
	   else 
	    close c_cur_nickname;
	    return(-4); -- Nickname j� existe para este usu�rio
	   end if;

   return(ln_usr_nick_id);
   
   end trr_fnc_inclui_nick_priv;
/
