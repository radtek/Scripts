Accept own prompt 'Owner:'

SELECT 'ALTER '||DECODE(OBJECT_TYPE,'PACKAGE BODY','PACKAGE',OBJECT_TYPE)
       ||OBJECT_NAME||
       DECODE (OBJECT_TYPE,'PACKAGE BODY',' COMPILE BODY;' , ' COMPILE;')
from user_objects
where status <>'VALID'
order by object_type
/

@trr_fnc_altera_flog.sql
@trr_fnc_altera_nick.sql
@trr_fnc_altera_post.sql
@trr_fnc_inclui_flog.sql
@trr_fnc_inclui_nick_priv.sql
@trr_fnc_inclui_post.sql
@trr_fnc_inclui_post_inbox.sql

exec dbms_utility.compile_schema(upper('&own'));

SELECT 'ALTER '||DECODE(OBJECT_TYPE,'PACKAGE BODY','PACKAGE',OBJECT_TYPE)
       ||OBJECT_NAME||
       DECODE (OBJECT_TYPE,'PACKAGE BODY',' COMPILE BODY;' , ' COMPILE;')
from user_objects
where status <>'VALID'
order by object_type
/


