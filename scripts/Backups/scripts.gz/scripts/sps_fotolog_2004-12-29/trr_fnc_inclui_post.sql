create or replace function trr_fnc_inclui_post
 (c_cur                 in out trr_pck_cur_type.t_cur_type
 ,in_flog_id            in trr_flogs.flog_id%type
 ,iv_titulo             in trr_posts.titulo%type
 ,iv_texto              in trr_posts.texto%type
 ,iv_extensao_arquivo   in trr_posts.arquivo%type
 ,in_espaco_ocupado     in trr_posts.espaco_ocupado%type
 ,in_max_posts_dia      in trr_flogs.nro_posts_dia%type
 ,in_max_espaco_ocupado in trr_usr_flogs.espaco_ocupado%type
 ,in_usr_com_id         in trr_usr_comunitario.usr_com_id%type
 ,iv_origem	    	in trr_origens.descricao%type
 )
 return integer
 is 

/*

Nome da fun��o: trr_fnc_inclui_post
Descri��o: Inclui um post em um flog de um usu�rio j� cadastrado
Autor: Leonardo Leites
Data: 10/05/2004

Par�metros:

   c_cur:                  cursor para o retorno dos dados                             - OBRIGATORIO
   in_flog_id:             identificador do flog ao qual pertence o post (number(10))  - OBRIGATORIO
   iv_titulo:              t�tulo do post (varchar2(100))                              - OBRIGATORIO
   iv_texto:               texto do post (varchar2(4000))                              - OBRIGATORIO
   iv_extensao_arquivo:    extensao do arquivo da foto do post (varchar2(30))          - OBRIGATORIO
   in_espaco_ocupado:      espa�o ocupado pelo post (number(10))                       - OBRIGATORIO
   in_max_posts_dia:       n�mero m�ximo de posts permitido por dia (number(10))       - OBRIGATORIO
   in_max_espaco_ocupado:  espa�o ocupado m�ximo permitido (number(10))                - OBRIGATORIO
   in_usr_com_id:          identificador de um usu�rio comunit�rio (number(10))        - OPCIONAL 
   iv_origem:	    	   descri��o da origem do post			      	       - OBRIGATORIO  

Retorno:

    0 - Sucesso
   -1 - Par�metro(s) obrigat�rio(s) n�o informado(s)
   -2 - Identificador de flog inv�lido
   -3 - Identificador de usu�rio comunit�rio inv�lido
   -4 - N�mero m�ximo de posts permitido por dia ultrapassado
   -5 - Espa�o ocupado m�ximo permitido ultrapassado
   -6 - Chave �nica duplicada (post_id ou arquivo ou ordem)
   -7 - Flog em lock

   Dados retornados no cursor:

   post_id     	identificador do post criado (number(10))
   dt_criacao  	data de cria��o do post criado (dd/mm/yyyy hh24:mi)   
   ordem	campo ordem da tabela trr_posts

Altera��es:

   17/05/2004 - Cristiano Perozzo
      - Substituicao do parametro iv_arquivo por iv_extensao_arquivo: o nome do arquivo ser� armazenado com a concatena��o dos campos trr_posts.ordem+'.'+iv_extensao_arquivo.
        Chamar a sp com iv_extensao_arquivo = 'jpg', por exemplo.
   
   18/05/2004 - Cristiano Perozzo
      - Inclu�do o campo ordem no cursor de retorno.

   25/05/2004 - Cristiano Perozzo
      - Incluidos valores 0 para os campos quant_comentarios e espaco_comentarios

   04/06/2004 - Cristiano Perozzo
      - Corrigida a gera��o do par�metro ORDEM do post. Sempre deve iniciar com 1 para fotologs sem posts.

   23/08/2004 - Cristiano Perozzo
      - inclu�do par�metro de entrada iv_origem
      - ORIGENS NOVAS s�o automaticamente inclu�das na tabela TRR_ORIGENS;
      - A consist�ncia que j� era feita com o atributo de entrada in_max_posts_dia com trr_flogs.nro_posts_dia � feita agora com a tabela TRR_FLOG_ORIGEM

   31/08/2004 - Cristiano Perozzo
      - inclu�do tratamento para valor -1 no par�metro in_max_posts_dia (-1 = ilimitado)

   28/12/2004 - Cristiano Perozzo
      - acrescentados os "substr" nos valores inclu�dos para evitar erros no banco para caracteres especiais que s�o armazenados como mais de um char

*/

   c_flog                  trr_pck_cur_type.t_cur_type;
   ln_nro_posts_dia        trr_flogs.nro_posts_dia%type;
   ld_dt_ultimo_post       trr_flogs.dt_ultimo_post%type;
   ln_usr_espaco_ocupado   trr_usr_flogs.espaco_ocupado%type;
   ln_usrf_id              trr_usr_flogs.usrf_id%type;
   c_usr_com               trr_pck_cur_type.t_cur_type;
   ln_usr_com_id           trr_usr_comunitario.usr_com_id%type;
   ln_novo_espaco_ocupado  trr_usr_flogs.espaco_ocupado%type;  -- Espa�o ocupado (total) pelo usu�rio
   ln_nova_ordem           trr_posts.ordem%type;
   ln_post_id              trr_posts.post_id%type;
   ld_dt_criacao           trr_posts.dt_criacao%type;
   ln_origem_id		   trr_origens.origem_id%type;

   cursor c_cur_lock is
   select *
     from trr_flogs
    where flog_id = in_flog_id
      for update nowait;

   cursor c_cur_origens (iv_dsc_or trr_origens.descricao%type) is
   select origem_id
     from trr_origens
    where descricao = iv_dsc_or;
   
   cursor c_cur_posts_dia_origem (in_fl_id trr_flogs.flog_id%type, in_or_id trr_origens.origem_id%type) is
   select nro_posts_dia, trunc(dt_ultimo_post) 
     from trr_flog_origens
    where flog_id = in_fl_id
      and origem_id = in_or_id;

begin
   -- Valida par�metros obrigat�rios
   if ((in_flog_id is null) or
       (iv_titulo is null) or
       (iv_texto is null) or
       (iv_extensao_arquivo is null) or
       (in_espaco_ocupado is null) or
       (iv_origem is null)) then
	  return(-1);  -- Par�metro(s) obrigat�rio(s) n�o informado(s)
   end if;

   -- In�cio do lock na trr_flogs
   open c_cur_lock;

   -- Verifica se o flog existe
   open c_flog for
      select usr.espaco_ocupado, usr.usrf_id 
        from trr_flogs flogs, trr_usr_nick nick, trr_usr_flogs usr
       where flogs.flog_id     = in_flog_id
	 and flogs.usr_nick_id = nick.usr_nick_id
	 and nick.usrf_id      = usr.usrf_id;

      fetch c_flog into ln_usr_espaco_ocupado, ln_usrf_id;		   

      if (c_flog%NOTFOUND) then
         close c_flog;
         return(-2);  -- Identificador de flog inv�lido
      else
         close c_flog;
      end if;   
   
   -- Verifica se o usu�rio comunit�rio existe
   if (in_usr_com_id is not null) then
      open c_usr_com for
         select usr_com_id
           from trr_usr_comunitario
          where usr_com_id = in_usr_com_id;

         fetch c_usr_com into ln_usr_com_id;

         if (c_usr_com%NOTFOUND) then
            close c_usr_com;
            return(-3);  -- Identificador de usu�rio comunit�rio inv�lido
         else
            close c_usr_com;
         end if;
   end if;   

   -- verifica se a origem existe
   open c_cur_origens(iv_origem);
   fetch c_cur_origens into ln_origem_id;
   if (c_cur_origens%NOTFOUND) then
      -- incluir na tabela de origens;
      insert into trr_origens(descricao) values (iv_origem)
        returning origem_id into ln_origem_id;
   end if;
   close c_cur_origens;

   -- Verifica se o flog tem permiss�o para receber um novo post no dia atual   
   -- alterado para consultar a tabela trr_flog_origens;
   --if ((ld_dt_ultimo_post = trunc(current_date)) and (ln_nro_posts_dia >= in_max_posts_dia)) then
   --   return(-4);  -- N�mero m�ximo de posts permitido por dia ultrapassado
   --end if; 

   open c_cur_posts_dia_origem (in_flog_id, ln_origem_id);
   fetch c_cur_posts_dia_origem into ln_nro_posts_dia, ld_dt_ultimo_post;

   if (in_max_posts_dia >=0) then
      if (c_cur_posts_dia_origem%FOUND) then
         if ((ld_dt_ultimo_post = trunc(current_date)) and (ln_nro_posts_dia >= in_max_posts_dia)) then
            return(-4);  -- N�mero m�ximo de posts permitido por dia ultrapassado
         end if; 
      end if;
   end if;


   -- Verifica se o espa�o ocupado do usu�rio n�o ser� ultrapassado
   ln_novo_espaco_ocupado := ln_usr_espaco_ocupado + in_espaco_ocupado;  -- Espa�o ocupado (total) pelo usu�rio

   if ((ln_novo_espaco_ocupado > in_max_espaco_ocupado) and (in_max_espaco_ocupado > 0)) then
      return(-5);  -- Espa�o ocupado m�ximo permitido ultrapassado
   end if;	           

   -- Atualiza o espa�o ocupado pelo usu�rio
   update trr_usr_flogs
      set espaco_ocupado = ln_novo_espaco_ocupado  -- Espa�o ocupado (total) pelo usu�rio
	where usrf_id = ln_usrf_id;
	
   -- Atualiza o flog do usu�rio
   update trr_flogs
      set espaco_ocupado = espaco_ocupado + in_espaco_ocupado  -- Espa�o ocupado pelo flog
    where flog_id = in_flog_id;    

   if (c_cur_posts_dia_origem%NOTFOUND) then
      insert into trr_flog_origens(dt_ultimo_post, nro_posts_dia, flog_id, origem_id)
	values (current_date, 1, in_flog_id, ln_origem_id);
   else
      if (ld_dt_ultimo_post <> trunc(current_date)) then  -- Primeiro post do dia (ou do flog)
         update trr_flog_origens 
            set dt_ultimo_post = current_date
	       ,nro_posts_dia  = 1
	  where flog_id = in_flog_id
	    and origem_id = ln_origem_id;
      else
         update trr_flog_origens 
            set dt_ultimo_post = current_date
	       ,nro_posts_dia  = nro_posts_dia + 1
	  where flog_id = in_flog_id
	    and origem_id = ln_origem_id;
      end if;
   end if;
   
   close c_cur_posts_dia_origem;
   
   -- Determina a ordem do pr�ximo post
   select nvl(max(ordem), 0) + 1
     into ln_nova_ordem 
     from trr_posts 
     where flog_id = in_flog_id;
	  

   -- Insere novo post
   insert into trr_posts
   (
	 ordem
	,titulo
	,texto
	,arquivo
	,dt_criacao
	,dt_alteracao
	,hits
	,hits_dia
        ,dt_hits_dia
	,soma_votos
	,nro_votos
	,espaco_ocupado
	,d_aprovado
	,d_habilitado
	,flog_id
	,usr_com_id
	,quant_comentarios
	,espaco_comentarios
	,origem_id
   )
   values
   (
    	ln_nova_ordem
    	,substr(iv_titulo, 1, 100)
	,substr(iv_texto, 1, 4000)
	,ln_nova_ordem||'.'||lower(iv_extensao_arquivo)
	,current_date
	,NULL
	,0
	,0
	,NULL
	,0
	,0
	,in_espaco_ocupado
	,'N'
	,'S'
	,in_flog_id
	,in_usr_com_id
	,0
	,0
	,ln_origem_id
   ) returning post_id, dt_criacao into ln_post_id, ld_dt_criacao;

   commit;		  
   close c_cur_lock;
   
   -- Cursor de retorno
   open c_cur for
      select ln_post_id post_id
             ,to_char(ld_dt_criacao, 'yyyymmdd') dt_criacao
             ,ln_nova_ordem ordem
        from dual;

   return(0);		

exception

   when DUP_VAL_ON_INDEX then
      begin
         rollback;
		 close c_cur_lock;
         return(-6);  -- Chave �nica duplicada (post_id ou arquivo ou ordem)
      end;

   when others then
      if (sqlcode = -54) then
         rollback;
         return(-7);  -- Flog em lock
      end if;

end trr_fnc_inclui_post;
/