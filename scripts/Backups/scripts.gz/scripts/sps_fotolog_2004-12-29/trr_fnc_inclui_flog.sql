 create or replace function trr_fnc_inclui_flog
 (in_usrf_id               in trr_usr_flogs.usrf_id%type
 ,iv_nick_usuario          in trr_usr_nick.nick_usuario%type
 ,iv_nick_flog             in trr_flogs.nick_flog%type
 ,iv_titulo                in trr_flogs.titulo%type
 ,ic_d_habilitado          in trr_flogs.d_habilitado%type
 ,ic_d_visivel_busca       in trr_flogs.d_visivel_busca%type
 ,ic_d_aceita_votos        in trr_flogs.d_aceita_votos%type
 ,ic_d_aceita_comentarios  in trr_flogs.d_aceita_comentarios%type
 ,ic_d_aviso_comentarios   in trr_flogs.d_aviso_comentarios%type
 ,ic_d_comunitario         in trr_flogs.d_comunitario%type
 ,iv_config_template       in trr_flogs.config_template%type
 ,iv_ip                    in trr_flogs.ip%type
 ,iv_ip_forward            in trr_flogs.ip_forward%type
 ,iv_cidade                in trr_usr_nick.cidade%type
 ,iv_estado                in trr_usr_nick.estado%type
 ,iv_pais                  in trr_usr_nick.pais%type
 ,ic_sexo                  in trr_usr_nick.sexo%type
 ,iv_dt_nasc               in varchar2
 ,iv_est_civil             in trr_usr_nick.est_civil%type
 ,iv_e_mail                in trr_usr_nick.e_mail%type
 ,iv_perfil                in trr_usr_nick.perfil%type
 ,in_limite_sms_dia	   in trr_flogs.limite_sms_dia%type default 3
 )
 
 
 return integer
 is
 /*
 Nome da fun��o: trr_fnc_inclui_flog
 Descri��o: Inclui flog para usu�rio.
 Data: 05/05/2004
 Autor: Taise Lorenzi
 
 Par�metros:
  
    in_usrf_id    	    number(10)                  - OBRIGATORIO
    iv_nick_usuario         varchar2(60)                - OBRIGATORIO
    iv_nick_flog            varchar2(60)                - OBRIGATORIO
    iv_titulo               varchar2(100)               - OBRIGATORIO
    ic_d_habilitado         char(01)                    - OBRIGATORIO
    ic_d_visivel_busca      char(01)                    - OBRIGATORIO
    ic_d_aceita_votos       char(01)                    - OBRIGATORIO
    ic_d_aceita_comentarios char(01)                    - OBRIGATORIO
    ic_d_aviso_comentarios  char(01)                    - OBRIGATORIO
    ic_d_comunitario        char(01)                    - OBRIGATORIO
    iv_config_template      varchar2(255)               - OBRIGATORIO
    iv_ip                   varchar2(20)                - OPCIONAL
    iv_ip_forward           varchar2(255)               - OPCIONAL
    iv_cidade               varchar2(60)                - OPCIONAL
    iv_estado               varchar2(02)                - OPCIONAL
    iv_pais                 varchar2(60)                - OPCIONAL
    ic_sexo                 char(01)                    - OPCIONAL
    iv_dt_nasc              varchar2(10)                - OPCIONAL
    iv_est_civil            varchar2(20)                - OPCIONAL
    iv_e_mail               varchar2(60)                - OPCIONAL
    iv_perfil               varchar2(4000)              - OPCIONAL
    in_limite_sms_dia	    number(10)			- OBRIGATORIO

    
 Retorno:
 
    >0 - Sucesso
    -1 - Par�metros obrigat�rios n�o informados
    -2 - Usu�rio inexistente
    -3 - Formato inv�lido para par�metro dt_nasc
    -4 - Nickname j� existe para este usu�rio
    -5 - Flog existente
    -6 - Valor inv�lido para par�metro d_habilitado
    -7 - Valor inv�lido para par�metro d_visivel_busca
    -8 - Valor inv�lido para par�metro d_aceita_votos
    -9 - Valor inv�lido para par�metro d_aceita_comentarios
   -10 - Valor inv�lido para par�metro d_aviso_comentarios
   -11 - Valor inv�lido para par�metro d_comunitario
   -12 - Valor inv�lido para par�metro in_limite_sms_dia
    
    
 Retorno da fun��o:
 	- flog_id 

 Alteracoes:

   11/08/2004 - Cristiano Rech Perozzo
      - o campo D_LIBERADO_LISTAS passa a ser inclu�do com valor 'S'

   23/08/2004 - Cristiano Rech Perozzo
      - campo d_aceita_posts_outros inclu�do com valor '0'
      - campo d_aceita_comentarios_outros inclu�do com valor 'N'
    
   25/10/2004 - Cristiano Perozzo
      - aceito o valor 'M' no campo d_aviso_comentarios 

   13/12/2004 - Cristiano Perozzo
      - inclu�do par�metro de entrada in_limite_sms_dia (OBRIGATORIO)
      - inclu�do c�digo de retorno de erro: -12
  
   28/12/2004 - Cristiano Perozzo
      - acrescentados os "substr" nos valores inclu�dos para evitar erros no banco para caracteres especiais que s�o armazenados como mais de um char
  */

 ln_flog_id        trr_flogs.flog_id%type; 
 ln_usr_nick_id    trr_usr_nick.usr_nick_id%type;
 ln_user            number(10);
 ln_flog            number(10);
 ln_nick            integer;
 ld_data          trr_usr_nick.dt_nasc%type;

 Cursor c_cur_user is
  select 1
  from trr_usr_flogs
  where usrf_id = in_usrf_id;
  
Cursor c_cur_nickname is
 select usr_nick_id
 from trr_usr_nick
 where lower(nick_usuario) = lower(iv_nick_usuario)
   and usrf_id = in_usrf_id;

Cursor c_cur_flog is
 select 1 
 from trr_flogs
 where nick_flog = lower(iv_nick_flog);
    
   
   
 begin
 
   -- Valida��o de Par�metros Obrigat�rios
   
   if ( (in_usrf_id is null) or 
        (iv_nick_usuario is null) or
        (iv_nick_flog is null) or 
        (iv_titulo is null) or 
        (ic_d_habilitado is null) or
        (ic_d_visivel_busca is null) or
        (ic_d_aceita_votos is null) or
        (ic_d_aceita_comentarios is null) or
        (ic_d_aviso_comentarios is null) or
        (ic_d_comunitario is null) or
        (iv_config_template is null) or
	(in_limite_sms_dia is null)   
   )then 
     return(-1); -- Par�metros obrigat�rios n�o informados
   end if;
   
 -- Valida limite_sms_dia  
 if (in_limite_sms_dia < -1) then
    return(-12);
 end if;
  
  -- Valida Usu�rio
  open c_cur_user;
  fetch c_cur_user into ln_user;
  if (c_cur_user%NOTFOUND) then 
   close c_cur_user;
   return(-2); -- Usu�rio inexistente
  else
   close c_cur_user;
  end if;
  

 -- valida data de nascimento
   if (iv_dt_nasc is not null) then 
     begin
     	   ld_data:= to_date(iv_dt_nasc,'dd/mm/yyyy');
     		exception 
     		  when others then
    		    return(-3); -- Formato inv�lido para o par�metro iv_dt_nasc 
     end;
   end if;
 
 
 -- Valida nickname, se n�o existir insere
 open c_cur_nickname;
 fetch c_cur_nickname into ln_usr_nick_id;
 if (c_cur_nickname%NOTFOUND) then 
  		 -- Insere nick
  		 ln_usr_nick_id:= trr_fnc_inclui_nick_priv( in_usrf_id
  				                                      ,iv_nick_usuario
  				                                      ,iv_cidade
  				                                      ,iv_estado
  				                                      ,iv_pais
                                         			  ,ic_sexo
                                         			  ,ld_data
				                                      ,iv_est_civil
			                                         ,iv_e_mail
			                                         ,iv_perfil);
		  close c_cur_nickname;
  
 else
 
  close c_cur_nickname;
  
 end if;
 
 -- Valida Flog
  open c_cur_flog;
  fetch c_cur_flog into ln_flog;
  if (c_cur_flog%FOUND) then 
   close c_cur_flog;
   return(-5); -- Flog existente
  else
   close c_cur_flog;
  end if;


 
 -- Valida par�metro d_habilitado
 if (ic_d_habilitado not in ('S', 'N') ) then 
 	return(-6); -- Valor Inv�lido para o par�metro ic_d_habilitado
 end if;
 
 -- Valida par�metro d_visivel_busca
 if (ic_d_visivel_busca not in ('S', 'N') ) then 
 	return(-7); -- Valor Inv�lido para o par�metro ic_d_visivel_busca
 end if;
 
 -- Valida par�metro d_aceita_votos
 if (ic_d_aceita_votos not in ('S', 'N') ) then 
 	return(-8); -- Valor Inv�lido para o par�metro ic_d_aceita_votos
 end if;
 
 -- Valida par�metro d_aceita_comentarios
 if (ic_d_aceita_comentarios not in ('0', '1', '2', '3') ) then 
 	return(-9); -- Valor Inv�lido para o par�metro ic_d_aceita_comentarios
 end if;
 
-- Valida par�metro d_aviso_comentarios
 if (ic_d_aviso_comentarios not in ('S', 'N', 'M') ) then 
 	return(-10); -- Valor Inv�lido para o par�metro ic_d_aviso_comentarios
 end if;
 
-- Valida par�metro d_comunitario
 if (ic_d_comunitario not in ('S', 'N') ) then 
 	return(-11); -- Valor Inv�lido para o par�metro ic_d_comunitario
 end if;

 
 begin
 		-- Insere Flog
 			insert into trr_flogs( usr_nick_id
 			                     ,nick_flog
 			                     ,titulo
 			                     ,nro_posts_dia
 			                     ,d_habilitado
 			                     ,d_visivel_busca
 			                     ,d_aceita_votos
 			                     ,d_aceita_comentarios
 			                     ,d_aviso_comentarios
 			                     ,d_comunitario
 			                     ,config_template
 			                     ,ip
 			                     ,ip_forward
 			                     ,espaco_ocupado
 			                     ,hits
 			                     ,dt_criacao
 			                     ,dt_ult_alteracao
					     ,d_liberado_listas
					     ,d_aceita_posts_outros
					     ,d_aceita_comentarios_outros
					     ,limite_sms_dia
 			                     )
 			 values ( ln_usr_nick_id
 			         ,lower(substr(iv_nick_flog, 1, 60))
 			         ,substr(iv_titulo, 1, 100)
 			         ,0
 			         ,ic_d_habilitado
 			         ,ic_d_visivel_busca
 			         ,ic_d_aceita_votos
 			         ,ic_d_aceita_comentarios
 			         ,ic_d_aviso_comentarios
 			         ,ic_d_comunitario
 			         ,iv_config_template
 			         ,iv_ip
 			         ,iv_ip_forward
 			         ,0
 			         ,0
 			         ,current_date
 			         ,current_date
				 ,'S'
				 ,'0'
				 ,'N'
				 ,in_limite_sms_dia
 			         )
 			returning flog_id into ln_flog_id;
    
    commit;
    return(ln_flog_id);
    
exception
  when others then
    rollback;
end;  
 
 

end trr_fnc_inclui_flog;
/
