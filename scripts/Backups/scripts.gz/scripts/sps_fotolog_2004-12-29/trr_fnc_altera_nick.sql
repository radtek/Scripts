   create or replace function trr_fnc_altera_nick
   (in_usr_nick_id   in trr_usr_nick.usr_nick_id%type,
    iv_nick_usuario  in trr_usr_nick.nick_usuario%type,
    iv_cidade        in trr_usr_nick.cidade%type,
    iv_estado        in trr_usr_nick.estado%type,
    iv_pais          in trr_usr_nick.pais%type,
    ic_sexo          in trr_usr_nick.sexo%type,
    iv_dt_nasc       in varchar2,
    iv_est_civil     in trr_usr_nick.est_civil%type,
    iv_e_mail        in trr_usr_nick.e_mail%type,
    iv_perfil        in trr_usr_nick.perfil%type
   )

   return integer
   is
   /*
   Nome da fun��o: trr_fnc_altera_nick
   Descri��o: Altera informa��es sobre nick do usuario.
   Data: 05/05/2004
   Autor: Taise Lorenzi
   
   Par�metros:
   
       in_usr_nick_id  number(10)     - OBRIGATORIO
       iv_nick_usuario varchar2(60)   - OPCIONAL
       iv_cidade       varchar2(60)   - OPCIONAL
       iv_estado       varchar2(2)    - OPCIONAL
       iv_pais         varchar2(60)   - OPCIONAL
       ic_sexo         char(1)        - OPCIONAL
       iv_dt_nasc      varchar2(24)   - OPCIONAL
       iv_est_civil    varchar2(20)   - OPCIONAL
       iv_e_mail       varchar2(60)   - OPCIONAL
       iv_perfil       varchar2(4000) - OPCIONAL


   Retorno:
   
       0 - Sucesso
      -1 - Par�metros obrigat�rios n�o informados
      -2 - Nick inexistente
      -3 - Nick_usuario existente
      -4 - Nenhum par�metro para alterar
      -5 - Formato inv�lido para o par�metro iv_dt_nasc 
      
   Altera��es:
	
	21/05/2004 - Cristiano Perozzo
		- Corrigido o tipo do par�metro dt_nasc e a inclus�o (to_date).

	31/05/2004 - Cristiano Rech Perozzo
		- Se o par�metro de entrada iv_dt_nasc for igual a "espa�o", atribui NULL ao campo dt_nasc;
		- Se o par�metro for NULL, ignora o campo na altera��o.

	22/09/2004 - Cristiano Rech Perozzo
		- Se o par�metro de entrada iv_e_mail for igual a "espa�o", atribui NULL ao campo e_mail;
		- Se o par�metro for NULL, ignora o campo na altera��o.

   	28/12/2004 - Cristiano Perozzo
      		- acrescentados os "substr" nos valores alterados para evitar erros no banco para caracteres especiais que s�o armazenados como mais de um char

    */
   
   ln_aux  number(10);
   ln_nick number(10);
   lv_sql  varchar2(3000);
   ln_flag integer;
   ld_data trr_usr_nick.dt_nasc%TYPE;
   ln_usrf_id trr_usr_flogs.usrf_id%TYPE;
   
   Cursor c_cur_nickname is
     select usrf_id
     from trr_usr_nick
     where usr_nick_id  = in_usr_nick_id;
         
  -- Cursor que procura o mesmo nick para o mesmo usu�rio com c�digo diferente do passado...
  Cursor c_cur_nick_usuario (l_usrf_id number) is
     select 1
     from trr_usr_nick
     where  usrf_id = l_usrf_id
        and usr_nick_id <> in_usr_nick_id
        and lower(nick_usuario) = lower(iv_nick_usuario);
        
   begin
   
    -- Valida Par�metros Obrigat�rios
    if (in_usr_nick_id is null) then 
      return(-1); -- Par�metros obrigat�rios n�o informados
    end if;
    
   -- Valida Nickname
   open c_cur_nickname;
   fetch c_cur_nickname into ln_usrf_id;
   if(c_cur_nickname%NOTFOUND) then 
      close c_cur_nickname;
      return(-2); -- Nick inexistente
   else
      close c_cur_nickname;
   end if;
   
   
   -- Verifica se o par�metro nick_usuario sera modificado
   if (iv_nick_usuario is not null) then

      -- Valida se nick_usuario j� existe para esse user
     
     open c_cur_nick_usuario(ln_usrf_id);
     fetch c_cur_nick_usuario into ln_nick;
     if (c_cur_nick_usuario%FOUND) then 
     	close c_cur_nick_usuario;
     	return(-3); -- Nick_usuario existente
     else
      close c_cur_nick_usuario;
     end if;
 
 end if;
   
   -- Verifica se h� dados para atualizar
   if ( (iv_nick_usuario is null) and
        (iv_cidade is null) and
        (iv_estado is null) and
        (iv_pais is null) and
        (ic_sexo is null) and
        (iv_dt_nasc is null) and
        (iv_est_civil is null) and
        (iv_e_mail is null) and
        (iv_perfil is null)
      )then 
      return(-4); -- Nenhum par�metro para alterar
   end if;
   
   
   
   -- Valida formato do par�metro dt_nasc
   if ((iv_dt_nasc is not null) and (iv_dt_nasc <> ' ')) then 
   
    begin
    	   ld_data:= to_date(iv_dt_nasc,'dd/mm/yyyy');
    		exception 
    		  when others then
   		    return(-5); -- Formato inv�lido para o par�metro iv_dt_nasc 
    end;
   
   end if;
   
   -- Altera informa��es do nickname 
   lv_sql:= 'update trr_usr_nick set ';
   
   if (iv_nick_usuario is not null) then 
   	lv_sql:= lv_sql || ' nick_usuario = '''  || substr(iv_nick_usuario, 1, 60) || '''';
   	ln_flag := 1;
   end if;
   
   if (iv_cidade is not null) then 
      if (ln_flag = 1) then 
        lv_sql:= lv_sql || ' ,cidade = ''' || substr(iv_cidade, 1, 60) || '''';
      else  
        lv_sql:= lv_sql || ' cidade = ''' || substr(iv_cidade, 1, 60) || '''';
        ln_flag:=1;
      end if;
   end if;
   
   if (iv_estado is not null) then 
      if (ln_flag = 1) then 
        lv_sql:= lv_sql || ' ,estado = ''' || substr(iv_estado, 1, 2) || '''';
      else  
        lv_sql:= lv_sql || ' estado = ''' || substr(iv_estado, 1, 2) || '''';
        ln_flag:=1;
      end if;
   end if;
   

   if (iv_pais is not null) then 
      if (ln_flag = 1) then 
        lv_sql:= lv_sql || ' ,pais = ''' || substr(iv_pais, 1, 60) || '''';
      else  
        lv_sql:= lv_sql || ' pais = ''' || substr(iv_pais, 1, 60) || '''';
        ln_flag:=1;
      end if;
   end if;


   if (ic_sexo is not null) then 
      if (ln_flag = 1) then 
        lv_sql:= lv_sql || ' ,sexo = ''' || ic_sexo  || '''';
      else  
        lv_sql:= lv_sql || ' sexo = ''' || ic_sexo  || '''';
        ln_flag:=1;
      end if;
   end if;
    
    
   if (iv_dt_nasc is not null) then 
      if (ln_flag = 1) then 
         if (iv_dt_nasc = ' ') then
            lv_sql:= lv_sql || ' ,dt_nasc = null';
	 else
            lv_sql:= lv_sql || ' ,dt_nasc = to_date(''' || iv_dt_nasc || ''', ''dd/mm/yyyy'')';
	 end if;
      else  
         if (iv_dt_nasc = ' ') then
            lv_sql:= lv_sql || ' dt_nasc = null';
	 else
            lv_sql:= lv_sql || ' dt_nasc = to_date(''' || iv_dt_nasc || ''', ''dd/mm/yyyy'')';
	 end if;
         ln_flag:=1;
      end if;
   end if;
    

   if (iv_est_civil is not null) then 
      if (ln_flag = 1) then 
        lv_sql:= lv_sql || ' ,est_civil = '''|| substr(iv_est_civil, 1, 20)  || '''';
      else  
        lv_sql:= lv_sql || ' est_civil = ''' || substr(iv_est_civil, 1, 20)  || '''';
        ln_flag:=1;
      end if;
   end if;


   if (iv_e_mail is not null) then 
      if (ln_flag = 1) then 
         if (iv_e_mail = ' ') then
            lv_sql:= lv_sql || ' ,e_mail = null';
	 else
            lv_sql:= lv_sql || ' ,e_mail = '''|| substr(iv_e_mail, 1, 60) || '''';
	 end if;
      else  
         if (iv_e_mail = ' ') then
            lv_sql:= lv_sql || ' e_mail = null';
	 else
            lv_sql:= lv_sql || ' e_mail = ''' || substr(iv_e_mail, 1, 60) || '''';
	 end if;
         ln_flag:=1;
      end if;
   end if;


   if (iv_perfil is not null) then 
      if (ln_flag = 1) then 
        lv_sql:= lv_sql || ' ,perfil = '''|| substr(iv_perfil, 1, 4000) || '''';
      else  
        lv_sql:= lv_sql || ' perfil = ''' || substr(iv_perfil, 1, 4000) || '''';
        ln_flag:=1;
      end if;
   end if;
   
   
   lv_sql:= lv_sql || ' where usr_nick_id = ' || in_usr_nick_id;
   
  execute immediate lv_sql;
  commit;
  return(0);   
   
end trr_fnc_altera_nick;
/
