create or replace function trr_fnc_altera_post
 (in_post_id            in trr_posts.post_id%type
 ,iv_titulo             in trr_posts.titulo%type
 ,iv_texto              in trr_posts.texto%type
 ,iv_arquivo            in trr_posts.arquivo%type
 ,in_espaco_ocupado     in trr_posts.espaco_ocupado%type
 ,in_max_espaco_ocupado in trr_usr_flogs.espaco_ocupado%type 
 ,ic_d_aprovado         in trr_posts.d_aprovado%type
 ,ic_d_habilitado       in trr_posts.d_habilitado%type
 )
 return integer
 is

/*

Nome da fun��o: trr_fnc_altera_post
Descri��o: Altera um post de um flog de um usu�rio
Autor: Leonardo Leites
Data: 10/05/2004

Par�metros:

   in_post_id:                identificador de um post (number(10))         - OBRIGATORIO
   iv_titulo:                 t�tulo do post (varchar2(100))                - OPCIONAL
   iv_texto:                  texto do post (varchar2(4000))                - OPCIONAL
   iv_arquivo:                foto do post (varchar2(30))                   - OPCIONAL 
   in_espaco_ocupado(*):      espa�o ocupado pelo post (number(10))         - OPCIONAL
   in_max_espaco_ocupado(*):  espa�o ocupado m�ximo permitido (number(10))  - OPCIONAL
   ic_d_aprovado:             define se um post est� aprovado (char(1))     - OPCIONAL
   ic_d_habilitado:           define se um post est� habilitado (char(1))   - OPCIONAL
   
   (*) Quando o espa�o ocupado for informado, o espa�o ocupado m�ximo permitido tamb�m deve ser informado.
   
Retorno:

    0 - Sucesso
   -1 - Par�metro(s) obrigat�rio(s) n�o informado(s)
   -2 - Identificador de post inv�lido
   -3 - Espa�o ocupado m�ximo permitido ultrapassado
   -4 - Chave �nica duplicada (arquivo)
   -5 - Valor inv�lido para o par�metro ic_d_aprovado
   -6 - Valor inv�lido para o par�metro ic_d_habilitado   

Altera��es:
	
   28/12/2004 - Cristiano Perozzo
      - acrescentados os "substr" nos valores alterados para evitar erros no banco para caracteres especiais que s�o armazenados como mais de um char

*/

   c_post                  trr_pck_cur_type.t_cur_type;
   ln_espaco_ocupado       trr_posts.espaco_ocupado%type;
   ln_flog_id              trr_flogs.flog_id%type;
   ln_usr_espaco_ocupado   trr_usr_flogs.espaco_ocupado%type;
   ln_usrf_id              trr_usr_flogs.usrf_id%type;
   ln_novo_espaco_ocupado  trr_usr_flogs.espaco_ocupado%type;
   ld_dt_alteracao         trr_posts.dt_alteracao%type;

begin

   -- Valida par�metros obrigat�rios
   if ( (in_post_id is null) or ((in_espaco_ocupado is not null) and (in_max_espaco_ocupado is null)) ) then
	  return(-1);  -- Par�metro(s) obrigat�rio(s) n�o informado(s)
   end if;

   -- Valida par�metro d_aprovado
   if (ic_d_aprovado not in ('S', 'N')) then
      return(-5);  -- Valor inv�lido para o par�metro ic_d_aprovado
   end if;

   -- Valida par�metro d_habilitado
   if (ic_d_habilitado not in ('S', 'N')) then
      return(-6);  -- Valor inv�lido para o par�metro ic_d_habilitado
   end if;

   -- Verifica se o post existe
   open c_post for
      select t1.espaco_ocupado, t2.flog_id, t4.espaco_ocupado, t4.usrf_id
        from trr_posts t1, trr_flogs t2, trr_usr_nick t3, trr_usr_flogs t4
       where t1.post_id     = in_post_id
	     and t1.flog_id     = t2.flog_id
		 and t2.usr_nick_id = t3.usr_nick_id
		 and t3.usrf_id     = t4.usrf_id;

      fetch c_post into ln_espaco_ocupado, ln_flog_id, ln_usr_espaco_ocupado, ln_usrf_id;		   

      if (c_post%NOTFOUND) then
         close c_post;
         return(-2);  -- Identificador de post inv�lido
      else
         close c_post;
      end if;

   if (in_espaco_ocupado is not null) then	  
	  
      -- Verifica se o espa�o ocupado do usu�rio n�o ser� ultrapassado
      ln_novo_espaco_ocupado := ln_usr_espaco_ocupado - ln_espaco_ocupado + in_espaco_ocupado;  -- Espa�o ocupado (total) pelo usu�rio

      if ((ln_novo_espaco_ocupado > in_max_espaco_ocupado) and (in_max_espaco_ocupado > 0)) then
         return(-3);  -- Espa�o ocupado m�ximo permitido ultrapassado
      end if;

      -- Atualiza o espa�o ocupado pelo usu�rio
      update trr_usr_flogs
         set espaco_ocupado = ln_novo_espaco_ocupado  -- Espa�o ocupado (total) pelo usu�rio
       where usrf_id = ln_usrf_id;

      -- Atualiza o flog do usu�rio	
      update trr_flogs
         set espaco_ocupado = espaco_ocupado - ln_espaco_ocupado + in_espaco_ocupado  -- Espa�o ocupado pelo flog
       where flog_id = ln_flog_id;
	  
   end if;

   -- Determina a atualiza��o da data de altera��o
   ld_dt_alteracao := null;
   
   if ((iv_titulo is not null) or (iv_texto is not null) or (iv_arquivo is not null)) then
      ld_dt_alteracao := sysdate;
   end if; 
   
   -- Atualiza o post
   update trr_posts
      set titulo         = nvl(substr(iv_titulo, 1, 100), titulo),
	      texto          = nvl(substr(iv_texto, 1, 4000), texto),
		  arquivo        = nvl(iv_arquivo, arquivo),
		  espaco_ocupado = nvl(in_espaco_ocupado, espaco_ocupado),
		  d_aprovado     = nvl(ic_d_aprovado, d_aprovado),
		  d_habilitado   = nvl(ic_d_habilitado, d_habilitado),
		  dt_alteracao   = decode(ld_dt_alteracao, null, dt_alteracao, ld_dt_alteracao)
    where post_id = in_post_id;
	
   commit;
   
   return(0);	   

exception

   when DUP_VAL_ON_INDEX then
      begin
         rollback;
         return(-4); -- Chave �nica duplicada (arquivo)
      end;
   
end trr_fnc_altera_post;
/