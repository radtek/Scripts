
ACCEPT sidi PROMPT 'SID:'

col value for 9999999999999;
select a.name,b.value
from v$statname a, v$sesstat b
where a.STATISTIC#= b.STATISTIC#
  and b.sid = &sidi
  and (a.name like '%pga%' or a.name like '%uga%')
ORDER BY A.NAME
/
