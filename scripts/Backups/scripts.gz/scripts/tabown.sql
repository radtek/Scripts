undef dono;
select table_name, tablespace_name, num_rows, last_analyzed, iot_type
from dba_tables
where owner = upper('&dono')
order by num_rows
/


