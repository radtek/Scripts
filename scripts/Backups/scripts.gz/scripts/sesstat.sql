accept sidi prompt 'Sid:'
accept stat prompt 'Stat:'
set ver off;
select a.name,b.value
from v$statname a, v$sesstat b
where a.STATISTIC# = b.STATISTIC#
  and (b.sid = &sidi or &sidi is null)
  and (a.name like '%&stat%' or '&stat' is null)
/
