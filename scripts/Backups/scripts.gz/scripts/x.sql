set echo on
set timing on
set time on
spool x.log
conn  suat/tcdpp6

alter session set db_file_multiblock_read_count=256;
alter session set sort_area_size=50000000;


create table suat.TMP_CONTAS_COB_EXPFATCOB tablespace suat_tmp_data Nologging as
SELECT /*+ ORDERED USE_HASH (PRIO COCO POP CONT ALIA COSE PASE LISE SERV CLSE CONV INCO) */
		pop.cd_pop
		, coco.cd_contrato_cobranca
		, alia.de_username
		, inco.de_nome
		, serv.cd_servico
		, TRUNC (coco.dt_cadastro) dt_aquisicao
		, conv.nm_convenio_abrev
   FROM (
		SELECT  /*+ No_Merge Ordered use_hash(temp coco cose pase lise serv clse) */
				coco.id_contrato_cobranca
		       ,cose.id_conta
		       ,max(clse.nr_prioridade) max_prioridade
		from     TMP_CONTRATO_COB_EXPFATCOB    temp,
		         trr_contrato_cobranca         coco,
		            trr_contrato_servico          cose,
		            trr_pacotecomerc_servico      pase,
		        trr_linhanegocio_servico      lise,
		        trr_servico                   serv,
		        trr_classe_servico            clse
		where    coco.cd_contrato_cobranca     = temp.cd_contrato_cobranca
		  and    cose.id_contrato_cobranca     = coco.id_contrato_cobranca
		  and   (cose.dt_validade             IS NULL
		    OR    cose.dt_validade             >= to_date('01/02/2006','dd/mm/rrrr') + 20 - 1
		         )
		   AND ( cose.dt_cancel 		IS NULL
		           OR (cose.dt_cancel BETWEEN ADD_MONTHS (to_date('01/02/2006','dd/mm/rrrr') + 20, -1)
		         						 AND to_date('01/02/2006','dd/mm/rrrr')+ 20 - 1
		        	  AND cose.bl_cancel_cobranca = 'S'
		         	 )
		       	)
		  and    pase.id_pacote_comercial      = cose.id_pacote_comercial
		  and    lise.id_linhanegocio_servico  = pase.id_linhanegocio_servico
		  and    serv.id_servico               = lise.id_servico
		  and    clse.id_classe_servico        = serv.id_classe_servico
		GROUP BY coco.id_contrato_cobranca
		       ,cose.id_conta)  Prio,
		trr_contrato_cobranca coco,
   		trr_pop pop,
		trr_contrato_servico cose,
		trr_pacotecomerc_servico pase,
		trr_linhanegocio_servico lise,
		trr_servico serv,
		trr_classe_servico clse,
		trr_conta cont,
		trr_alias alia,
		trr_convenio conv,
		trr_informacao_cobranca inco
  WHERE pop.id_pop = coco.id_pop
	AND cont.id_contrato_cobranca = coco.id_contrato_cobranca
	AND cont.id_alias_principal = alia.id_alias
	AND cose.id_contrato_cobranca = coco.id_contrato_cobranca
	AND cose.id_conta = cont.id_conta
	AND cose.id_pacote_comercial = pase.id_pacote_comercial
	AND pase.id_linhanegocio_servico = lise.id_linhanegocio_servico
	AND lise.id_servico = serv.id_servico
	AND serv.id_classe_servico = clse.id_classe_servico
	AND conv.id_convenio = cose.id_convenio
	AND coco.id_informacao_cobranca = inco.id_informacao_cobranca
	AND coco.id_contrato_cobranca = prio.id_contrato_cobranca
	and cose.id_conta			  = prio.id_conta
	and clse.nr_prioridade		  = prio.max_prioridade
	and   (cose.dt_validade             IS NULL
	  OR    cose.dt_validade             >= to_date('01/02/2006','dd/mm/rrrr') + 20 - 1
	       )
	 AND ( cose.dt_cancel 		IS NULL
	         OR (cose.dt_cancel BETWEEN ADD_MONTHS (to_date('01/02/2006','dd/mm/rrrr') + 20, -1)
	       						 AND to_date('01/02/2006','dd/mm/rrrr')+ 20 - 1
	      	  AND cose.bl_cancel_cobranca = 'S'
	       	 )
	     	)
/


spool off;
exit;

