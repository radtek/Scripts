undef own;
exec dbms_utility.compile_schema(upper('&own'));

