accept ban prompt 'Banco:'
conn perfstat/perfstat@&ban
set sqlprompt '&ban-perf>'
