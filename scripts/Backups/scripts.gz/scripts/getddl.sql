accept sch prompt 'Owner......:'
accept typ prompt 'Object_type:'
accept nam Prompt 'Object_name:'
set long 200000;
select dbms_metadata.get_ddl (upper('&typ'),  upper('&nam'), upper('&sch'))
  from dual;

