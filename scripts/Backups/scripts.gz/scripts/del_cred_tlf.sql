spool del_cred_tlf.log
set timing on
set echo on
set serveroutput on size 1000000

alter session set sort_area_size=30000000;
-- alter session set hash_multiblock_io_count=16;
-- alter session set db_file_multiblock_read_count=16;
-- alter session set sort_multiblock_read_count=16;


-- Script para inicializa��o dos cr�ditos de usu�rios
--
declare
	cursor c_usr(p_srv_id in number,
					 p_eve_id in number,
					 p_oper_id in number) is
		select /*+ use_hash(uassi uscd con ucred) full(uassi) */
              uassi.snh_id,
		        con.con_id
		from ciut.trr_usr_assinantes uassi,
			  cred_debit.trr_usr_creddeb uscd,
			  cred_debit.trr_contas con,
			  cred_debit.trr_uso_creditos ucred
		where uassi.snh_id = uscd.snh_id
		and	con.uscd_id = uscd.uscd_id
		and	ucred.con_id = con.con_id
		and	con.d_status_conta = 'A'
		and	uscd.snh_id is not null
		and	uassi.oper_id = p_oper_id
		and	ucred.srv_id = p_srv_id
		and	ucred.eve_id = p_eve_id;

    ln_srv_id				number;
    ln_eve_id 				number;
    v_lines_to_commit 	number := 5000;
    ln_count 				number := 0;
    lv_exit 				varchar2(1) := null;
    ln_num_procs			number := 0;
    ln_num_snapshots		number := 0;
    ln_oper_id number;

begin
	select srv_id
	into ln_srv_id
	from bd_central.trr_servicos
	where servico = 'SMS';
	
	select eve_id
	into ln_eve_id
	from cred_debit.trr_eventos
	where srv_id = ln_srv_id
	and	evento = 'credito_sms';
	
	select oper_id
	into ln_oper_id
	from ciut.trr_operadoras
	where sigla = 'TLF';
	
	-- Esse loop foi incluido apenas para tratar os poss�veis ORA-1555 (SNAPSHOT TOO OLD).
	lv_exit := 'N';
	loop
		exit when lv_exit = 'S';
		begin
			for c_usr_rec in c_usr (ln_srv_id, ln_eve_id, ln_oper_id)
			loop
				update cred_debit.trr_contas
				  set d_status_conta = 'I'
				where con_id = c_usr_rec.con_id;

				delete from bd_central.trr_userprodutos
				where snh_id = c_usr_rec.snh_id
				and	d_produto = 'SMS';

				if (ln_count = v_lines_to_commit) then
					commit;
					ln_count := 0;
				else
					ln_count := ln_count + 1;
				end if;
				ln_num_procs := ln_num_procs + 1;
			end loop;
			commit;
			lv_exit := 'S';
		exception when others then
			if (sqlcode = -1555) then -- snapshot too old
				lv_exit := 'N';
				ln_num_snapshots := ln_num_snapshots + 1;
				rollback;
			else
				rollback;
				raise;
			end if;
		end;
	end loop;
	dbms_output.put_line('Total de usu�rios processados = ' || ln_num_procs);
	dbms_output.put_line('Nro. de snapshots = ' || ln_num_snapshots);
end;
/

exit;
