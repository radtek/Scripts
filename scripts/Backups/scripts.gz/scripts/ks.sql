undef sidi;
undef serial;
alter system kill session '&sidi,&serial' immediate;

