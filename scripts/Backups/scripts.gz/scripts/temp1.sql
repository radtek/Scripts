BREAK ON report;
COMPUTE SUM OF KBYTES ON report;
---
SELECT  s.sid, s.username, u.tablespace, u.extents, 
       (u.blocks * (select value from v$parameter where name = 'db_block_size')) /1024 KBytes,
       (select sum(f.bytes) from dba_free_space f where f.tablespace_name = u.tablespace) /1024 KBytes_free_tbl
FROM v$session s, v$sort_usage u
WHERE s.saddr      = u.session_addr
order by s.sid
/

