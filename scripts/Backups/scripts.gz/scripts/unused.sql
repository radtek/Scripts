set serverout on 
set ver off

declare

	w1 number;
	w2 number;
	w3 number;
	w4 number;
	w5 number;
	w6 number;
	w7 number;

begin

     dbms_space.unused_space(upper('&&owner'),upper('&&segment_name'),upper('&&segment_type'),w1,w2,w3,w4,w5,w6,w7,
                             UPPER('&&PARTITION'));

     dbms_output.put_line('----------------------------------------------');
     dbms_output.put_line('Owner        : '||'&&owner');
     dbms_output.put_line('Segment_name : '||'&&segment_name');
     dbms_output.put_line('Segment_type : '||'&&segment_type');
     dbms_output.put_line('Parti��o     : '||'&&partition');

     dbms_output.put_line('----------------------------------------------');

     -- dbms_output.put_line('Total de blocks   : '||to_char(w1,'999,999,999,999,999,999'));
     dbms_output.put_line('Total de bytes    : '||to_char(w2,'999,999,999,999,999,999')||' - '||(w2/1024)/1024);
     dbms_output.put_line('Bytes nao usados  : '||to_char(w4,'999,999,999,999,999,999')||' - '||(w4/1024)/1024);
     dbms_output.put_line('----------------------------------------------');
     dbms_output.put_line('Bytes utilizados..: '||to_char(w2-w4,'999,999,999,999,999,999')||' - '||((w2-w4)/1024)/1024);

     dbms_output.put_line('----------------------------------------------');

end;

/


set serverout off
set ver on

undef owner
undef segment_name
undef segment_type
undef partition
