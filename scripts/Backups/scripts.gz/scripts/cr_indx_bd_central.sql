spool cr_indx_bd_central.log
set timing on
set echo on
alter session set  sort_area_size = 50000000;

create index bd_central.usr_nome_i on bd_central.trr_users (nome)
tablespace central_index
storage (initial 50m next 50m)
nologging
online;

alter index bd_central.usr_nome_i logging;

create index bd_central.usr_ciccgc_i on bd_central.trr_users (ciccgc)
tablespace central_index
storage (initial 50m next 50m)
nologging
online;

alter index bd_central.usr_ciccgc_i logging;

analyze index bd_central.usr_nome_i  compute statistics;
analyze index bd_central.usr_ciccgc_i  compute statistics;

exit;

