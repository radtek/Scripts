. /home/oracle/.bash_profile

cd /o01/app/oracle/oracledba/scripts

sqlplus suat/tcdpp6@oradb1 @update_contrato_cobranca_dsv3386.sql


