spool ana_almas.log
alter session set sort_area_size=100000000;
set echo on set timing on

analyze table "ALMASGEMEAS"."TRR_USR_ALMS"  compute statistics;

spool off;
exit;

