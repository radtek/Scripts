sqlplus suat/tcdpp6 <<eof
set echo on
set timing on
set time on

alter session set sort_area_size=50000000;


--> Recria a tabela que exporta as informacoes de contrato
drop table suat.TMP_CONTRATO_COB_EXPFATCOB;
create table suat.TMP_CONTRATO_COB_EXPFATCOB Nologging as
With Tmp_Contr_Serv_Ativos As
	(Select cose.id_contrato_cobranca,
			cose.id_pacote_comercial
	   from trr_contrato_servico cose
	  where ( cose.dt_validade 		IS NULL
           OR cose.dt_validade 		>= to_date('01/02/2006','dd/mm/rrrr') + 20 - 1
            )
   	    AND ( cose.dt_cancel 		IS NULL
           OR (cose.dt_cancel BETWEEN ADD_MONTHS (to_date('01/02/2006','dd/mm/rrrr') + 20, -1)
         						 AND to_date('01/02/2006','dd/mm/rrrr')+ 20 - 1
         	  AND cose.bl_cancel_cobranca = 'S'
         	 )
	     	)
	)
SELECT /*+ ORDERED USE_HASH( COCO ASSI CONT ALIA INCO MOCO VECO CIVE FOCO INCB COUNT_CRP SUST PECO TIVE VALOR) */
       'SUAT' nr_sistema,
	   coco.cd_contrato_cobranca,
       SUBSTR (TRIM (cont.nm_usuario), 1, 60) nm_usuario,
       CASE
          WHEN inco.tp_natureza = 'F'
             THEN 'PF'
          WHEN inco.tp_natureza = 'J'
             THEN 'PJ'
          ELSE inco.tp_natureza
       END tp_pessoa,
       inco.de_cpf_cnpj,
       CASE
          WHEN inco.tp_natureza = 'J' THEN
             assi.de_inscr_estadual
          WHEN inco.tp_natureza = 'F' THEN
             assi.de_rg
       END de_rg_ie,
       TO_CHAR (assi.dt_nascimento, 'dd/mm/yyyy') dt_nascimento
       ,
       CASE
          WHEN LENGTH (TRIM (   inco.de_endereco
                             || ' '
                             || inco.de_numero
                             || ' '
                             || inco.de_complemento
                            )
                      ) <= 60
             THEN TRIM (   inco.de_endereco
                        || ' '
                        || inco.de_numero
                        || ' '
                        || inco.de_complemento
                       )
          ELSE    SUBSTR (TRIM (inco.de_endereco),
                          1,
                            LENGTH (TRIM (inco.de_endereco))
                          + 60
                          - LENGTH (TRIM (   inco.de_endereco
                                          || ' '
                                          || inco.de_numero
                                          || ' '
                                          || inco.de_complemento
                                         )
                                   )
                         )
               || ' '
               || inco.de_numero
               || ' '
               || inco.de_complemento
       END ds_enderecocobr,
       inco.de_bairro,
	   inco.de_cidade,
	   inco.de_uf,
	   inco.de_cep,
       SUBSTR (TRIM (inco.de_ddd) || TRIM (inco.de_telefone),
               1,
               20
              ) nr_fonecobr,
       moco.cd_modalidade_cobranca,
       veco.nr_dia_vencimento nr_vencimentotitulo,
       CASE
          WHEN foco.tp_forma_cobranca = 'C'
             THEN SUBSTR (coco.de_cartao_credito,
                          1,
                          20
                         )
          WHEN foco.tp_forma_cobranca = 'D'
             THEN coco.de_conta_corrente
       END nr_contacorr_cartaocreg,
       CASE
          WHEN foco.tp_forma_cobranca = 'C'
             THEN TO_CHAR (coco.dt_cartao_credito,
                           'mm/yy'
                          )
          WHEN foco.tp_forma_cobranca = 'D'
             THEN coco.de_agencia
       END nr_agencia_venccart,
       incb.nr_banco,
	   TO_CHAR (coco.dt_cadastro, 'dd/mm/yyyy') dt_cadastro,
	   0 v1,0 v2,0 v3,
       pop.cd_pop sg_pop,
	   coco.bl_emite_nota bl_emitenf,
       dnlo.cd_chave_local_cep nr_ect
       ,
       CASE
          WHEN LENGTH (TRIM (   assi.de_endereco
                             || ' '
                             || assi.de_numero
                             || ' '
                             || assi.de_complemento
                            )
                      ) <= 60
             THEN TRIM (   assi.de_endereco
                        || ' '
                        || assi.de_numero
                        || ' '
                        || assi.de_complemento
                       )
          ELSE    SUBSTR (assi.de_endereco,
                          1,
                            LENGTH (assi.de_endereco)
                          + 60
                          - LENGTH (TRIM (   assi.de_endereco
                                          || ' '
                                          || assi.de_numero
                                          || ' '
                                          || assi.de_complemento
                                         )
                                   )
                         )
               || ' '
               || assi.de_numero
               || ' '
               || assi.de_complemento
       END ds_enderecores,
       assi.de_bairro bairro_res,
	   assi.de_cidade cidade_res,
       assi.de_uf sg_estado_res,
	   assi.de_cep nr_cepres,
       SUBSTR (TRIM (cont.de_ddd_res) || TRIM (cont.de_telefone_res),
               1,
               20
              ) nr_foneres,
       cont.de_ddd_cel || cont.de_telefone_cel nr_fonecelular,
       sust.cd_submotivo_status status,
       TRUNC (cont.dt_submotivo_status) dt_desligamento,
       coco.cd_contrato_cobranca nr_cliente,
       SUBSTR (TRIM (cont.de_ddd_com) || TRIM (cont.de_telefone_com),
               1,
               20
              ) nr_fonecom,
       alia.de_username nr_contaacessopai, ' ' ds_contato,
       CASE
          WHEN tive.cd_tipo_venda = 'ONLINE'
             THEN 1
          ELSE 2
       END nr_origemmodcob, peco.cd_perfil_comercial sg_perfil,
       CASE
          WHEN count_crp.num IS NULL
             THEN 'IND'
          ELSE 'CRP'
       END tp_contrato
  FROM trr_contrato_cobranca coco,
	   trr_pop	 pop,
       trr_cidade cida,
       trr_dne_localidade dnlo,
       trr_modalidade_cobranca moco,
       trr_perfil_comercial peco,
       trr_ciclobilling_vencimento cive,
       trr_vencimento_cobranca veco,
       trr_instituicao_cobranca incb,
       trr_forma_cobranca foco,
       trr_tipo_venda tive,
       trr_informacao_cobranca inco,
       trr_assinante assi,
       trr_conta cont,
       trr_submotivo_status sust,
       trr_alias alia,
       (  SELECT /*+ NO_MERGE USE_HASH (SERV LISE PASE COCO COSE PACO) */
                 coco.id_contrato_cobranca, paco.cd_pacote_comercial, paco.vl_monetario, COUNT (*) num
            FROM trr_servico serv,
                 trr_linhanegocio_servico lise,
                 trr_pacotecomerc_servico pase,
                 trr_contrato_cobranca coco,
                 Tmp_Contr_Serv_Ativos cose,
                 trr_pacote_comercial paco
           WHERE serv.cd_servico 				= 'CRP'
             AND serv.id_servico 				= lise.id_servico
             AND lise.id_linhanegocio_servico 	= pase.id_linhanegocio_servico
             AND pase.id_pacote_comercial 		= paco.id_pacote_comercial
             AND cose.id_pacote_comercial 		= paco.id_pacote_comercial
             AND cose.id_contrato_cobranca 		= coco.id_contrato_cobranca
        GROUP BY coco.id_contrato_cobranca,
                 paco.cd_pacote_comercial,
                 paco.vl_monetario) count_crp
 WHERE pop.id_pop 							= coco.id_pop
   AND pop.id_cidade 						= cida.id_cidade
   AND cida.id_localidade 					= dnlo.id_localidade
   AND Assi.id_linha_negocio 				= 6
   AND coco.id_assinante 					= assi.id_assinante
   AND count_crp.id_contrato_cobranca(+) 	= coco.id_contrato_cobranca
   AND coco.id_informacao_cobranca 			= inco.id_informacao_cobranca
   AND coco.id_modalidade_cobranca 			= moco.id_modalidade_cobranca
   AND coco.id_perfil_comercial 			= peco.id_perfil_comercial
   AND coco.id_ciclobilling_venciment 		= cive.id_ciclobilling_vencimento
   AND cive.id_vencimento_cobranca 			= veco.id_vencimento_cobranca
   AND incb.id_instituicao_cobranca 		= moco.id_instituicao_cobranca
   AND coco.id_assinante 					= inco.id_assinante
   AND coco.id_conta_adm 					= cont.id_conta
   AND foco.id_forma_cobranca 				= moco.id_forma_cobranca
   AND cont.id_alias_principal 				= alia.id_alias
   AND cont.id_submotivo_status 			= sust.id_submotivo_status
   AND coco.id_tipo_venda 					= tive.id_tipo_venda
   AND coco.id_contrato_cobranca			in (Select cose.id_contrato_cobranca
												  from Tmp_Contr_Serv_Ativos cose)
/

grant select on suat.TMP_CONTRATO_COB_EXPFATCOB  to selsuat;

--> Recria a tabela que export as informacoes de Conta
drop table TMP_CONTAS_COB_EXPFATCOB;
create table TMP_CONTAS_COB_EXPFATCOB tablespace suat_tmp_data Nologging as
SELECT /*+ ORDERED USE_HASH (PRIO COCO POP CONT ALIA COSE PASE LISE SERV CLSE cpscnv INCO) */
  pop.cd_pop
  , coco.cd_contrato_cobranca
  , alia.de_username
  , inco.de_nome
  , Min(serv.cd_servico) Cd_servico
  , TRUNC (coco.dt_cadastro) dt_aquisicao
  , cpscnv.nm_convenio_abrev
  FROM ( SELECT /* No_Merge Ordered use_hash(temp coco cose pase lise serv clse) */
    coco.id_contrato_cobranca
    ,cose.id_conta
    ,max(clse.nr_prioridade) max_prioridade
     from TMP_CONTRATO_COB_EXPFATCOB temp,
    trr_contrato_cobranca coco,
    trr_contrato_servico cose,
    trr_pacotecomerc_servico pase,
    trr_linhanegocio_servico lise,
    trr_servico serv,
    trr_classe_servico clse
    where coco.cd_contrato_cobranca = temp.cd_contrato_cobranca
   and cose.id_contrato_cobranca = coco.id_contrato_cobranca
   and (cose.dt_validade IS NULL OR cose.dt_validade >= to_date('01/02/2006','dd/mm/rrrr') + 20 - 1 )
   AND ( cose.dt_cancel IS NULL  OR (cose.dt_cancel BETWEEN ADD_MONTHS (to_date('01/02/2006','dd/mm/rrrr') + 20, -1)
                 AND to_date('01/02/2006','dd/mm/rrrr')+ 20 - 1
              AND cose.bl_cancel_cobranca = 'S'
             )
    )
   and pase.id_pacote_comercial = cose.id_pacote_comercial
   and lise.id_linhanegocio_servico = pase.id_linhanegocio_servico
   and serv.id_servico = lise.id_servico
   and clse.id_classe_servico = serv.id_classe_servico
    GROUP BY coco.id_contrato_cobranca ,cose.id_conta) Prio,
  trr_contrato_cobranca coco,
  trr_pop pop,
  trr_contrato_servico cose,
  trr_pacotecomerc_servico pase,
  trr_linhanegocio_servico lise,
  trr_servico serv,
  trr_classe_servico clse,
  trr_conta cont,
  trr_alias alia,
  trr_informacao_cobranca inco,
  ( SELECT cpscnv.id_conta, cpscnv.nm_convenio_abrev
   FROM (SELECT /*+ No_merge use_hash(cps cnv) */
       cps.id_conta AS id_conta, cnv.nm_convenio_abrev AS nm_convenio_abrev,
       RANK () OVER (PARTITION BY cps.id_conta ORDER BY cps.dt_aquisicao, cnv.NM_CONVENIO_ABREV ASC) RANK
       FROM trr_contrato_servico cps, trr_convenio cnv
      WHERE cnv.id_convenio = cps.id_convenio) cpscnv
   WHERE cpscnv.RANK = 1
      GROUP BY cpscnv.id_conta, cpscnv.nm_convenio_abrev
  ) cpscnv
  WHERE pop.id_pop       = coco.id_pop
 AND cont.id_contrato_cobranca   = coco.id_contrato_cobranca
 and cpscnv.id_conta     = cont.id_conta
 AND cont.id_alias_principal   = alia.id_alias
 AND cose.id_contrato_cobranca   = coco.id_contrato_cobranca
 AND cose.id_conta      = cont.id_conta
 AND cose.id_pacote_comercial   = pase.id_pacote_comercial
 AND pase.id_linhanegocio_servico  = lise.id_linhanegocio_servico
 AND lise.id_servico     = serv.id_servico
 AND serv.id_classe_servico    = clse.id_classe_servico
 AND coco.id_informacao_cobranca  = inco.id_informacao_cobranca
 AND coco.id_contrato_cobranca   = prio.id_contrato_cobranca
 and cose.id_conta      = prio.id_conta
 and clse.nr_prioridade     = prio.max_prioridade
 and (cose.dt_validade IS NULL OR cose.dt_validade >= to_date('01/02/2006','dd/mm/rrrr') + 20 - 1)
 AND ( cose.dt_cancel  IS NULL OR (cose.dt_cancel BETWEEN ADD_MONTHS (to_date('01/02/2006','dd/mm/rrrr') + 20, -1)
               AND to_date('01/02/2006','dd/mm/rrrr')+ 20 - 1
            AND cose.bl_cancel_cobranca = 'S'
             )
  )
 GROUP BY pop.cd_pop
   , coco.cd_contrato_cobranca
   , alia.de_username
   , inco.de_nome
   , TRUNC (coco.dt_cadastro)
   , cpscnv.nm_convenio_abrev
/

grant select on TMP_CONTAS_COB_EXPFATCOB to selsuat;

spool off;
exit;
eof

sqlplus fatcobdesenv2/fatcobdesenv2@oradsv <<eof
drop table TMP_CONTRATO_COB_EXPFATCOB;
create table TMP_CONTRATO_COB_EXPFATCOB nologging as select * from suat.TMP_CONTRATO_COB_EXPFATCOB@suat;
Analyze table TMP_CONTRATO_COB_EXPFATCOB estimate statistics sample 10 percent;
-----
drop table TMP_CONTAS_COB_EXPFATCOB;
create table TMP_CONTAS_COB_EXPFATCOB nologging as Select * from suat.TMP_CONTAS_COB_EXPFATCOB@suat;
Analyze table TMP_CONTAS_COB_EXPFATCOB estimate statistics sample 10 percent;
----
exit;
eof

