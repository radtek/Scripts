select ROW_WAIT_OBJ#,          
ROW_WAIT_FILE#      ,   
ROW_WAIT_BLOCK#     ,   
ROW_WAIT_ROW#       
from v$session 
where sid = &sidi
/
   