col KSPPSTVL for a30;
select a.ksppinm,b.ksppstvl 
from x$ksppi a,x$ksppsv b 
where a.indx=b.indx 
and a.ksppinm like '%&par%' 
/
