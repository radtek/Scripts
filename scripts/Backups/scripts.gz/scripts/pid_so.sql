col usr_banco for a9;
col osuser for a9;
col machine for a12;
col program for a30 trunc;
undefine sidI;
select s.username usr_banco,s.osuser,s.machine,s.program,p.spid
from v$session s, v$process p
where s.sid=&sidI
and s.paddr=p.addr;


