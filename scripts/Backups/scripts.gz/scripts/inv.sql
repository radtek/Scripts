 undef own;
 SELECT 'ALTER '||DECODE(OBJECT_TYPE,'PACKAGE BODY','PACKAGE',OBJECT_TYPE)
        ||' '||OWNER||'.'||OBJECT_NAME||
        DECODE (OBJECT_TYPE,'PACKAGE BODY',' COMPILE BODY;' , ' COMPILE;')
 from dba_objects
 where status <>'VALID'
   and owner like upper('&own') ||'%'
 order by owner, object_type
/

