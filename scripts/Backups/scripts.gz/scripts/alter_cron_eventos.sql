set echo on;
set timing on;
spool alter_cron_eventos.log

whenever sqlerror exit 1;


alter session set sort_area_size=50000000;


create table meudinheiro.trr_cron_eventos_new as 
select * from meudinheiro.trr_cron_eventos where status <> '2';



alter table meudinheiro.trr_cron_eventos_new add
 CONSTRAINT "CEVT_PK_NEW" PRIMARY KEY("CEVT_ID") 
    USING INDEX  
    TABLESPACE "MEUDINHEIRO_INDEX" 
/

CREATE INDEX "MEUDINHEIRO"."PLAN_ID_I_NEW" 
    ON "MEUDINHEIRO"."TRR_CRON_EVENTOS_NEW"("PLAN_ID") 
    TABLESPACE "MEUDINHEIRO_INDEX"
/

analyze table meudinheiro.trr_cron_eventos_new  compute statistics;

rename trr_cron_eventos to trr_cron_eventos_old;
rename trr_cron_eventos_new to trr_cron_eventos;

CREATE OR REPLACE TRIGGER "MEUDINHEIRO"."TRR_TRG_CEVT" BEFORE
INSERT
OR UPDATE
OR DELETE ON "MEUDINHEIRO"."TRR_CRON_EVENTOS" 
    FOR EACH ROW BEGIN
   IF inserting THEN
      IF :new.cevt_id IS NULL THEN
      SELECT cevt_seq.NEXTVAL
         INTO :new.cevt_id
         FROM sys.dual;
      END IF;
   END IF;
END TRR_TRG_CEVT;
/

exec dbms_utility.compile_schema ('MEUDINHEIRO');


