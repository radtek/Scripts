col what for a50;
select job,log_user,what,to_char(next_date,'dd/mm/yyyy hh24:mi:ss') next_d,
       to_char(last_date,'dd/mm/yyyy hh24:mi:ss') last_d,interval,broken,nvl(failures,0) falhas
from dba_jobs
/
