conn bd_central/bd_central@oramig
set echo on
set timing on
set time on
spool stat_bdcentral_oramig.log

analyze table BD_CENTRAL.TRR_NICKNAMES estimate statistics sample 10 percent;
analyze table BD_CENTRAL.TRR_OBPV_USERS estimate statistics sample 10 percent;
analyze table BD_CENTRAL.TRR_OBP_VARS estimate statistics sample 10 percent;
analyze table BD_CENTRAL.TRR_OPEN_TMP estimate statistics sample 10 percent;
analyze table BD_CENTRAL.TRR_SENHAS estimate statistics sample 10 percent;
analyze table BD_CENTRAL.TRR_SENHAS_USERS estimate statistics sample 10 percent;
analyze table BD_CENTRAL.TRR_SERVICOS estimate statistics sample 10 percent;
analyze table BD_CENTRAL.TRR_UFS estimate statistics sample 10 percent;
analyze table BD_CENTRAL.TRR_USERPRODUTOS estimate statistics sample 10 percent;
analyze table BD_CENTRAL.TRR_USERS estimate statistics sample 10 percent;
analyze table BD_CENTRAL.TRR_VIS_MIGRADOS estimate statistics sample 10 percent;

Spool off;
exit;

