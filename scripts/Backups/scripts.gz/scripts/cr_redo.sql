ALTER DATABASE
    ADD LOGFILE GROUP 5 ('/o02/oradata/oradb1/redo05a.rdo','/o03/oradata/oradb1/redo05b.rdo') size 256m
/

