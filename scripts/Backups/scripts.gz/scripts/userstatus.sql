break on status;
compute sum of qtd on status;
select username, status, count(*) qtd
  from v$session 
group by username, status
order by status
/
