SPOOL CR_IND.LOG

select to_char(sysdate,'dd/mm/yyyy hh24:mi:ss') inicio from dual;

CREATE UNIQUE INDEX fatcobtre.ak_contrato_nrcontrato_i
   ON fatcobtre.trr_contrato (id_pop,nr_contrato)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.cliente_nocliente_i
   ON fatcobtre.trr_tmp_cliente (nr_cliente,no_cliente)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.cliente_nrcgccpf_i
   ON fatcobtre.trr_cliente (nr_cgccpf)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.cliente_nrfonecobr
   ON fatcobtre.trr_cliente (nr_fonecobr)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.cliente_uppernocliente_i
   ON fatcobtre.trr_cliente (no_cliente)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.contaacesso_uppernoconta_i
   ON fatcobtre.trr_contaacesso (no_conta)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.contaacesso_uppernrconta_i
   ON fatcobtre.trr_contaacesso (nr_conta)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.contrato_nrcontrato_i
   ON fatcobtre.trr_contrato (nr_contrato)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_agencia_idinstituicao_i
   ON fatcobtre.trr_agencia (id_instituicao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_bilhetehist_idbilhete_i
   ON fatcobtre.trr_bilhete_historico (id_bilhete)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_bilhetehist_idctaacesso_i
   ON fatcobtre.trr_bilhete_historico (id_contaacesso)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_bilhetehist_idplano_i
   ON fatcobtre.trr_bilhete_historico (id_plano)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_bilhetehist_idpop_i
   ON fatcobtre.trr_bilhete_historico (id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_bilhetehist_idprodcom_i
   ON fatcobtre.trr_bilhete_historico (id_produtocomercial)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_bilhete_idcontrato_i
   ON fatcobtre.trr_bilhete (id_contrato)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_bilhete_idpop_i
   ON fatcobtre.trr_bilhete (id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_bilhete_idprodcontab_i
   ON fatcobtre.trr_bilhete (id_produtocontabil)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_bilhete_idtitulo_i
   ON fatcobtre.trr_bilhete (id_titulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_boletimpagamento_idpop_i
   ON fatcobtre.trr_boletimpagamento (id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_capalinhaopcional_idcapa_i
   ON fatcobtre.trr_capalinhaopcional (id_capamodelo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_capamodeloarq_idinstmod_i
   ON fatcobtre.trr_capamodeloarquivo (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_capaocorrem_idinstmod_i
   ON fatcobtre.trr_capaocorrenciaremessa (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_capaocorrret_idinstmod_i
   ON fatcobtre.trr_capaocorrenciaretorno (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_cidadegerencial_idpop_i
   ON fatcobtre.trr_cidadegerencial (id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_cliente_idpop_i
   ON fatcobtre.trr_cliente (id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_contaacesso_idcontrato_i
   ON fatcobtre.trr_contaacesso (id_contrato)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_contaacesso_idpop_i
   ON fatcobtre.trr_contaacesso (id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_contacorrente_idagencia_i
   ON fatcobtre.trr_contacorrente (id_agencia)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_contrato_idcidade_i
   ON fatcobtre.trr_contrato (id_cidade)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_contrato_idcliente_i
   ON fatcobtre.trr_contrato (id_cliente)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_contrato_idctaacessopai_i
   ON fatcobtre.trr_contrato (id_contaacessopai)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_contrato_idinstmod_i
   ON fatcobtre.trr_contrato (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_contrato_idpop_i
   ON fatcobtre.trr_contrato (id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_contrato_idprior_i
   ON fatcobtre.trr_contrato (id_prioridade)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_contrato_sistema
   ON fatcobtre.trr_contrato (id_sistema)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_customodalidade_idinstmod_i
   ON fatcobtre.trr_customodalidade (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_customodalidade_idpop_i
   ON fatcobtre.trr_customodalidade (id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_filialcontabil_idregional_i
   ON fatcobtre.trr_filialcontabil (id_regional)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_filialproduto_idfilial_i
   ON fatcobtre.trr_filial_produto (id_filial)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_filialproduto_idprodctab_i
   ON fatcobtre.trr_filial_produto (id_produtocontabil)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_instmodcobra_idcontacorr_i
   ON fatcobtre.trr_instituicao_modcobranca (id_contacorrente)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_instmodcobra_idinst_i
   ON fatcobtre.trr_instituicao_modcobranca (id_instituicao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_instmodcobra_idmodal_i
   ON fatcobtre.trr_instituicao_modcobranca (id_modalidade)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_instmodcob_idinstmodcompl_i
   ON fatcobtre.trr_instituicao_modcobranca (id_instituicaomod_compl)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_instmodpop_idinstmod_i
   ON fatcobtre.trr_instituicao_mod_pop (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_instmodpop_idpop_i
   ON fatcobtre.trr_instituicao_mod_pop (id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_lanctocontab_idcaplancto_i
   ON fatcobtre.trr_lancamentocontabil (id_capalancamento)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_lanctocontab_idmovto_i
   ON fatcobtre.trr_lancamentocontabil (id_movimento)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_lanctocontab_idprodcont_i
   ON fatcobtre.trr_lancamentocontabil (id_produtocontabil)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_logbloqueio_idcontrato_i
   ON fatcobtre.trr_logbloqueio (id_contrato)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_logfaturamento_idinstmod_i
   ON fatcobtre.trr_logfaturamento (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_logoperacao_idtabela_i
   ON fatcobtre.trr_logoperacao (id_tabela)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_logtransacao_idtptrans_i
   ON fatcobtre.trr_logtransacao (id_tipotransacao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_logtranserro_idlogtrans_i
   ON fatcobtre.trr_logtransacaoerro (id_logtransacao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_logtranserro_idtitulo_i
   ON fatcobtre.trr_logtransacaoerro (id_titulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_logtranserro_idtperro_i
   ON fatcobtre.trr_logtransacaoerro (id_tipoerro)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_modeloarquivo_idcampo_i
   ON fatcobtre.trr_modeloarquivo (id_campo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_modeloarquivo_idcapamodel_i
   ON fatcobtre.trr_modeloarquivo (id_capamodelo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_movimento_idboletim_i
   ON fatcobtre.trr_movimento (id_boletim)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_movimento_idctacorr_i
   ON fatcobtre.trr_movimento (id_contacorrente)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_movimento_idinstituicao_i
   ON fatcobtre.trr_movimento (id_instituicao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_movimento_idinstmod_i
   ON fatcobtre.trr_movimento (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_movimento_idmovtovinc
   ON fatcobtre.trr_movimento (id_movimentovinc)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_movimento_idtitulo_i
   ON fatcobtre.trr_movimento (id_titulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_movimento_idtpmovto_i
   ON fatcobtre.trr_movimento (id_tipomovimento)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_notafiscalitem_idnota_i
   ON fatcobtre.trr_notafiscal_item (id_nota)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_notafiscalitem_prodcom_i
   ON fatcobtre.trr_notafiscal_item (id_produtocomercial)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_numeronotafiscal_idfilial_i
   ON fatcobtre.trr_numeronotafiscal (id_filial)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorbancorem_idinstmod_i
   ON fatcobtre.trr_ocorrenciabancoremessa (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorbancorem_idocorpadrem_i
   ON fatcobtre.trr_ocorrenciabancoremessa (id_ocorrenciapadraoremessa)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorrbancoret_idinstmod_i
   ON fatcobtre.trr_ocorrenciabancoretorno (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorrbancoret_idocopadret_i
   ON fatcobtre.trr_ocorrenciabancoretorno (id_ocorrenciapadraoretorno)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorremessa_idcaparem_i
   ON fatcobtre.trr_ocorrenciaremessa (id_caparemessa)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorremessa_idocorbancrem_i
   ON fatcobtre.trr_ocorrenciaremessa (id_ocorrenciabancoremessa)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorremessa_idtitulo_i
   ON fatcobtre.trr_ocorrenciaremessa (id_titulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorrencia_idcontrato_i
   ON fatcobtre.trr_ocorrencia (id_contrato)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorrencia_idtpocorr_i
   ON fatcobtre.trr_ocorrencia (id_tipoocorrencia)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorretorno_idcaparet_i
   ON fatcobtre.trr_ocorrenciaretorno (id_caparetorno)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorretorno_idocorbanret_i
   ON fatcobtre.trr_ocorrenciaretorno (id_ocorrenciabancoretorno)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorretorno_idtitulo_i
   ON fatcobtre.trr_ocorrenciaretorno (id_titulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_ocorrpadraoret_idsituatit_i
   ON fatcobtre.trr_ocorrenciapadraoretorno (id_situacaotitulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_paramcontab_idmodcobranca_i
   ON fatcobtre.trr_parametrocontabilizacao (id_modalidade)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_parametroctab_idprodctab_i
   ON fatcobtre.trr_parametrocontabilizacao (id_produtocontabil)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_parametroctab_idtpmovto_i
   ON fatcobtre.trr_parametrocontabilizacao (id_tipomovimento)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_pop_idfilialfat_i
   ON fatcobtre.trr_pop (id_filialfaturamento)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_pop_idgrupo_i
   ON fatcobtre.trr_pop (id_grupo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_prodcomercial_idprodcntab_i
   ON fatcobtre.trr_produtocomercial (id_produtocontabil)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_prodcontabpar_idprodcont_i
   ON fatcobtre.trr_produtocontabil_parametros (id_produtocontabil)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_regional_idregiao_i
   ON fatcobtre.trr_regional (id_regiao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_tarefaprogr_idcontrato_i
   ON fatcobtre.trr_tarefaprogramada (id_contrato)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_tarefaprogr_idinstmod_i
   ON fatcobtre.trr_tarefaprogramada (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_tarefaprogr_idtptarefa_i
   ON fatcobtre.trr_tarefaprogramada (id_tipotarefa)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_tipomovimento_idtpmovtoes_i
   ON fatcobtre.trr_tipomovimento (id_tipomovimentoestorno)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_tipomovimento_sittitulo_i
   ON fatcobtre.trr_tipomovimento (id_situacaotitulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_titulotarefaprog_idtarefa_i
   ON fatcobtre.trr_titulotarefaprogramada (id_tarefa)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_titulotarefaprog_idtitulo_i
   ON fatcobtre.trr_titulotarefaprogramada (id_titulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_titulo_idcontrato_i
   ON fatcobtre.trr_titulo (id_contrato)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_titulo_idinstmod_i
   ON fatcobtre.trr_titulo (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_titulo_idmotivo_i
   ON fatcobtre.trr_titulo (id_motivo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_titulo_idnota_i
   ON fatcobtre.trr_titulo (id_nota)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_titulo_idocorrret_i
   ON fatcobtre.trr_titulo (id_ocorrenciaretorno)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_titulo_idpop_i
   ON fatcobtre.trr_titulo (id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_titulo_idprodcont_i
   ON fatcobtre.trr_titulo (id_produtocontabil)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_titulo_idsitutitulo_i
   ON fatcobtre.trr_titulo (id_situacaotitulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.fk_tmptituloextrato_idtitulo_i
   ON fatcobtre.trr_tmp_titulo_extrato (id_titulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.i_lnotafiscali_sernnf
   ON fatcobtre.trr_tmp_load_notafiscal_item (nr_serie,nr_nota)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.i_lnotafiscal_sernnf
   ON fatcobtre.trr_tmp_load_notafiscal (nr_serie,nr_nota)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.i_planoacesso_prodcoml
   ON fatcobtre.trr_planoacesso (id_produtocomercial)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_agencia_i
   ON fatcobtre.trr_agencia (id_agencia)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_bilhete_historico_i
   ON fatcobtre.trr_bilhete_historico (id_historico)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_bilhete_i
   ON fatcobtre.trr_bilhete (id_bilhete)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_boletimpagamento_i
   ON fatcobtre.trr_boletimpagamento (id_boletim)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_campotabela_i
   ON fatcobtre.trr_campotabela (id_campo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_capalancamentocontabil_i
   ON fatcobtre.trr_capalancamentocontabil (id_capalancamento)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_capalinhaopcional
   ON fatcobtre.trr_capalinhaopcional (id_capalinhaopcional)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_capamodeloarquivo_i
   ON fatcobtre.trr_capamodeloarquivo (id_capamodelo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_capaocorrenciaremessa_i
   ON fatcobtre.trr_capaocorrenciaremessa (id_caparemessa)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_capaocorrenciaretorno_i
   ON fatcobtre.trr_capaocorrenciaretorno (id_caparetorno)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_ciclofaturamento_i
   ON fatcobtre.trr_ciclofaturamento (id_ciclo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_cidadegerencial_i
   ON fatcobtre.trr_cidadegerencial (id_cidade)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_cliente_i
   ON fatcobtre.trr_cliente (id_cliente)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_contaacesso_i
   ON fatcobtre.trr_contaacesso (id_contaacesso)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_contacorrente_i
   ON fatcobtre.trr_contacorrente (id_contacorrente)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_contrato_i
   ON fatcobtre.trr_contrato (id_contrato)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_customodalidade_i
   ON fatcobtre.trr_customodalidade (id_custo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_filialcontabil_i
   ON fatcobtre.trr_filialcontabil (id_filial)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_filial_produto_i
   ON fatcobtre.trr_filial_produto (id_filialproduto)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_grupotrabalho_i
   ON fatcobtre.trr_grupotrabalho (id_grupo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_instituicao_i
   ON fatcobtre.trr_instituicao (id_instituicao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_instituicao_modcobranca_i
   ON fatcobtre.trr_instituicao_modcobranca (id_instituicaomod)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_instituicao_mod_pop_i
   ON fatcobtre.trr_instituicao_mod_pop (id_instituicao_mod_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_lancamentocontabil_i
   ON fatcobtre.trr_lancamentocontabil (id_lancamento)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_logbloqueio
   ON fatcobtre.trr_logbloqueio (id_logbloqueio)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_logfaturamento
   ON fatcobtre.trr_logfaturamento (id_logfaturamento)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_logoperacao_i
   ON fatcobtre.trr_logoperacao (id_logoperacao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_logtransacaoerro_i
   ON fatcobtre.trr_logtransacaoerro (id_logtransacaoerro)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_logtransacao_i
   ON fatcobtre.trr_logtransacao (id_logtransacao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_modalidadecobranca_i
   ON fatcobtre.trr_modalidadecobranca (id_modalidade)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_modeloarquivo_i
   ON fatcobtre.trr_modeloarquivo (id_modelo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_motivo_i
   ON fatcobtre.trr_motivo (id_motivo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_movimento_i
   ON fatcobtre.trr_movimento (id_movimento)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_notafiscal_i
   ON fatcobtre.trr_notafiscal (id_nota)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_notafiscal_item_i
   ON fatcobtre.trr_notafiscal_item (id_notaitem)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_numeronotafiscal_i
   ON fatcobtre.trr_numeronotafiscal (id_numero)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_ocorrenciabancoremessa_i
   ON fatcobtre.trr_ocorrenciabancoremessa (id_ocorrenciabancoremessa)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_ocorrenciabancoretorno_i
   ON fatcobtre.trr_ocorrenciabancoretorno (id_ocorrenciabancoretorno)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_ocorrenciapadraoremessa_i
   ON fatcobtre.trr_ocorrenciapadraoremessa (id_ocorrenciapadraoremessa)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_ocorrenciapadraoretorno_i
   ON fatcobtre.trr_ocorrenciapadraoretorno (id_ocorrenciapadraoretorno)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_ocorrenciaremessa_i
   ON fatcobtre.trr_ocorrenciaremessa (id_ocorrenciaremessa)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_ocorrenciaretorno_i
   ON fatcobtre.trr_ocorrenciaretorno (id_ocorrenciaretorno)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_ocorrencia_i
   ON fatcobtre.trr_ocorrencia (id_ocorrencia)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_parametrocontabilizacao_i
   ON fatcobtre.trr_parametrocontabilizacao (id_parametro)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_parametrosistema_i
   ON fatcobtre.trr_parametrosistema (id_parametrosistema)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_planoacesso_i
   ON fatcobtre.trr_planoacesso (id_plano)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_pop
   ON fatcobtre.trr_pop (id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_prioridade_i
   ON fatcobtre.trr_prioridade (id_prioridade)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_prodcontabilpar_i
   ON fatcobtre.trr_produtocontabil_parametros (id_prod_parametro)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_produtocomercial_i
   ON fatcobtre.trr_produtocomercial (id_produtocomercial)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_produtocontabil_i
   ON fatcobtre.trr_produtocontabil (id_produtocontabil)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_regiao_i
   ON fatcobtre.trr_regiao (id_regiao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_regional_i
   ON fatcobtre.trr_regional (id_regional)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_saiter_i
   ON fatcobtre.trr_saiter (id_saiter)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_sistemaorigem_i
   ON fatcobtre.trr_sistemaorigem (id_sistema)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_situacaotitulo_i
   ON fatcobtre.trr_situacaotitulo (id_situacaotitulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_tabelasistema_i
   ON fatcobtre.trr_tabelasistema (id_tabela)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_tarefaprogramada_i
   ON fatcobtre.trr_tarefaprogramada (id_tarefa)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_tipoerro_i
   ON fatcobtre.trr_tipoerro (id_tipoerro)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_tipomovimento_i
   ON fatcobtre.trr_tipomovimento (id_tipomovimento)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_tipoocorrencia_i
   ON fatcobtre.trr_tipoocorrencia (id_tipoocorrencia)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_tipotarefa_i
   ON fatcobtre.trr_tipotarefa (id_tipotarefa)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_tipotransacao_i
   ON fatcobtre.trr_tipotransacao (id_tipotransacao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_titulotarefaprogramada_i
   ON fatcobtre.trr_titulotarefaprogramada (id_titulotarefa)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_titulo_i
   ON fatcobtre.trr_titulo (id_titulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_tmptituloextrato_i
   ON fatcobtre.trr_tmp_titulo_extrato (id_extrato)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_tmp_historicoimportacao_i
   ON fatcobtre.trr_tmp_historicoimportacao (id_tmp_historicoimportacao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.pk_vencimento_i
   ON fatcobtre.trr_vencimento (id_vencimento)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.planoacesso_nr_plano
   ON fatcobtre.trr_planoacesso (nr_plano)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.sys_c001858
   ON fatcobtre.trr_mensagem (id_mensagem)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 262144 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.titulo_contacorrente
   ON fatcobtre.trr_titulo (nr_banco,nr_agencia,nr_contacorrente)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.titulo_nrcartaocred
   ON fatcobtre.trr_titulo (nr_contacorrente)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.titulo_nrnossonumero
   ON fatcobtre.trr_titulo (nr_nossonumero)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.tmp_contaacesso_nr_conta
   ON fatcobtre.trr_tmp_contaacesso (nr_conta)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.tmp_fk_contaacesso_nr_conta
   ON fatcobtre.trr_tmp_fk_contaacesso (nr_conta)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.tmp_planoacesso_nr_plano
   ON fatcobtre.trr_tmp_planoacesso (nr_plano)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_bilhete_nrbilhpop
   ON fatcobtre.trr_bilhete (nr_bilhete,id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_capalinhaopcional
   ON fatcobtre.trr_capalinhaopcional (id_capamodelo,tp_secao,nr_linha)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_contrato_nrcontratoidpop
   ON fatcobtre.trr_contrato (nr_contrato,id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_cusmod_pop_ins_vig
   ON fatcobtre.trr_customodalidade (id_pop,id_instituicaomod,dt_inivigencia)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_instituicaomodpop_instmodpo
   ON fatcobtre.trr_instituicao_mod_pop (id_instituicaomod,id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_agencia_id_ins_nr_agenc
   ON fatcobtre.trr_agencia (id_instituicao,nr_agencia)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_ciclofaturamento_nr_cic
   ON fatcobtre.trr_ciclofaturamento (nr_ciclo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_cidadegerencial_nr_ect
   ON fatcobtre.trr_cidadegerencial (nr_ect)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE INDEX fatcobtre.uk_trr_cidadegerencial_sg_cida
   ON fatcobtre.trr_cidadegerencial (sg_cidade)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_contacorr_id_age_id_con
   ON fatcobtre.trr_contacorrente (id_agencia,id_contacorrente)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_filialcontabil_no_filia
   ON fatcobtre.trr_filialcontabil (no_filial)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_grupotrabalho_sg_grupo
   ON fatcobtre.trr_grupotrabalho (sg_grupo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_ins_modco_id_ins_id_mod
   ON fatcobtre.trr_instituicao_modcobranca (id_instituicao,id_modalidade)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_modalidadecobr_sg_modal
   ON fatcobtre.trr_modalidadecobranca (sg_modalidade)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_numnotfis_id_fil_nr_ser
   ON fatcobtre.trr_numeronotafiscal (id_filial,nr_serie)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_ocobanret_id_ins_nr_oco
   ON fatcobtre.trr_ocorrenciabancoretorno (id_instituicaomod,nr_ocorrencia)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_ocobrem_id_insmo_nr_oco
   ON fatcobtre.trr_ocorrenciabancoremessa (id_instituicaomod,nr_ocorrencia)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_parametrosistema_ds_nom
   ON fatcobtre.trr_parametrosistema (ds_nome)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_parcont_id_tipomoviment
   ON fatcobtre.trr_parametrocontabilizacao (id_tipomovimento,id_produtocontabil,id_modalidade)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_produtocontabil_nr_prod
   ON fatcobtre.trr_produtocontabil (nr_produto)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_regiao_sg_regiao
   ON fatcobtre.trr_regiao (sg_regiao)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_regional_sg_regional
   ON fatcobtre.trr_regional (sg_regional)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_sistemaorigem_nr_sistem
   ON fatcobtre.trr_sistemaorigem (nr_sistema)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_situacaotitulo_sg_situa
   ON fatcobtre.trr_situacaotitulo (sg_situacaotitulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_tipomovimento_tp_catego
   ON fatcobtre.trr_tipomovimento (tp_categoria)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.uk_trr_vencimento_nr_diavencim
   ON fatcobtre.trr_vencimento (nr_diavencimento)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.xak1trr_pop
   ON fatcobtre.trr_pop (sg_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.xpktrr_rel_primeiropagamento
   ON fatcobtre.trr_rel_primeiropagamento (no_login,id_titulo)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.xpktrr_tmp_cidadegerencial_ina
   ON fatcobtre.trr_tmp_cidadegerencial_inativ (id_cidade)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.xpktrr_tmp_contaacessol_inativ
   ON fatcobtre.trr_tmp_contaacessol_inativ (id_contaacesso)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.xpktrr_tmp_planoacesso_inativo
   ON fatcobtre.trr_tmp_planoacesso_inativo (id_plano)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.xpktrr_tmp_pop_inativo
   ON fatcobtre.trr_tmp_pop_inativo (id_pop)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.xpktrr_tmp_produtocomercial_in
   ON fatcobtre.trr_tmp_produtocomercial_inati (id_produtocomercial)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/

CREATE UNIQUE INDEX fatcobtre.xpktrr_tmp_produtocontabil_ina
   ON fatcobtre.trr_tmp_produtocontabil_inativ (id_produtocontabil)
PCTFREE 10
INITRANS 2 MAXTRANS 255
nologging tablespace fatcobtre_indx STORAGE (
INITIAL 131072 NEXT 131072
MINEXTENTS 1 MAXEXTENTS 2147483645 PCTINCREASE 0)
/


select to_char(sysdate,'dd/mm/yyyy hh24:mi:ss') final from dual;

SPOOL OFF;