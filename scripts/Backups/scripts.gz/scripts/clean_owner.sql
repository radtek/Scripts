accept own Prompt 'Owner:'
Select 'drop '||object_type||' '||owner||'.'||Object_name||decode(object_type,'TABLE',' CASCADE CONSTRAINTS;',';')
 FROM DBA_OBJECTS
WHERE OWNER =  UPPER('&OWN')
  AND OBJECT_TYPE NOT IN ('INDEX','INDEX PARTITION','PACKAGE BODY','TRIGGER', 'TABLE PARTITION')
ORDER BY OBJECT_TYPE;

