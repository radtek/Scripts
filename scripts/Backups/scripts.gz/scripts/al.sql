alter session set max_dump_file_size = unlimited;
alter session set sql_trace = true;
set serveroutput on;
set timing on;

