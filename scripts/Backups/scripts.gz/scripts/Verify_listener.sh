for i in 3 4
do
lsnrctl services listener$i >> listener.log
grep DEDICATED listener.log > dedicated.log
done
more dedicated.log
rm listener.log
