set echo on
set time on
spool cr_tables_iboxnet2.log
conn iboxnet/iboxnet

create table iboxnet.AUDIENCE Tablespace  IBOXNET_DATA nologging as
select * from iboxnet.AUDIENCE@orass1 where STARTDATE = TRUNC(SYSDATE) - 1
;

create table iboxnet.AUD_LIVES Tablespace IBOXNET_DATA  nologging as
select * from iboxnet.AUD_LIVES@orass1 WHERE STARTDATE = TRUNC(SYSDATE) - 1
;

create table iboxnet.AUD_MMEDIAS Tablespace IBOXNET_DATA  nologging as
select * from iboxnet.AUD_MMEDIAS@orass1 WHERE STARTDATE = TRUNC(SYSDATE) - 1
;

spool off;
exit;

