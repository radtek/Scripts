spool update_obps2.log
set timing on
set echo on
alter session set sort_area_size=30000000;

-- Script to insert new OBP variables.
--
declare
    --
    v_lines_to_commit       number := 1000;
    v_cont                  number := 0;
    v_exit                  varchar2(01) := null;
    --
    cursor assinantes_cur is
		select *
		from ajustabd.tabklaus;
--
begin
    --
    -- Esse loop foi incluido apenas para tratar os poss�veis ORA-1555 (SNAPSHOT TOO OLD).
    v_exit := 'N';
    loop
      exit when v_exit = 'S';
      begin
        --
        for C in assinantes_cur
        loop
		  --
			begin

				update bd_central.trr_obpv_users a
				set a.valor = C.valor
				where a.obpv_id = (select b.obpv_id
                			from bd_central.trr_obp_vars b
                			where substr(b.nome_gat, 5) = C.nomegat)
				and a.snh_id = (select x.snh_id
					from bd_central.trr_senhas x
					where x.cdom_id = 1
					and x.email = C.username);

			exception
				when others then
					raise;
			end;
			  --
			if (v_cont = v_lines_to_commit) then
				commit;
				v_cont := 0;
			else
				v_cont := v_cont + 1;
			end if;
        --
        end loop;
        --
        commit;
        v_exit := 'S';
      exception when others then
        if (sqlcode = -1555) then
           v_exit := 'N';
		   rollback;
        else
		   rollback;
           raise;
        end if;
      end;
    end loop;
end;
/
exit;
