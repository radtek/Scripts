sqlldr ajustabd/ajustabd control=obps.ctl
