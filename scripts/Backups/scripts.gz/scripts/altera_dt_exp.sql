spool altera_dt_exp.log
set timing on
set echo on
set serveroutput on size 100000
-- alter session set sort_area_size=30000000;
-- alter session set hash_multiblock_io_count=16;
-- alter session set db_file_multiblock_read_count=16;
-- alter session set sort_multiblock_read_count=16;


-- Script para inicializa��o dos cr�ditos de usu�rios
--
declare
	cursor c_scon is
		select scon.scon_id
		from cred_debit.trr_saldos_contas scon
		where scon.d_recarga_auto = 'N';

    v_lines_to_commit 	number := 5000;
    ln_count 				number := 0;
    lv_exit 				varchar2(1) := null;
    ln_ora_2291			number := 0;
    ln_ret					number;
    ln_num_ok				number := 0;
    ld_data_expiracao	date := to_date('30/06/2014', 'dd/mm/yyyy');

begin
	/* Esse loop foi incluido apenas para tratar os poss�veis 
	   ORA-1555 (SNAPSHOT TOO OLD).
	 */
	lv_exit := 'N';
	loop
		exit when lv_exit = 'S';
		begin
			ln_ora_2291 := 0;
			for c_scon_rec in c_scon
			loop
				begin
					update cred_debit.trr_saldos_contas scon
					set scon.dt_expiracao = ld_data_expiracao
					where scon.scon_id = c_scon_rec.scon_id;
					
					ln_num_ok := ln_num_ok + 1;

				exception
					when others then
						if (sqlcode = -2291) then -- parent key not found
							ln_ora_2291 := ln_ora_2291 + 1;
							rollback;
						else
							raise;
						end if;
				end;

				if (ln_count = v_lines_to_commit) then
					commit;
					ln_count := 0;
				else
					ln_count := ln_count + 1;
				end if;
			end loop;

			commit;
			
			if ln_ora_2291 = 0 then
				lv_exit := 'S';
			else
				dbms_output.put_line('erro ora_2291 [' || ln_ora_2291 || ']');
			end if;

		exception when others then
			if (sqlcode = -1555) then -- snapshot too old
				lv_exit := 'N';
				rollback;
			else
				rollback;
				raise;
			end if;
		end;
	end loop;
	dbms_output.put_line('Total de usu�rios OK = ' || ln_num_ok);
end;
/
--spool off
exit;
