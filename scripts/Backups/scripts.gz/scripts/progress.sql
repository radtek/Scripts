col message for a150
select s.sid,s.username,l.start_time,l.time_remaining remaining,l.elapsed_seconds Elapsed,
       round((sofar/totalwork)*100,2) "%done",l.message
from v$session s, v$session_longops l
where s.sid = l.sid and
      s.status = 'ACTIVE' and
      (sofar/totalwork) < 1 and
      totalwork > 0
order by s.username
/


