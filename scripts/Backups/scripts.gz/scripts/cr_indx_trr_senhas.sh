sqlplus bd_central/swde67 <<eof
spool /tmp/cr_indx_trr_senhas.log
set lines 80
set echo on
set timing on
alter session set sort_area_size = 100000000;

select to_char(sysdate,'dd/mm/yyyy hh24:mi:ss') Inicio from dual;


create index idx_email_def_cdom_id on trr_senhas
(EMAIL_DEFAULT,
 CDOM_ID)
local
online
tablespace CENTRAL_INDEX
storage (initial 50m next 10m)
/

analyze index idx_email_def_cdom_id compute statistics;

select to_char(sysdate,'dd/mm/yyyy hh24:mi:ss') final from dual;

exit;
eof 

