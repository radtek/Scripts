col name for a30;
col lmode for a4;
col request for a4;
col username for a20;
select a.sid,b.username,a.type,d.name||'.'||c.name name,a.id1,a.id2,
       decode(lmode,1,'null',2,'RS',3,'RX',4,'S',5,'SRX',6,'X',0,'NONE',lmode) lmode,
       decode(request,1,'null',2,'RS',3,'RX',4,'S',5,'SRX',6,'X',0,'NONE',request) request,
       'Locando' A��O
 from v$lock a,v$session b,sys.obj$ c,sys.user$ d
where a.id1 = c.OBJ# (+)
  and a.sid = b.sid
  and c.owner# = d.user# (+)
  and b.username is not null
  and a.lmode = 6
  and (a.id1,a.id2) in (select id1,id2 from v$lock where request <> 0)      
union all
select a.sid,b.username,a.type,d.name||'.'||c.name name,a.id1,a.id2,
       decode(lmode,1,'null',2,'RS',3,'RX',4,'S',5,'SRX',6,'X',0,'NONE',lmode) lmode,
       decode(request,1,'null',2,'RS',3,'RX',4,'S',5,'SRX',6,'X',0,'NONE',request) request,
       'locado' A��O
 from v$lock a,v$session b,sys.obj$ c,sys.user$ d
where a.id1 = c.OBJ# (+)
  and a.sid = b.sid
  and c.owner# = d.user# (+)
  and b.username is not null
  and a.request <> 0
order by 5,6
/
