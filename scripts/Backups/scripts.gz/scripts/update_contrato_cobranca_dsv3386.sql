spool update_contrato_cobranca_dsv3386.log
set echo on
set timing on
set time on
set serveroutput on;
declare
  lv_count integer := 0;
begin
	--Seleciona os que estãcom a linha de negó incorreta
	for reg in (SELECT ASSI.ID_LINHA_NEGOCIO linha_certa
					  ,COCO.id_contrato_cobranca
					  ,TIVE.cd_tipo_venda
					  ,TIVE.id_linha_negocio linha_errada
					  ,CERTA.ID_TIPO_VENDA ID_TIPO_VENDA_CERTA
				 FROM TRR_ASSINANTE ASSI
				     ,TRR_CONTRATO_COBRANCA COCO
				     ,TRR_TIPO_VENDA TIVE
					 ,TRR_TIPO_VENDA CERTA
				WHERE ASSI.id_assinante 	= COCO.id_assinante
				  AND COCO.id_tipo_venda 	= TIVE.id_tipo_venda
				  AND assi.id_linha_negocio <> tive.id_linha_negocio
				  AND tive.cd_tipo_venda	= certa.cd_tipo_venda
				  AND ASSI.ID_LINHA_NEGOCIO = certa.id_linha_negocio
				)
	loop
		---
		update trr_contrato_cobranca
		   set id_tipo_venda = reg.ID_TIPO_VENDA_CERTA
		 where id_contrato_cobranca = reg.id_contrato_cobranca;
		---
		lv_count := lv_count + 1;
		if (mod(lv_count,10000) = 0) Then
		   commit;
		end if;
		---
	end loop;
	----
	commit;
	dbms_output.put_line ('Nro de updates:'||lv_count);
	----
end;
/

spool off;
exit;

