select tablespace_name, owner, bytes from dba_SEGMENTS where segment_type = 'TEMPORARY'
/
