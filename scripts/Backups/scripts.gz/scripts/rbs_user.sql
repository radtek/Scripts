select r.name rname,rs.extents,u.username,u.machine,
       u.sid, t.used_ublk,t.start_uext,
       t.log_io,t.phy_io,t.used_urec,t.start_time
from v$rollname r     ,
     v$session u     ,
     v$transaction t     ,
     v$rollstat rs
where r.usn=t.xidusn(+)
  and u.taddr(+)=t.addr
  and rs.usn=r.usn
order by r.name
/
