exec sys.dbms_logmnr.START_LOGMNR ( options => sys.dbms_logmnr.DICT_FROM_ONLINE_CATALOG);

