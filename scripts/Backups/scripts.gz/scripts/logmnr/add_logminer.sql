exec sys.dbms_logmnr.add_logfile ('/o02/oradata/oradb1/archive/ORADB1_0000004174.ARC');
exec sys.dbms_logmnr.add_logfile ('/o02/oradata/oradb1/archive/ORADB1_0000004175.ARC');
exec sys.dbms_logmnr.add_logfile ('/o02/oradata/oradb1/archive/ORADB1_0000004176.ARC');

