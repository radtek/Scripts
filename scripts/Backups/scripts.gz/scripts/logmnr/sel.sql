col seg_owner for a30;
col seg_name for a30;
col sql_redo for a100;
col sql_undo for a100;

set lines 200;
set pages 200;

spool sel.log
alter session set nls_date_format = 'dd/mm/yyyy hh24:mi:ss';
create table system.restore_antispan tablespace tools as (
select TIMESTAMP,  
       SEG_OWNER,      
       SEG_NAME ,
       SQL_REDO ,      
       SQL_UNDO         
  from v$logmnr_contents
 where OPERATION = 'DELETE'
--   and seg_owner in ('CIUT','BD_CENTRAL')
--   and seg_name  in ('TRR_SENHAS','TRR_USR_ASSINANTES','TRR_REMETENTES','TRR_LISTA_REMETENTES','TRR_EMP_ATRIBUTOS')
)
/

select * from system.restore_antispan  order by timestamp;

spool off;
 
