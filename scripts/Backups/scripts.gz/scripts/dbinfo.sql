select a.INSTANCE_NAME, b.name DbName, a.HOST_NAME, a.VERSION, a.STARTUP_TIME,b.CREATED,b.LOG_MODE,b.OPEN_MODE
 from v$instance a, v$database b
 /
Select * from v$version;

