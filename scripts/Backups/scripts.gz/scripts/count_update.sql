set timing on
set echo on
spool count_update.log
select count(*) 
  from bd_central.trr_obpv_users new
 where exists (select 1
                 from ciut.trr_usr_assinantes a 
                where a.snh_id =  new.snh_id
                  and a.quota  <> new.valor)
   and new.obpv_id = (select obpv_id
                        from bd_central.trr_obp_vars
                       where nome = 'quota_caixa')
/
exit;

