undef sidi;

col program for a60
select b.spid,a.sid,a.serial#,a.username,a.osuser,a.machine,a.program,a.status,a.logon_time, a.last_call_et, a.server, a.sql_hash_value, c.event
from v$session a,v$process b, v$session_wait c
where a.paddr = b.addr
  and a.sid   = c.sid
  and a.sid   = &sidi
/


