spool migra_suat_contrato_servico_dir_adquirido.log
set echo on
set timing on
set time on
conn suat/tcdpp6

alter session set sort_area_size=100000000;

insert /*+ APPEND */ all
into trr_contrato_servico
    (
    id_contrato_servico,
    id_contrato_cobranca,
    id_conta,
    id_pacote_comercial,
    id_convenio,
    id_promocao,
    dt_aquisicao,
    id_submotivo_status,
    dt_submotivo_status,
    dt_ativacao,
    dt_cancel,
    de_protocolo_cancel,
    bl_cancel_cobranca,
    bl_cancel_conta,
    tp_valor_multa,
    nr_valor_multa,
    nr_validade_multa,
    nr_aviso_previo,
    de_reajuste,
    dt_validade,
    id_contrato_servico_diradq
    )
values (
		id_contrato_servico_seq.nextval,
		id_contrato_cobranca,
		id_conta,
		id_pacote_comercial,
		id_convenio,
		id_promocao,
		dt_aquisicao,
		id_submotivo_status,
		dt_submotivo_status,
		dt_ativacao,
		dt_cancel,
		de_protocolo_cancel,
		bl_cancel_cobranca,
		bl_cancel_conta,
		tp_valor_multa,
		nr_valor_multa,
		nr_validade_multa,
		nr_aviso_previo,
		de_reajuste,
		dt_validade,
		id_contrato_servico_diradq
     )
select /*+ ordered use_hash (gatcpp cmdi cmco gatprod gatconta cmcps cont conv line oper sus most stat) */
		cont.id_contrato_cobranca, --1,
		cont.id_conta,
		cmdi.suat_chave id_pacote_comercial,
		conv.id_convenio,
		null id_promocao,
		cont.dt_cadastro dt_aquisicao,
		sust.id_submotivo_status,
		decode(gatprod.cod_prodciut,'VDK',to_date('22/10/2001','dd/mm/yyyy'),
					'ALB',to_date('22/10/2001','dd/mm/yyyy'),cont.dt_cadastro) dt_submotivo_status,
		decode(gatprod.cod_prodciut,'VDK',to_date('22/10/2001','dd/mm/yyyy'),
					'ALB',to_date('22/10/2001','dd/mm/yyyy'),cont.dt_cadastro) dt_ativacao,
		cont.dt_cancel,
		null de_protocolo_cancel,
		'N' bl_cancel_cobranca,
		'N' bl_cancel_conta,
		'V' tp_valor_multa,
		null nr_valor_multa,
		null nr_validade_multa,
		null nr_aviso_previo,
		null de_reajuste,
		null dt_validade,
		cmcps.suat_chave id_contrato_servico_diradq
   from gatmig.conta gatconta,
		gatmig.contaplanoprod gatcpp,
     	trr_controle_migracao_conta cmco,
     	trr_controle_migracao_diradq cmdi,
     	gatmig.produto gatprod,
     	trr_controle_migracao_cps cmcps,
     	trr_convenio conv,
     	trr_conta cont,
     	trr_linha_negocio line,
     	(select /*+ no_merge */ distinct linhanegocio from gatmig.operadora) oper,
     	trr_submotivo_status sust,
     	trr_motivo_status most,
     	trr_status stat
  where gatcpp.cod_conta 			= cmco.gat_chave
	and gatcpp.cod_conta 			= gatconta.cod_conta
	and line.id_linha_negocio 		= cmco.id_linha_negocio
	and upper(oper.linhanegocio) 	= line.nm_linha_negocio
	and gatconta.principal 			= 'S'
	and gatcpp.cod_prod 			= cmdi.gat_codprod
	and gatcpp.cod_carac 			= cmdi.gat_codcarac
	and gatcpp.valorcarac 			= cmdi.gat_vlcarac
	and gatcpp.cod_prod 			= gatprod.cod_prod
	and cmdi.id_linha_negocio 		= cmco.id_linha_negocio
	and cont.id_conta 				= cmco.suat_chave
	and conv.id_linha_negocio 		= cmco.id_linha_negocio
	and conv.tp_convenio 			= 'I'
	and conv.cd_convenio 			= 'CVCNT0000000'
	and sust.id_linha_negocio 		= cmco.id_linha_negocio
	and sust.cd_submotivo_status 	= gatconta.cod_statcta
	and sust.id_motivo_status 		= most.id_motivo_status
	and most.id_status 				= stat.id_status
	and stat.tp_status 				= 'A'
	and most.de_objeto_motivo 		= 'CPS'
	and cmcps.gat_tabela 			= 'PLANOCONTRATO'
	and cmcps.gat_chave 			= gatconta.cod_contr
	and cmcps.id_linha_negocio 		= cmco.id_linha_negocio
  UNION
  select /*+ Ordered use_hash (gatcpp cmdi cmco gatprod gatconta gatcontaaad cmcps cont conv line oper sust most stat) */
		cont.id_contrato_cobranca, --1,
		cmco.suat_chave id_conta,
		cmdi.suat_chave id_pacote_comercial,
		conv.id_convenio,
		null id_promocao,
		cont.dt_cadastro dt_aquisicao,
		sust.id_submotivo_status,
		decode(gatprod.cod_prodciut,'VDK',to_date('22/10/2001','dd/mm/yyyy'),
					'ALB',to_date('22/10/2001','dd/mm/yyyy'),cont.dt_cadastro) dt_submotivo_status,
		decode(gatprod.cod_prodciut,'VDK',to_date('22/10/2001','dd/mm/yyyy'),
				'ALB',to_date('22/10/2001','dd/mm/yyyy'),cont.dt_cadastro) dt_ativacao,
		cont.dt_cancel,
		null de_protocolo_cancel,
		'N' bl_cancel_cobranca,
		'N' bl_cancel_conta,
		'V' tp_valor_multa,
		null nr_valor_multa,
		null nr_validade_multa,
		null nr_aviso_previo,
		null de_reajuste,
		null dt_validade,
		cmcps.suat_chave id_contrato_servico_diradq
   from gatmig.conta gatconta,
     	gatmig.conta gatcontaad,
	gatmig.contaplanoprod gatcpp,
     	trr_controle_migracao_diradq cmdi,
     	gatmig.produto gatprod,
     	trr_controle_migracao_conta cmco,
     	trr_controle_migracao_cps cmcps,
     	trr_conta cont,
     	trr_convenio conv,
     	trr_linha_negocio line,
     	(select /*+ no_merge */ distinct linhanegocio from gatmig.operadora) oper,
     	trr_submotivo_status sust,
     	trr_motivo_status most,
     	trr_status stat
  where gatcpp.cod_conta 			= gatcontaad.cod_conta --cmco.gat_chave
  	and line.id_linha_negocio 		= cmco.id_linha_negocio
  	and upper(oper.linhanegocio) 	= line.nm_linha_negocio
  	and gatcpp.cod_prod 			= cmdi.gat_codprod
  	and gatcpp.cod_carac 			= cmdi.gat_codcarac
  	and gatcpp.valorcarac 			= cmdi.gat_vlcarac
  	and gatcpp.cod_prod 			= gatprod.cod_prod
  	and cmdi.id_linha_negocio 		= cmco.id_linha_negocio
  	and conv.id_linha_negocio 		= cmco.id_linha_negocio
  	and conv.tp_convenio 			= 'I'
  	and conv.cd_convenio 			= 'CVCNT0000000'
  	and sust.id_linha_negocio 		= cmco.id_linha_negocio
  	and sust.cd_submotivo_status 	= gatconta.cod_statcta
  	and sust.id_motivo_status 		= most.id_motivo_status
  	and most.id_status 				= stat.id_status
  	and stat.tp_status 				= 'A'
  	and most.de_objeto_motivo 		= 'CPS'
  	and cmcps.gat_tabela 			= 'PLANOCONTRATO'
  	and cmcps.gat_chave 			= gatconta.cod_contr
  	and cmcps.id_linha_negocio 		= cmco.id_linha_negocio
  	and gatconta.principal  		= 'S' --sóconta principal
  	and gatcontaad.principal 		= 'N'
  	and gatconta.cod_contr  		= gatcontaad.cod_contr
  	and cmco.suat_tabela    		= 'TRR_CONTA'
  	and cmco.gat_tabela     		= 'CONTA'
  	and cmco.gat_chave      		= gatconta.cod_conta
  	and cmco.suat_chave     		= cont.id_conta;
commit;

spool off;
exit;

