col OPERATION for a85;
col OPTIMIZER for a18;
col OBJECT_NODE for a10;
col OTHER for a40;

delete from system.plan_table;
commit;
--
explain plan
into system.plan_table
for
------------------
select f.flog_id
              ,f.nick_flog
              ,to_char(v.dt_criacao, 'dd/mm/yyyy hh24:mi') dt_criacao
          from (select v.flog_id, v.dt_criacao
                  from trr_favoritos v
                 where v.flog_id_fav    = :ln_flog
                   and exists (select 1
                                 from trr_flog_origens
                                where flog_id                   = v.flog_id
                                  and DT_ULTIMO_POST >= current_date - :in_dias_post)
                 order by v.dt_criacao desc) v
            ,trr_flogs f
       where f.flog_id   = v.flog_id
------------------
/

-------------------

select 	lpad(' ',2*(level-1))|| decode(id,0,operation||' '||options||' '||object_name||' Cost:'||cost,operation||' '||options||' '||object_name) operation,
	optimizer,
	cardinality num_rows --, PARTITION_START, PARTITION_STOP
--	object_node,
--	other
 from system.plan_table
connect by prior id=parent_id
start with id=0;

--
--SELECT PARTITION_START, PARTITION_STOP FROM PLAN_TABLE
--/
/*



*/
