##clean_trc_aud.sh
##
. /home/oracle/.bash_profile
DIR_DEST=$ORACLE_BASE/admin
SUFIX1=.trc
SUFIX2=.aud
DT=`date +%Y%m%d%H%M%S`
RETENTION=60

##
echo "Cleaning .aud and .trc files older than $RETENTION days..."
find ${DIR_DEST} -name *${SUFIX1} -mtime +${RETENTION} -print -exec rm {} \;
find ${DIR_DEST} -name *${SUFIX2} -mtime +${RETENTION} -print -exec rm {} \;
