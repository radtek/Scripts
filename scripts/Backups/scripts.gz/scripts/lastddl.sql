select * from (
select * from dba_objects where object_type <> 'DATABASE LINK' order by last_ddl_time desc)
where rownum <= 50
/

