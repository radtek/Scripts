ANO=2006
MES=1
BLOCO_COMMIT=100
CDSUBMOTIVOSTATUS="CE7"

## Variaveis necessarias p/ o client oracle



aumento_pendente ()
{
sqlplus -s suat/tcdpp6@base03 <<eof
set feed off
whenever sqlerror exit 1;
declare
  lv_ret integer := null;
begin
  select 1
    into lv_ret
    from trr_aumentopreco_cliente
   where nr_ano = ${ANO}
     and nr_mes = ${MES}
     and bl_valido_suat is null
     and rownum <= 1;
end;
/
exit 
eof
}
     

exec_aumento ()
{
sqlplus -s suat/tcdpp6@base03 <<eof
set echo on
set timing on
set time on
set serveroutput on size 1000000;
begin
   trr_pkg_aumento_preco.prc_loop_efetua_aumento
   (
      IPANOCOMPETENCIA      => ${ANO}, 
      IPMESCOMPETENCIA      => ${MES}, 
      IPTAMANHOBLOCOCOMMIT  => ${BLOCO_COMMIT}, 
      IPCDSUBMOTIVOSTATUS   => '${CDSUBMOTIVOSTATUS}',
      IPMAXNROLINHAS         => ${BLOCO_COMMIT} 
   );
end;
/
exit;
eof
}

IND=0
while true
do
  IND=`expr $IND + 1 `
  echo "`date` -> Executando um bloco de aumento de precos ($IND)."
  exec_aumento
  aumento_pendente > /dev/null 2>&1
  if [ $? = 0 ] ; then
    echo "Existem aumentos pendentes"
  else
    echo "Nao existem aumentos pendentes."
    exit
  fi 
done

