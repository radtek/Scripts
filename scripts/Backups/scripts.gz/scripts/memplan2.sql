col OPERATION for a85;
col OPTIMIZER for a18;
col OBJECT_NODE for a10;
col OTHER for a40;
accept hash prompt 'Hash_value:'
delete from plan_table;
commit;

insert into plan_table (STATEMENT_ID      ,
                        OPERATION         ,
                        OPTIONS           ,
                        OBJECT_NODE       ,
                        OBJECT_OWNER      ,
                        OBJECT_NAME       ,
                        OPTIMIZER         ,
                        ID                ,
                        PARENT_ID         ,
                        POSITION          ,
                        COST              ,
                        CARDINALITY       ,
                        BYTES             ,
                        OTHER_TAG         ,
                        PARTITION_START   ,
                        PARTITION_STOP    ,
                        PARTITION_ID      ,
                        OTHER             ,
                        DISTRIBUTION      ,
                        CPU_COST          ,
                        IO_COST           ,
                        TEMP_SPACE        ,
                        ACCESS_PREDICATES ,
                        FILTER_PREDICATES )
                select  to_char(hash_value),
                        OPERATION         ,
                        OPTIONS           ,
                        OBJECT_NODE       ,
                        OBJECT_OWNER      ,
                        OBJECT_NAME       ,
                        OPTIMIZER         ,
                        ID                ,
                        PARENT_ID         ,
                        POSITION          ,
                        COST              ,
                        CARDINALITY       ,
                        BYTES             ,
                        OTHER_TAG         ,
                        PARTITION_START   ,
                        PARTITION_STOP    ,
                        PARTITION_ID      ,
                        OTHER             ,
                        DISTRIBUTION      ,
                        CPU_COST          ,
                        IO_COST           ,
                        TEMP_SPACE        ,
                        ACCESS_PREDICATES ,
                        FILTER_PREDICATES 
                  from  v$sql_plan
                 where hash_value = &hash
/
commit;

select     lpad(' ',2*(level-1))|| decode(id,0,operation||' '||options||' '||object_name||' Cost:'||cost,operation||' '||options||' '||object_name) operation,
   optimizer,
   cardinality num_rows , PARTITION_START, PARTITION_STOP,
 object_node,
 other
 from system.plan_table
connect by prior id=parent_id
start with id=0;
-----

