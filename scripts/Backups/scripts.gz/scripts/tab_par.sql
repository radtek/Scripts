UNDEFINE TABELA;
undefine own;
COL HIGH_VALUE FOR A30 TRUNC;
col tablespace_name for a50;
col partition_name for a30;
select     partition_name, a.tablespace_name || ' (' || decode(tbloff.status,NULL, b.status, tbloff.status) || ')' Tablespace_name,
   HIGH_VALUE , num_rows, last_analyzed, PARTITION_POSITION, sample_size, CHAIN_CNT, pct_free, COMPRESSION
from dba_tab_partitions a,
   (Select distinct a.name, status
   from v$tablespace a, v$datafile b
   where a.ts# = b.ts#
     and b.status = 'OFFLINE') tbloff,
   dba_tablespaces b
where table_name = UPPER('&TABELA')
  and table_owner = upper('&own')
  and a.tablespace_name = tbloff.name (+)
  and a.tablespace_name = b.tablespace_name
ORDER BY PARTITION_POSITION
/

