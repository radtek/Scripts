
# verifica se o processo de insercao das variaveis obps esta rodando...
X=`ps -efw | grep 7568 | grep -v grep`

if [ ! "${X}x" = "x" ] ; then
   echo "`date` => Processo rodando." > /tmp/mon_ins.log
else
   echo "`date` => Processo Parado." > /tmp/mon_ins.log
   cat /o01/app/oracle/advanced/work/ins_obpv_users.log >> /tmp/mon_ins.log
fi
mail -s "Aviso" 5198260328@aviso.net.br < /tmp/mon_ins.log
