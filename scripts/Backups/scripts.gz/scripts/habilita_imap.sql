spool habilita_imap.log
set timing on
set echo on
set serveroutput on size 1000000

alter session set HASH_AREA_SIZE = 30000000;
alter session set sort_area_size=50000000;
alter session set hash_multiblock_io_count=16;
alter session set db_file_multiblock_read_count=128;

-- Script de habilitacao de IMAP para todas as caixas postais
--
--
declare
	cursor c_cur (in_numregs in number) is
		select usrm.usrm_id
		from mail.trr_usr_mails usrm,
			  bd_central.trr_obpv_users obpv
		where usrm.usrm_id = obpv.snh_id
		and	obpv.obpv_id = 48
		and	obpv.valor in ('2_ALLOWED', '1_ONLY_WEB')
		and	usrm.d_mail_imap_habilitado = 'N'
		and	rownum <= in_numregs;

    v_lines_to_commit 	number := 1000;
    ln_count 				number := 0;
    lv_exit 				varchar2(1) := null;
    ln_num_ok				number := 0;
    ln_total				number := 82000;
begin
	-- Esse loop foi incluido apenas para tratar os poss�veis ORA-1555 (SNAPSHOT TOO OLD).
	lv_exit := 'N';
	loop
		exit when lv_exit = 'S';
		begin
			if (ln_total>ln_num_ok) then
				for c_cur_rec in c_cur(ln_total-ln_num_ok)
				loop

					update mail.trr_usr_mails
					set d_mail_imap_habilitado = 'S'
					where usrm_id = c_cur_rec.usrm_id;

					if (ln_count = v_lines_to_commit) then
						commit;
						ln_count := 0;
					else
						ln_count := ln_count + 1;
					end if;
					ln_num_ok := ln_num_ok + 1;
				end loop;
				commit;
				lv_exit := 'S';
			else
				lv_exit := 'S';
			end if;

		exception when others then
			if (sqlcode = -1555) then -- snapshot too old
				lv_exit := 'N';
				rollback;
			else
				rollback;
				raise;
			end if;
		end;
	end loop;
	dbms_output.put_line('Total de usu�rios processados = ' || (ln_num_ok));
end;
/
exit;
