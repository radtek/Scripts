select INDEX_name, num_rows, to_char(last_analyzed,'dd/mm/yyyy hh24:mi:ss') ultima
 from dba_INDEXES
where owner = upper('&dono')
/
