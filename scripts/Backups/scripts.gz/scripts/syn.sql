select * from dba_synonyms
 where synonym_name like '%' ||upper('&syn') || '%'
/

