set timing on;
spool rebuild_index.log
alter session set sort_area_size=100000000;

alter index MEUDINHEIRO.AMB_USRP_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 4194304);
alter index MEUDINHEIRO.AMB_USRP_FK_I logging;
analyze index MEUDINHEIRO.AMB_USRP_FK_I compute statistics;

alter index MEUDINHEIRO.AMB_PK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 4194304);
alter index MEUDINHEIRO.AMB_PK logging;
analyze index MEUDINHEIRO.AMB_PK compute statistics;

alter index MEUDINHEIRO.AMB_USRP_AMB_ID_UK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 5242880);
alter index MEUDINHEIRO.AMB_USRP_AMB_ID_UK logging;
analyze index MEUDINHEIRO.AMB_USRP_AMB_ID_UK compute statistics;

alter index MEUDINHEIRO.CATG_PLAN_CATG_ID_UK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 47185920);
alter index MEUDINHEIRO.CATG_PLAN_CATG_ID_UK logging;
analyze index MEUDINHEIRO.CATG_PLAN_CATG_ID_UK compute statistics;

alter index MEUDINHEIRO.CATG_PLAN_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 36700160);
alter index MEUDINHEIRO.CATG_PLAN_FK_I logging;
analyze index MEUDINHEIRO.CATG_PLAN_FK_I compute statistics;

alter index MEUDINHEIRO.CATG_PK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 35651584);
alter index MEUDINHEIRO.CATG_PK logging;
analyze index MEUDINHEIRO.CATG_PK compute statistics;

alter index MEUDINHEIRO.CONT_PLAN_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 2097152);
alter index MEUDINHEIRO.CONT_PLAN_FK_I logging;
analyze index MEUDINHEIRO.CONT_PLAN_FK_I compute statistics;

alter index MEUDINHEIRO.CONT_PK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 2097152);
alter index MEUDINHEIRO.CONT_PK logging;
analyze index MEUDINHEIRO.CONT_PK compute statistics;

alter index MEUDINHEIRO.CONT_PLAN_CONT_ID_UK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 3145728);
alter index MEUDINHEIRO.CONT_PLAN_CONT_ID_UK logging;
analyze index MEUDINHEIRO.CONT_PLAN_CONT_ID_UK compute statistics;

alter index MEUDINHEIRO.CEVT_PK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 1048576);
alter index MEUDINHEIRO.CEVT_PK logging;
analyze index MEUDINHEIRO.CEVT_PK compute statistics;

alter index MEUDINHEIRO.PLAN_ID_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 2097152);
alter index MEUDINHEIRO.PLAN_ID_I logging;
analyze index MEUDINHEIRO.PLAN_ID_I compute statistics;

alter index MEUDINHEIRO.MAIL_PLAN_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 6291456);
alter index MEUDINHEIRO.MAIL_PLAN_FK_I logging;
analyze index MEUDINHEIRO.MAIL_PLAN_FK_I compute statistics;

alter index MEUDINHEIRO.MAIL_PK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 4194304);
alter index MEUDINHEIRO.MAIL_PK logging;
analyze index MEUDINHEIRO.MAIL_PK compute statistics;

alter index MEUDINHEIRO.MAIL_PLAN_MAIL_ID_TIPO_UK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 6291456);
alter index MEUDINHEIRO.MAIL_PLAN_MAIL_ID_TIPO_UK logging;
analyze index MEUDINHEIRO.MAIL_PLAN_MAIL_ID_TIPO_UK compute statistics;

alter index MEUDINHEIRO.EVNT_PLAN_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 1048576);
alter index MEUDINHEIRO.EVNT_PLAN_FK_I logging;
analyze index MEUDINHEIRO.EVNT_PLAN_FK_I compute statistics;

alter index MEUDINHEIRO.EVNT_PK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 1048576);
alter index MEUDINHEIRO.EVNT_PK logging;
analyze index MEUDINHEIRO.EVNT_PK compute statistics;

alter index MEUDINHEIRO.EVNT_PLAN_EVNT_ID_UK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 1048576);
alter index MEUDINHEIRO.EVNT_PLAN_EVNT_ID_UK logging;
analyze index MEUDINHEIRO.EVNT_PLAN_EVNT_ID_UK compute statistics;

alter index MEUDINHEIRO.FMPG_CONT_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 10485760);
alter index MEUDINHEIRO.FMPG_CONT_FK_I logging;
analyze index MEUDINHEIRO.FMPG_CONT_FK_I compute statistics;

alter index MEUDINHEIRO.FMPG_PK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 10485760);
alter index MEUDINHEIRO.FMPG_PK logging;
analyze index MEUDINHEIRO.FMPG_PK compute statistics;

alter index MEUDINHEIRO.FMPG_CONT_FMPG_ID_UK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 13631488);
alter index MEUDINHEIRO.FMPG_CONT_FMPG_ID_UK logging;
analyze index MEUDINHEIRO.FMPG_CONT_FMPG_ID_UK compute statistics;

alter index MEUDINHEIRO.MOVI_CONT_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 17825792);
alter index MEUDINHEIRO.MOVI_CONT_FK_I logging;
analyze index MEUDINHEIRO.MOVI_CONT_FK_I compute statistics;

alter index MEUDINHEIRO.MOVI_PLAN_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 17825792);
alter index MEUDINHEIRO.MOVI_PLAN_FK_I logging;
analyze index MEUDINHEIRO.MOVI_PLAN_FK_I compute statistics;

alter index MEUDINHEIRO.MOVI_CATG_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 18874368);
alter index MEUDINHEIRO.MOVI_CATG_FK_I logging;
analyze index MEUDINHEIRO.MOVI_CATG_FK_I compute statistics;

alter index MEUDINHEIRO.MOVI_PK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 17825792);
alter index MEUDINHEIRO.MOVI_PK logging;
analyze index MEUDINHEIRO.MOVI_PK compute statistics;

alter index MEUDINHEIRO.MOVI_FMPG_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 16777216);
alter index MEUDINHEIRO.MOVI_FMPG_FK_I logging;
analyze index MEUDINHEIRO.MOVI_FMPG_FK_I compute statistics;

alter index MEUDINHEIRO.MOVI_PLAN_MOVI_ID_UK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 23068672);
alter index MEUDINHEIRO.MOVI_PLAN_MOVI_ID_UK logging;
analyze index MEUDINHEIRO.MOVI_PLAN_MOVI_ID_UK compute statistics;

alter index MEUDINHEIRO.PLAN_USR_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 1048576);
alter index MEUDINHEIRO.PLAN_USR_FK_I logging;
analyze index MEUDINHEIRO.PLAN_USR_FK_I compute statistics;

alter index MEUDINHEIRO.PLAN_PK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 1048576);
alter index MEUDINHEIRO.PLAN_PK logging;
analyze index MEUDINHEIRO.PLAN_PK compute statistics;

alter index MEUDINHEIRO.PLAN_USR_PLAN_ID_UK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 2097152);
alter index MEUDINHEIRO.PLAN_USR_PLAN_ID_UK logging;
analyze index MEUDINHEIRO.PLAN_USR_PLAN_ID_UK compute statistics;

alter index MEUDINHEIRO.USR_PK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 3145728);
alter index MEUDINHEIRO.USR_PK logging;
analyze index MEUDINHEIRO.USR_PK compute statistics;

alter index MEUDINHEIRO.USRP_PLAN_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 1048576);
alter index MEUDINHEIRO.USRP_PLAN_FK_I logging;
analyze index MEUDINHEIRO.USRP_PLAN_FK_I compute statistics;

alter index MEUDINHEIRO.USRP_USR_FK_I rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 1048576);
alter index MEUDINHEIRO.USRP_USR_FK_I logging;
analyze index MEUDINHEIRO.USRP_USR_FK_I compute statistics;

alter index MEUDINHEIRO.USRP_USR_PLAN_USRP_ID_UK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 2097152);
alter index MEUDINHEIRO.USRP_USR_PLAN_USRP_ID_UK logging;
analyze index MEUDINHEIRO.USRP_USR_PLAN_USRP_ID_UK compute statistics;

alter index MEUDINHEIRO.USRP_PK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 1048576);
alter index MEUDINHEIRO.USRP_PK logging;
analyze index MEUDINHEIRO.USRP_PK compute statistics;

alter index MEUDINHEIRO.USR_SNH_UK rebuild online nologging tablespace MEUDINHEIRO_INDEX
storage (initial 3145728);
alter index MEUDINHEIRO.USR_SNH_UK logging;
analyze index MEUDINHEIRO.USR_SNH_UK compute statistics;




spool off;
EXIT;
