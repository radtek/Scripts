col sql_text for a90;
set lines 300;
accept lista_sid prompt 'Lista sid:'
select sid,username,BUFFER_GETS,disk_reads,executions,sql_text,hash_value, rows_processed
from v$session a , v$sqlarea b
where a.sql_address = b.address
  and a.sql_hash_value = b.hash_value
  and sid IN (&lista_sid)
order by disk_reads
/
