spool update_usofoto.log
set timing on
set echo on
set serveroutput on size 1000000

--alter session set sort_area_size=30000000;
--alter session set hash_multiblock_io_count=16;
--alter session set db_file_multiblock_read_count=16;
--alter session set sort_multiblock_read_count=16;

-- Script para inicializa��o dos cr�ditos de usu�rios
--
declare
	cursor c_cur (id_datacad in date) is
		select ualm.ualm_id
		from almasgemeas.trr_usr_alms ualm
		where ualm.d_uso_da_foto is not null
		and	ualm.d_uso_da_foto = 'N'
		and	ualm.data_cadastro < id_datacad;

    v_lines_to_commit 	number := 100;
    ln_count 				number := 0;
    lv_exit 				varchar2(1) := null;
    ln_num_ok				number := 0;
    ln_ora_2291			number := 0;
    ld_datacad 			date := to_date('25/05/2004', 'dd/mm/yyyy');
begin
	-- Esse loop foi incluido apenas para tratar os poss�veis ORA-1555 (SNAPSHOT TOO OLD).
	lv_exit := 'N';
	loop
		exit when lv_exit = 'S';
		begin
			ln_ora_2291 := 0;
			for c_cur_rec in c_cur(ld_datacad)
			loop
				begin
					update almasgemeas.trr_usr_alms
					set d_uso_da_foto = NULL
					where ualm_id = c_cur_rec.ualm_id;
				exception
					when others then
						if (sqlcode = -2291) then -- parent key not found
							ln_ora_2291 := ln_ora_2291 + 1;
							rollback;
						else
							raise;
						end if;
				end;
				if (ln_count = v_lines_to_commit) then
					commit;
					ln_count := 0;
				else
					ln_count := ln_count + 1;
				end if;
				ln_num_ok := ln_num_ok + 1;
			end loop;

			commit;
			
			if ln_ora_2291 = 0 then
				lv_exit := 'S';
			else
				dbms_output.put_line('erro ora_2291 [' || ln_ora_2291 || ']');
			end if;

		exception when others then
			if (sqlcode = -1555) then -- snapshot too old
				lv_exit := 'N';
				rollback;
			else
				rollback;
				raise;
			end if;
		end;
	end loop;
	dbms_output.put_line('Total de usu�rios processados = ' || (ln_num_ok));
end;
/

exit;
