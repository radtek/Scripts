accept own prompt 'Owner:'
accept tab prompt 'Table:'
break on report;
compute sum of bytes on report;

select segment_name, partition_name, bytes, extents
from dba_segments
where owner = upper('&own')
and segment_name in (select index_name 
		       from dba_indexes 
		      where owner = upper('&own')
  			and table_name = upper('&tab'))
/

