undefine tabela;
select owner, table_name, constraint_name, constraint_type, status, deferrable
  from ALL_constraints
 where r_constraint_name in (select constraint_name
                              from ALL_constraints
                             where table_name = upper('&tabela')
                               and constraint_type = 'P')
/
