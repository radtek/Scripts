col message for a20;
col units for a10;
accept sid prompt 'SID:' defaul null;
select username,message,SOFAR,TOTALWORK,UNITS,
    to_char(START_TIME,'dd/mm/yyyy hh24:mi:ss') Inicio,
    TIME_REMAINING,ELAPSED_SECONDS, target
from v$session_longops
where (sid = &sid  or  &sid is null)
 and sofar <> totalwork
 and time_remaining > 0
/
