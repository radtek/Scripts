Break On report;
compute sum of Mb on report;
undef own;
select owner, segment_type, round(sum(bytes)/1024/1024) Mb
from dba_segments
where owner like upper('&own')||'%'
group by owner, segment_type
/

