col sid for 9999
col username for a14
col event for a27
col p1text for a9
col p2text for a9
col p3text for a9
col p1 for 999
col p2 for 999999
col p3 for 999
col seconds_in_wait for 9999 heading (s)
select /*+ rule */
       s.sid,s.username,w.seconds_in_wait,w.event,substr(w.p1text,1,9) p1text,w.p1,
       w.p2text,w.p2,w.p3text,w.p3,s.program,s.logon_time
from v$session s, v$session_wait w
where s.sid = w.sid and
      w.event <> 'SQL*Net message from client' and
      w.event <> 'Null event' and
      w.event <> 'rdbms ipc message' and
      w.event <> 'pmon timer' and
      w.event <> 'smon timer' and
--      w.event <> 'SQL*Net message to client' and
      w.event <> 'pipe get' and
      w.event <> 'jobq slave wait' and
      1=1;

