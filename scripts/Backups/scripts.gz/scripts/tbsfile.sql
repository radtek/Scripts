col file_name for a51
break on report
compute sum of mb on report
select /*+ ordered */
       d.file_name,d.bytes/1024/1024 Mb,d.file_id,v.status,
       d.tablespace_name||decode(t.status,'READ ONLY',' (RO)','OFFLINE',' (OFF)','ONLINE','',t.status) tablespace,
       d.increment_by*d.bytes/d.blocks/1024/1024 "Inc(Mb)",d.maxbytes/1024/1024 "Max(Mb)",to_char(v.checkpoint_time) checkpoint_time
from dba_data_files d,
     (select /*+ no_merge */ * from v$datafile) v ,
     (select /*+ no_merge */ tablespace_name,status from dba_tablespaces) t
where d.file_id = v.file# and
      d.tablespace_name like upper('&&tablespace') and
      d.tablespace_name = t.tablespace_name
union all
select file_name,bytes/1024/1024 Mb,file_id,status,tablespace_name,increment_by*bytes/blocks/1024/1024 "Inc(Mb)",maxbytes/1024/1024 "Max(Mb)", 'Tempfile'
from dba_temp_files
where tablespace_name like upper('&&tablespace')
order by 5,3
/
undef tablespace
clear computes
clear breaks

