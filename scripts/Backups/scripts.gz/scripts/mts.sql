--
-- max conn: especifica o m�ximo n�mero de clientes.
-- started : nro de shared server iniciados pelo pmon.
-- terminated: nro de shared server terminados pelo pmon.
-- HIGHWATER: especifica o m�ximo nro de shared servers que o banco 
--            chegou a ter desde o startup.
--
select maximum_connections "MAX CONN",
servers_started "STARTED",
servers_terminated "TERMINATED",
servers_highwater "HIGHWATER" from v$mts;
