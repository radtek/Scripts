select * from v$rollstat
/
