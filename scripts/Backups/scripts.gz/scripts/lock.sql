select a.sid,b.username,a.type,d.name||'.'||c.name name, a.id1, a.id2,
decode(lmode,1,'null',2,'RS',3,'RX',4,'S',5,'SRX',6,'X',0,'NONE',lmode) lmode,
decode(request,1,'null',2,'RS',3,'RX',4,'S',5,'SRX',6,'X',0,'NONE',request) request
from v$lock a,v$session b,sys.obj$ c,sys.user$ d
where a.id1 = c.OBJ# (+)
and a.sid = b.sid
and c.owner# = d.user# (+)
and b.username is not null
order by 1
/
