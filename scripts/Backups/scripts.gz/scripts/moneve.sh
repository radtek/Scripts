sqlplus sys/rqtyz7<<eof
exec prc_mon_ev(300,2,25);
exit;
eof

