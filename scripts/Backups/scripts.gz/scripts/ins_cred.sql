spool ins_cred.log
set timing on
set echo on

alter session set sort_area_size=30000000;
-- alter session set hash_multiblock_io_count=16;
-- alter session set db_file_multiblock_read_count=16;
-- alter session set sort_multiblock_read_count=16;


-- Script para inicializa��o dos cr�ditos de usu�rios
--
declare
	cursor c_usr(p_srv_id in number,
					 p_eve_id in number,
					 p_obpv_id in number) is
		select snh.email,
				 snh.snh_id,
			  	 obpv.valor sou_user_type,
			  	 uscd.uscd_id
		from bd_central.trr_senhas snh,
			  bd_central.trr_obpv_users obpv,
			  cred_debit.trr_usr_creddeb uscd
		where snh.snh_id = obpv.snh_id
		and	snh.cdom_id = 1
		and	obpv.obpv_id = p_obpv_id
		and 	obpv.snh_id = uscd.snh_id (+)
		and 	obpv.snh_id not in (
				select /*+ hash_aj */ 
						 uscd.snh_id
				from cred_debit.trr_usr_creddeb uscd,
					  cred_debit.trr_contas con,
					  cred_debit.trr_uso_creditos ucred
				where uscd.uscd_id = con.uscd_id
				and	ucred.con_id = con.con_id
				and	ucred.srv_id = p_srv_id
				and	ucred.eve_id = p_eve_id
				and	uscd.snh_id is not null
				);

    ln_srv_id				number;
    ln_eve_id 				number;
    ln_obpv_id				number;
    v_lines_to_commit 	number := 5000;
    ln_count 				number := 0;
    lv_exit 				varchar2(1) := null;
    ln_num_cred 			number;
    ln_num_ok				number := 0;
    ln_num_nok				number := 0;
    ln_ora_2291			number := 0;
    ln_ret					number;

begin
	select obpv_id
	into ln_obpv_id
	from bd_central.trr_obp_vars
	where nome = 'sou_user_type';
	
	select srv_id
	into ln_srv_id
	from bd_central.trr_servicos
	where servico = 'SMS';
	
	select eve_id
	into ln_eve_id
	from cred_debit.trr_eventos
	where srv_id = ln_srv_id
	and	evento = 'credito_sms';
	
	-- Esse loop foi incluido apenas para tratar os poss�veis ORA-1555 (SNAPSHOT TOO OLD).
	lv_exit := 'N';
	loop
		exit when lv_exit = 'S';
		begin
			ln_ora_2291 := 0;
			for c_usr_rec in c_usr (ln_srv_id, ln_eve_id, ln_obpv_id)
			loop
				if c_usr_rec.sou_user_type = '2_PREMIUM' then
					ln_num_cred := 15;
				else
					ln_num_cred := 5;
				end if;
				begin
					ln_ret := cred_debit.trr_fnc_new_account(
										c_usr_rec.email,
										'terra',
										'SMS',
										'credito_sms',
										ln_num_cred,
										'S',
										30,
										'N',
										'N',
										'UNI',
										sysdate+30,
										'S',
										'venda_planopacote');
					if ln_ret = 0 then
						begin
							insert into bd_central.trr_userprodutos
								(snh_id,
								 d_produto,
								 data_cadastro)
							values
								(c_usr_rec.snh_id,
								 'SMS',
								 sysdate);
						exception
							when DUP_VAL_ON_INDEX then
								NULL;
							when others then
								raise;
						end;

						ln_num_ok := ln_num_ok + 1;
					else
						ln_num_nok := ln_num_nok + 1;
						dbms_output.put_line('erro [' || ln_ret || '] user [' || c_usr_rec.email || ']');
					end if;
				exception
					when others then
						if (sqlcode = -2291) then -- parent key not found
							ln_ora_2291 := ln_ora_2291 + 1;
							rollback;
						else
							raise;
						end if;
				end;

				if (ln_count = v_lines_to_commit) then
					commit;
					ln_count := 0;
				else
					ln_count := ln_count + 1;
				end if;
			end loop;

			commit;
			
			if ln_ora_2291 = 0 then
				lv_exit := 'S';
			else
				dbms_output.put_line('erro ora_2291 [' || ln_ora_2291 || ']');
			end if;

		exception when others then
			if (sqlcode = -1555) then -- snapshot too old
				lv_exit := 'N';
				rollback;
			else
				rollback;
				raise;
			end if;
		end;
	end loop;
	dbms_output.put_line('Total de usu�rios processados = ' || (ln_num_ok+ln_num_nok));
	dbms_output.put_line('Total de usu�rios OK = ' || ln_num_ok);
	dbms_output.put_line('Total de usu�rios NOK = ' || ln_num_nok);
end;
/

exit;
