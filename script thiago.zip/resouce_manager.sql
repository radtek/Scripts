select plan, status, num_plan_directives, mandatory 
from dba_rsrc_plans; 