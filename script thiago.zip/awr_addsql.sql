exec dbms_workload_repository.add_colored_sql('&sql_id');
