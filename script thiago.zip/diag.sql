set lines 2000
col name format a50
col value format a100
SELECT * FROM V$DIAG_INFO;