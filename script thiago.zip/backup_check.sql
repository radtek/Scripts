prompt list corruption 
select * from V$DATABASE_BLOCK_CORRUPTION;
