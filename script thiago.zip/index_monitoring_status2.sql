prompt 
prompt **** obs: so apresenta informacoes do owner corrente ***
prompt 

select *
from v$object_usage;


undefine OWNER
undefine TABLE_NAME