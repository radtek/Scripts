prompt cuidado faz o flush da shared pool e buffer cache
prompt 
alter system flush shared_pool;
alter system flush buffer_cache;
