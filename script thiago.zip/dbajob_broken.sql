prompt broken true ou false
begin 
	sys.DBMS_iJOB.BROKEN(&job, &broken);
end;
/