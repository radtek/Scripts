select * 
from dba_sys_privs 
where PRIVILEGE = 'SELECT ANY TABLE';