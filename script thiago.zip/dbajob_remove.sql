BEGIN
   sys.DBMS_iJOB.REMOVE(&jobid);
END; 
/