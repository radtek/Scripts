begin 
	SYS.DBMS_IJOB.RUN(&jobid);
end;
/

@@runningjobs