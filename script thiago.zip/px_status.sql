SELECT * FROM v$pq_sysstat 
WHERE statistic LIKE 'Server%';