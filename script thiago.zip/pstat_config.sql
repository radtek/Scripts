select * from perfstat.stats$statspack_parameter
order by LAST_MODIFIED desc
/