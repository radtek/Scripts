prompt deve executar na instance ASM
prompt listar database com DG montados
prompt se baixar ASM instance com dbs montados falha se for do tipo normal ou immediate, tem que ser abort

select * from V$ASM_CLIENT;