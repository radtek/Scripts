SET numwidth 20
SELECT current_scn FROM v$database;
