prompt
prompt para comparar snaps, executar no servidor diretamente:
prompt @$ORACLE_HOME/rdbms/admin/spreport.sql
prompt 
@@info_env
