@@sesinfo.sql

begin 
	coleta_storage; 
end;
/