col sid for 9999999
select sid from v$mystat where rownum=1;