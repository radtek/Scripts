17:10:16 orahlg01>@clean
SP2-0734: in�cio de comando desconhecido "17:09:48 o..." - restante da linha ignorado.
SP2-0734: in�cio de comando desconhecido "17:09:50 o..." - restante da linha ignorado.
SP2-0734: in�cio de comando desconhecido "SP2-0223: ..." - restante da linha ignorado.
SP2-0734: in�cio de comando desconhecido "17:09:56 o..." - restante da linha ignorado.
SP2-0044: P/lista comandos conhec., informe HELP
. P/sair, informe EXIT.
SP2-0734: in�cio de comando desconhecido "SP2-0042: ..." - restante da linha ignorado.
SP2-0734: in�cio de comando desconhecido "17:10:07 o..." - restante da linha ignorado.
17:10:21 orahlg01>
17:10:31 orahlg01>
17:10:31 orahlg01>
17:10:31 orahlg01>
17:10:32 orahlg01>
17:10:32 orahlg01>
17:10:32 orahlg01>
17:10:32 orahlg01>
17:10:32 orahlg01>
17:10:33 orahlg01>
17:10:33 orahlg01>spool c:\temp\clean_infrahlgsuat.sql
