SELECT owner_name, job_name, operation, job_mode, state
FROM dba_datapump_jobs;