col name for a100
col value for a100
select inst_id, name, value from gv$parameter where name like '%&param_name%';